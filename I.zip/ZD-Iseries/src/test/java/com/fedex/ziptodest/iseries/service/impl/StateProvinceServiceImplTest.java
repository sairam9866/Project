package com.fedex.ziptodest.iseries.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.iseries.model.CountryCode;
import com.fedex.ziptodest.iseries.model.State;
import com.fedex.ziptodest.iseries.model.StateProvince;
import com.fedex.ziptodest.iseries.model.StateProvinceResponse;
import com.fedex.ziptodest.iseries.repository.CountryCodeRepository;
import com.fedex.ziptodest.iseries.repository.StateProvinceRepository;
import com.fedex.ziptodest.iseries.utils.AppConstants;

@RunWith(SpringRunner.class)
public class StateProvinceServiceImplTest {
	
	@InjectMocks
	private StateProvinceServiceImpl stateProvinceServiceImpl;
	@Mock
	private StateProvinceRepository stateProvinceRepository;
	@Mock
	private CountryCodeRepository countryCodeRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void testGetStateProvinceCode_Positive(){
		
		List<StateProvince> stateProvinceList =new ArrayList<>();
		
		StateProvince stateProvince=new StateProvince();
		stateProvince.setCntryc("CA");
		stateProvince.setSpName("ONTARIO");
		stateProvince.setStaPro("ON");
		
		stateProvinceList.add(stateProvince);
		
		List<CountryCode> countryCodeList=new ArrayList<>();
		CountryCode countryCode=new CountryCode();
		countryCode.setCyclcu(124);
		countryCode.setCycode("CA");
		
		countryCodeList.add(countryCode);
		
		State state = new State();
		state.setCode(124);
		state.setStateName("ON");

		List<State> data = new ArrayList<State>();
		data.add(state);

		Set<State> stateSet = new TreeSet<>();
		stateSet.add(state);
		
		StateProvinceResponse expected = new StateProvinceResponse();
		expected.setStatus("success");
		expected.setMessage("The state list has been generated successfully");
		expected.setData(stateSet);			

		Mockito.doReturn(stateProvinceList).when(stateProvinceRepository).selectByCountryCode(AppConstants.COUNTRY_CODE_US, AppConstants.COUNTRY_CODE_CA);
		Mockito.doReturn(countryCodeList).when(countryCodeRepository).findAll();
		StateProvinceResponse stateProvinceResponse = stateProvinceServiceImpl.getStateCountryCode();
		
		assertEquals(expected.getStatus(), stateProvinceResponse.getStatus());
	}
	
	@Test
	public void testGetStateProvinceCode_Negative(){
		
		StateProvinceResponse expected = new StateProvinceResponse();
		expected.setStatus("failure");
		expected.setMessage("The state list hasn't been generated becuase DB not connected");
		expected.setData(null);
		
		Mockito.doReturn(Collections.emptyList()).when(stateProvinceRepository).selectByCountryCode(AppConstants.COUNTRY_CODE_US, AppConstants.COUNTRY_CODE_CA);
		Mockito.doReturn(Collections.emptyList()).when(countryCodeRepository).findAll();
		StateProvinceResponse stateProvinceResponse = stateProvinceServiceImpl.getStateCountryCode();
		
		assertEquals(expected.getStatus(), stateProvinceResponse.getStatus());
		
	}
}