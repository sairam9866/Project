package com.fedex.ziptodest.iseries.utils;

import static org.junit.Assert.assertNotEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import org.junit.Test;

public class AppConstantsTest {

	@Test
	public void testPrivateConstructor() throws Exception {
		Constructor<AppConstants> constructor = AppConstants.class.getDeclaredConstructor();
		assertNotEquals(1,Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}
}
