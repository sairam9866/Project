package com.fedex.ziptodest.iseries.utils;

import static org.junit.Assert.assertNotEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import org.junit.Test;

public class NetworkConstantsTest {
	
	@Test
	public void testNetworkConstantsPrivateConstructor() throws Exception {
		Constructor<NetworkConstants> constructor = NetworkConstants.class.getDeclaredConstructor();
		assertNotEquals(1,Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

}
