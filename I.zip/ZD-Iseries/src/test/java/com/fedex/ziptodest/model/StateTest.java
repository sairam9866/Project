package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.fedex.ziptodest.iseries.model.State;

public class StateTest {

	
	@Test
	public void testState_Positive() {
		State state = new State();
		state.setCode(124);
		state.setStateName("CA");

		assertEquals(124, state.getCode());
		assertEquals("CA", state.getStateName());
	}
	@Test
	public void testState_Negitive() {
		State state = new State();
		state.setCode(840);
		state.setStateName("NY");

		assertNotEquals(124, state.getCode());
		assertNotEquals("CA", state.getStateName());

	}

	@Test
	public void testToString() {
		State state = new State();
		assertNotEquals(null, state.toString());
	}
	
	@Test
	public void testHashCode() {
		State state = new State();
		assertTrue(state.hashCode() > 0);
		state.setCode(1);
		state.setStateName("WA");
		assertTrue(state.hashCode() > 0);
	}
	
	@Test
	public void testEquals() {			
		State state = new State();
		assertTrue(state.equals(state));
		
		State state2 = null;
		assertFalse(state.equals(state2));
		assertFalse(state.equals(new Object()));
		
		state2 = new State();
		state.setCode(0);
		state2.setCode(1);
		assertFalse(state.equals(state2));
		
		state.setStateName(null);
		state2.setStateName("QA");
		state.setCode(1);
		state2.setCode(1);
		assertFalse(state.equals(state2));	
		
		state.setStateName(null);
		state2.setStateName(null);
		state.setCode(1);
		state2.setCode(1);
		assertTrue(state.equals(state2));
		
		state.setStateName("AQ");
		state2.setStateName("AQ");
		state.setCode(1);
		state2.setCode(1);
		assertTrue(state.equals(state2));
		
		state.setStateName("AQ");
		state2.setStateName("QA");
		state.setCode(1);
		state2.setCode(1);
		assertFalse(state.equals(state2));
	}
}
