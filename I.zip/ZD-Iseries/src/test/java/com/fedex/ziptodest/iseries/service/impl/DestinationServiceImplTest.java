package com.fedex.ziptodest.iseries.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.iseries.model.Destination;
import com.fedex.ziptodest.iseries.repository.DestinationRepository;
import com.fedex.ziptodest.iseries.utils.AppConstants;

@RunWith(SpringRunner.class)
public class DestinationServiceImplTest {

	@InjectMocks
	private DestinationServiceImpl destinationService;
	
	@Mock
	private DestinationRepository destinationRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testIsDestinationNotExist(){
		String destination = "1231";
		Destination dest = new Destination();
		dest.setTerminalAbbreviation("WAQ");
		dest.setTerminalNumber(1231);
		dest.setTerminalStatus("A");
		List<Destination> destinations = new ArrayList<>();
		destinations.add(dest);
		Mockito.doReturn(destinations).when(destinationRepository).findByTerminalNumberAndTerminalStatus(Integer.parseInt(destination), AppConstants.TERMINAL_STATUS_ADDED);
		boolean destinationNotExist = destinationService.isDestinationExist(destination);
		
		assertTrue(destinationNotExist);
	}
	@Test
	public void testIsDestinationNotExist_Negative(){
		String destination = "0011";
		List<Destination> destinations = new ArrayList<>();
		Mockito.doReturn(destinations).when(destinationRepository).findByTerminalNumberAndTerminalStatus(Integer.parseInt(destination), AppConstants.TERMINAL_STATUS_ADDED);
		
		boolean destinationNotExist = destinationService.isDestinationExist(destination);
		
		assertFalse(destinationNotExist);
	}
	
	@Test
	public void testIsDestinationNotExist_Invalid(){
		String destination = "12345";
		boolean destinationNotExist = destinationService.isDestinationExist(destination);		
		assertFalse(destinationNotExist);
	}
}
