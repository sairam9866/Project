package com.fedex.ziptodest.model;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

import com.fedex.ziptodest.iseries.model.State;
import com.fedex.ziptodest.iseries.model.StateProvinceResponse;


public class StateProvinceResponseTest {

	@Test
	public void testStateProvinceModels_Positive() {
		StateProvinceResponse stateProvinceResponse = new StateProvinceResponse();
		stateProvinceResponse.setMessage("Hi");
		stateProvinceResponse.setStatus("200");
		State state = new State();
		state.setStateName("CA");
		state.setCode(124);
		Set<State> states = new TreeSet<>();
		states.add(state);
		stateProvinceResponse.setData(states);		
		assertNotNull(stateProvinceResponse.getData());
		assertNotNull(stateProvinceResponse);
	}
	@Test
	public void testToString() {
		StateProvinceResponse stateProvinceResponse = new StateProvinceResponse();
		assertNotEquals(null, stateProvinceResponse.toString());
	}	
}
