package com.fedex.ziptodest.iseries.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.iseries.model.CountryCode;
import com.fedex.ziptodest.iseries.repository.redis.CountryCodeRedisRepository;

@Repository("countryCodeRepository")
public class CountryCodeRepository implements CountryCodeRedisRepository {

	@Autowired
	@Qualifier("countryCodeRedisRepository")
	CountryCodeRedisRepository countryCodeRedisRepository;

	@Override
	public List<CountryCode> findAll() {
		return (List<CountryCode>) countryCodeRedisRepository.findAll();
	}

	@SuppressWarnings("unchecked")
	@Override
	public CountryCode save(CountryCode countryCode) {
		return countryCodeRedisRepository.save(countryCode);
	}

	@Override
	public <S extends CountryCode> Iterable<S> saveAll(Iterable<S> entities) {
		return countryCodeRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<CountryCode> findById(String id) {
		return countryCodeRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(String id) {
		return countryCodeRedisRepository.existsById(id);
	}

	@Override
	public Iterable<CountryCode> findAllById(Iterable<String> ids) {
		return countryCodeRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return countryCodeRedisRepository.count();
	}

	@Override
	public void deleteById(String id) {
		countryCodeRedisRepository.deleteById(id);
	}

	@Override
	public void delete(CountryCode entity) {
		countryCodeRedisRepository.delete(entity);
	}

	@Override
	public void deleteAll(Iterable<? extends CountryCode> entities) {
		countryCodeRedisRepository.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		countryCodeRedisRepository.deleteAll();
	}

}
