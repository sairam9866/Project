package com.fedex.ziptodest.iseries.service;

public interface EmbeddedServerPayloadService {

	public void init();
}
