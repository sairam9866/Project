package com.fedex.ziptodest.iseries.repository;

import java.util.Optional;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.repository.redis.NetworkRedisRepository;
import com.fedex.ziptodest.iseries.utils.AppConstants;

@Repository("networkRepository")
public class NetworkRepository implements NetworkRedisRepository {

	@Autowired
	@Qualifier("networkRedisRepository")
	NetworkRedisRepository networkRedisRepository;

	@Resource(name = "iseriesRedisTemplate")
	private ZSetOperations<String, String> networkSetOperations;

	@SuppressWarnings("unchecked")
	@Override
	public Network save(Network network) {
		networkSetOperations.add(AppConstants.HASH_KEY_NETWORK, network.getNetworkId(), network.getTermNum());
		return networkRedisRepository.save(network);
	}

	@Override
	public Set<String> selectAllNetworks() {
		return networkSetOperations.range(AppConstants.HASH_KEY_NETWORK, AppConstants.SET_START_INDEX,
				AppConstants.SET_END_INDEX); 
	}

	@Override
	public <S extends Network> Iterable<S> saveAll(Iterable<S> entities) {
		return networkRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<Network> findById(Long id) {
		return networkRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(Long id) {
		return networkRedisRepository.existsById(id);
	}

	@Override
	public Iterable<Network> findAll() {
		return networkRedisRepository.findAll();
	}

	@Override
	public Iterable<Network> findAllById(Iterable<Long> ids) {
		return networkRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return networkRedisRepository.count();
	}

	@Override
	public void deleteById(Long id) {
		networkRedisRepository.deleteById(id);
	}

	@Override
	public void delete(Network entity) {
		networkRedisRepository.delete(entity);
	}

	@Override
	public void deleteAll(Iterable<? extends Network> entities) {	
		networkRedisRepository.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		networkRedisRepository.deleteAll();
	}

}
