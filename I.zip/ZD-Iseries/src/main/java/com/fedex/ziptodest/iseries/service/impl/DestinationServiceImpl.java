package com.fedex.ziptodest.iseries.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.iseries.model.Destination;
import com.fedex.ziptodest.iseries.repository.DestinationRepository;
import com.fedex.ziptodest.iseries.service.DestinationService;
import com.fedex.ziptodest.iseries.utils.AppConstants;
import com.fedex.ziptodest.iseries.utils.ValidationUtil;

@Service
public class DestinationServiceImpl implements DestinationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DestinationServiceImpl.class);

	@Autowired
	@Qualifier("destinationRepository")
	DestinationRepository destinationRepository;

	@Override
	public boolean isDestinationExist(String terminalNumber) {
		boolean distinationExist = false;
		LOGGER.debug("::isDestinationExist -> Input Terminal Number : {} ", terminalNumber);
		if (ValidationUtil.isValidDestination(terminalNumber)) {

			List<Destination> destinations = destinationRepository.findByTerminalNumberAndTerminalStatus(
					Integer.parseInt(terminalNumber), AppConstants.TERMINAL_STATUS_ADDED);

			distinationExist = (!destinations.isEmpty());
		}
		LOGGER.debug("::isDestinationExist ->  Terminal Number Exist ? : {} ", distinationExist);
		return distinationExist;
	}
}
