package com.fedex.ziptodest.iseries.configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;

import com.fedex.ziptodest.iseries.service.EmbeddedServerPayloadService;

import redis.embedded.RedisServer;
import redis.embedded.RedisServerBuilder;

@Configuration
@Profile("lcl")
public class RedisServerConfig {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisServerConfig.class);

	private RedisServer redisServer;
	
	@Value("${iseries.redis.port:6376}")
	private Integer redisPort;

	@Value("${iseries.redis.hostname:localhost}")
	private String redisHostName;
	
	@Autowired
	EmbeddedServerPayloadService embeddedServerPayloadService;
	
	@Autowired 
	@Qualifier("iseriesJedisConnectionFactory")
	JedisConnectionFactory jedisConnectionFactory;
	
	@PostConstruct
	public void init() {
		LOGGER.info("iSeries Redis Host : {}", redisHostName);
		LOGGER.info("iSeries Redis Port : {}", redisPort);
		jedisConnectionFactory.setHostName(redisHostName);
		jedisConnectionFactory.setPort(redisPort);
		redisServer = new RedisServerBuilder().port(redisPort).setting("maxmemory 256M").build();
		redisServer.start();
		LOGGER.info("iSeries  Embedded Redis Server Started....");
		embeddedServerPayloadService.init();
	}

	@PreDestroy
	public void destroy() {
		redisServer.stop();
		LOGGER.info("iSeries  Embedded Redis Server Stopped.");
	}
	
}