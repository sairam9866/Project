package com.fedex.ziptodest.iseries.model;

public class State implements Comparable<State> {

	private String stateName;
	private int code;

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public State() {
		/**
		 * Default Constructor
		 */
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + code;
		result = prime * result + ((stateName == null) ? 0 : stateName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		State other = (State) obj;
		if (code != other.code)
			return false;
		if (stateName == null) {
			if (other.stateName != null)
				return false;
		} else if (!stateName.equals(other.stateName)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "State [stateName=" + stateName + ", code=" + code + "]";
	}

	@Override
	public int compareTo(State stateCompare) {
		return this.stateName.compareTo(stateCompare.getStateName());
	}

}
