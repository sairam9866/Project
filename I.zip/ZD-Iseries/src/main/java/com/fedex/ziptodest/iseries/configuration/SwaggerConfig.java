package com.fedex.ziptodest.iseries.configuration;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicate;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

//@Configuration
//@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket iSeriesApi() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("public-api").apiInfo(apiInfo()).select()
				.apis(RequestHandlerSelectors.basePackage("com.fedex.ziptodest.iseries.controller")).build();
	}

	
	@SuppressWarnings("unused")
	private Predicate<String> postPaths() {
		return regex("/network/get");
	}

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("ISeries API").description("ISeries have NETWORK API and STATEPROVINCE API")
				.version("1.0").build();
	}

	/**
	 * 
	 * if one controller is there we add only postPaths() all endpoints comes
	 * under this. if more than one controller have we need to distinguish so we
	 * added stateProvincePaths().
	 * 
	 */
	@SuppressWarnings("unused")
	private Predicate<String> stateProvincePaths() {
		return regex("/state-province/get");
	}
}
