package com.fedex.ziptodest.iseries.service;

public interface DestinationService {
	public boolean isDestinationExist(String desinationCode);
}

