package com.fedex.ZDCache.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.fedex.ZDCache.utils.ConfigFileReader;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/it/resources/features",
tags={"@Get"},
plugin = {"pretty", "html:target/cucumber-reports"},
monochrome=true
)
public class CucumberIntegrationTest {
	
	static String timeStamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	static String reportpath = null;
	
	@BeforeClass
	public static void setUp() throws IOException {

		ConfigFileReader.loadProperties();
		ConfigFileReader.writeProperties();
	}

	@AfterClass
	public static void writeExtentReport() { 
		
	}
}