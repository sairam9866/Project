package com.fedex.ZDCache.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class ConfigFileReader {

	public String reportConfigPath = System.getProperty("user.dir")+ "\\src\\it\\resources\\configs\\extent-config.xml";
	public static String envFilePath = System.getProperty("user.dir") + "\\src\\it\\resources\\configs\\env.properties";
	public static String dataFilePath = System.getProperty("user.dir") +  "\\src\\it\\resources\\configs\\data.properties";
	
	public static Properties RedisLoadAPIProp;
	public static Properties RedisAPIPropWrite;
	
	@SuppressWarnings("unused")
	public String getReportConfigPath() {

		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException("Report Config Path not specified in the Configuration :reportConfigPath");
	}

	public static void loadProperties() {

		RedisLoadAPIProp = new Properties();
		try {
			InputStream fis = new FileInputStream(envFilePath);
			RedisLoadAPIProp.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	
	public static void writeProperties() {
		
		
		try {
			OutputStream output = new FileOutputStream(dataFilePath);
			RedisAPIPropWrite = new Properties();
			RedisAPIPropWrite.store(output, null);
		}catch (Exception e) {
			e.printStackTrace();
		}

	}
}
