package com.fedex.ZDCache.cucumber;


import org.fedex.zd.cache.ZipToDestCacheApp;
import org.junit.runner.RunWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = ZipToDestCacheApp.class, webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ActiveProfiles("lcl")
public abstract class SpringBootBaseIntegrationTest {

	  // @LocalServerPort
	   //protected int port = 8080;

}