package org.ZD.Cache;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.fedex.zd.cache.controller.ZipToDestController;
import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.service.MasterZDOracleFacilityService;
import org.fedex.zd.cache.service.MasterZDOracleZipToDestService;
import org.fedex.zd.cache.service.ZipToDestService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ZipToDestControllerTest {

	@InjectMocks
	ZipToDestController zipToDestController;
	
	@Mock
	MasterZDOracleFacilityService masterZDOracleFacilityService;

	@Mock
	ZipToDestService zipToDestService;
	
	@Mock
	MasterZDOracleZipToDestService masterzipToDestService;
	

	@Test
	public void saveZipTodestDataToRedis() {
		RenderRedisResponse response= new RenderRedisResponse();
		Mockito.doReturn(response).when(zipToDestService).saveZipTodestDataToRedis();
		zipToDestController.saveZipTodestDataFromOracleToRedis();
		assertEquals(response, response);
	}

	@Test
	public void saveOracleFacilityDataToRedis() {
		RenderRedisResponse response= new RenderRedisResponse();
		Mockito.doReturn(response).when(zipToDestService).saveOracleFacilityDataToRedis();
		zipToDestController.saveOracleFacilityDataToRedis();

	}

	@Test
	public void deleteAllZipToDestRecardsfromRedis() {
		Mockito.doNothing().when(zipToDestService).deleteZipTodestRecordsFromRedis();
		zipToDestController.deleteAllZipToDestRecardsfromRedis();

	}

	@Test
	public void deleteAllFacilityRecardsfromRedis() {
		Mockito.doNothing().when(zipToDestService).deleteAllFacilityRecardsfromRedis();
		zipToDestController.deleteAllFacilityRecardsfromRedis();

	}
	
	@Test
	public void getAllFacilityIds() {
		List<MasterZDOracleFacilityId> facilityIdsList= new ArrayList<>();
		Mockito.doReturn(facilityIdsList).when(masterZDOracleFacilityService).getAllFacilityIds();
		zipToDestController.getAllFacilityIds();

	}
	
	@Test
	public void getAllZipTodestFromOracle() {
		List<MasterZDOracleZipToDestination> zipToDestList= new ArrayList<>();
		Mockito.doReturn(zipToDestList).when(masterzipToDestService).getAllZipTodestFromOracle();
		//zipToDestController.getAllZiptodests();

	}

}