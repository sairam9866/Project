package org.ZD.Cache;

import java.sql.Timestamp;

import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.MasterZDOracleFacilityIdPK;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestinationPK;
import org.fedex.zd.cache.repository.MasterZDRedisZipToDestRepository;
import org.fedex.zd.cache.util.ZipToDestUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ZipToDestUtilTest {

	@InjectMocks
	ZipToDestUtil zipToDestUtil;
	
	MasterZDOracleZipToDestinationPK id;

	@Mock
	MasterZDRedisZipToDestRepository masterZDRedisTransactionalRepository;
	

	@Test
	public void zipToDestOracleDataToRedis() {

		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);
		MasterZDOracleZipToDestination masterZDOracleZipToDestination=new MasterZDOracleZipToDestination();
		
		MasterZDOracleZipToDestinationPK masterZDOracleZipToDestinationPK=new MasterZDOracleZipToDestinationPK();
		masterZDOracleZipToDestination.setDestination(458);
		masterZDOracleZipToDestination.setState("UAS");
		masterZDOracleZipToDestination.setLastUpdateBy("USER");
		masterZDOracleZipToDestination.setLastUpdateTimestamp(timestamp);
		masterZDOracleZipToDestinationPK.setCountryCode(125);
		masterZDOracleZipToDestinationPK.setNetwork("LPN");
		masterZDOracleZipToDestinationPK.setZipCode("458711");
		masterZDOracleZipToDestination.setId(masterZDOracleZipToDestinationPK);
		
	//Mockito.doReturn(masterRedisZipToDestination).when()
		zipToDestUtil.zipToDestOracleDataToRedis(masterZDOracleZipToDestination);

	}

	@Test
	public void faclityOracleDataToRedis(){
		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);
		MasterZDOracleFacilityId masterZDOracleFacilityId= new MasterZDOracleFacilityId();
		MasterZDOracleFacilityIdPK masterZDOracleFacilityIdPK=new MasterZDOracleFacilityIdPK();
		masterZDOracleFacilityId.setState("US");
		masterZDOracleFacilityId.setTransactionType('Y');
		masterZDOracleFacilityId.setUuId("test");
		masterZDOracleFacilityIdPK.setEffectiveDateTimestamp(timestamp);
		masterZDOracleFacilityIdPK.setNetwork("LPN");
		masterZDOracleFacilityIdPK.setZipCode("1452");
		masterZDOracleFacilityIdPK.setFacilityId(455);
		masterZDOracleFacilityId.setFacilityIdPK(masterZDOracleFacilityIdPK);
		
		zipToDestUtil.faclityOracleDataToRedis(masterZDOracleFacilityId);
	}
	
}


