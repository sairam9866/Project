--Insert into TRX_ZIP_TO_DEST_DEMO (NETWORK,COUNTRY_CD,ZIP_CD,STATE,DEST_TERMINAL,CREATION_DATE_TMSTP,CREATION_USER,CURRENT_FLG) values ('FHDL',840,'16764000000','PA',3158,CURRENT_TIMESTAMP,'Rajiv','Y');

--Insert into TRX_ZIP_TO_DEST_DEMO (ID,NETWORK,COUNTRY_CD) values ('10','FHDL',124);


Insert into TRX_ZIP_TO_DEST_DEMO (ID,NETWORK,COUNTRY_CD,ZIP_CD,DEST_TERMINAL,STATE ,CURRENT_FLG,CREATION_USER,TRANS_TYPE, PROCESSED, CANCELLED,UUID, CANCELLED_USER,EFFECTIVE_DT,PROCESSED_DT,CANCELLED_DT ) values ('1','FHDL',124,'12345','11','PA', 'Y','Rajiv', 'A','Y', 'N', 'AA11SS11',' ','2019-12-31.20:10:10' , '2020-01-01.20:10:10','2021-01-01.20:10:10');

Insert into TRX_ZIP_TO_DEST_DEMO (ID,NETWORK,COUNTRY_CD,ZIP_CD,DEST_TERMINAL,STATE ,CURRENT_FLG,CREATION_USER,TRANS_TYPE, PROCESSED, CANCELLED,UUID, CANCELLED_USER ,EFFECTIVE_DT,PROCESSED_DT,CANCELLED_DT) values ('2','FHDL',124,'22222','11','PA', 'Y','Anoop', 'A','Y', 'N', 'AA11bb11',' ' ,'2020-12-31.20:10:10', '2020-01-01.20:10:10','2021-01-01.20:10:10' );

Insert into TRX_ZIP_TO_DEST_DEMO (ID,NETWORK,COUNTRY_CD,ZIP_CD,DEST_TERMINAL,STATE ,CURRENT_FLG,CREATION_USER,TRANS_TYPE, PROCESSED, CANCELLED,UUID, CANCELLED_USER,EFFECTIVE_DT ,PROCESSED_DT,CANCELLED_DT) values ('3','FHDL',124,'33333','11','PA', 'Y','Prabhakar', 'A','Y', 'N', 'AA11cc11',' ' ,'2020-12-31.20:10:10', '2020-01-01.20:10:10','2021-01-01.20:10:10' );

--Insert into TRX_ZIP_TO_DEST_DEMO (ID,NETWORK,COUNTRY_CD,ZIP_CD,DEST_TERMINAL,STATE ,CURRENT_FLG,CREATION_USER,TRANS_TYPE, PROCESSED, CANCELLED,UUID, CANCELLED_USER ,EFFECTIVE_DT) values ('4','FHDL',124,'44444','11','PA', 'Y','Krishna', 'A','Y', 'N', 'AA11dd11','' ,'2020-12-31.20:10:10' );
--
--Insert into TRX_ZIP_TO_DEST_DEMO (ID,NETWORK,COUNTRY_CD,ZIP_CD,DEST_TERMINAL,STATE ,CURRENT_FLG,CREATION_USER,TRANS_TYPE, PROCESSED, CANCELLED,UUID, CANCELLED_USER,EFFECTIVE_DT ) values ('5','FHDL',124,'55555','11','PA', 'Y','Rajiv', 'A','Y', 'N', 'AA11ee11',' ' ,'2020-12-31.20:10:10' );

insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0A', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0B0A0', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0B0A1', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0B1C3', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0B1C4', 'NF', 6012, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0K', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0C0A2', 'NF', 6012, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0C0A4', 'NF', 6012, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D0E5', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D0A1', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D0A5', 'NF', 6012, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D0A2', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D0A4', 'NF', 6012, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D0A3', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A8', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A1', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A3', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A2', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A6', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A4', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A5', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0D1A7', 'NF', 6013, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0J', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 124, 'A0L', 'NF', 6011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '11355000000', 'MA', 0011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01356000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01357000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01358000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01365000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01366000000', 'PA', 0011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01367000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01368000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01369000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01370000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01371000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('LPN', 840, '01372000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01356000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01357000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01358000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01365000000', 'MA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01366000000', 'PA', 0011, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01367000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01368000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01369000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01370000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01371000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '01372000000', 'PA', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXG', 840, '07054000000', 'NJ', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXO', 840, '07055000000', 'NJ', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXO', 840, '07056000000', 'NJ', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('FXO', 840, '07057000000', 'NJ', 0034, CURRENT_TIMESTAMP, 'FedexUser');
insert into zip_to_dest (network, country_cd, zip_cd, state, dest_terminal, last_update_tmstp, last_update_user) values ('PPP', 840, '07058000000', 'NJ', 0034, CURRENT_TIMESTAMP, 'FedexUser');

insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXG', 1241,'CA', '01376', 'D', TIMESTAMP '2019-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456780' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXG', 1241,'CA', '01378', 'A', TIMESTAMP '2019-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456781' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXG', 1241,'CA', '01379', 'A', TIMESTAMP '2019-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456782' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXO', 1241,'CA', '01380', 'D', TIMESTAMP '2020-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456783' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXO', 1241,'CA', '01381', 'A', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456784' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXO', 1242,'CA', '01382', 'A', TIMESTAMP '2020-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456785' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXO', 1243,'PA', '01383', 'D', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456786' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('FXO', 1241,'PA', '01384', 'A', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456787' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('LPN', 1241,'PA', '01385', 'A', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456788' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('LPN', 1241,'PA', '01386', 'D', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456789' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('LPN', 1246,'PA', '01387', 'A', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456790' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('PPP', 1241,'PA', '01388', 'D', TIMESTAMP '2017-11-03 21:22:23', 'MPHASIS-600012-FEDEX-BANGALORE-123456791' );
insert into ZD_FACILITY_DELTA(NETWORK, FACILITY_ID, STATE, ZIP_CD, TRANS_TYPE, EFFECTIVE_DATE_TMSTP, UUID) values('CHE', 1241,'PA', '01388', 'D', TIMESTAMP '2017-11-03 21:22:23', '--CHECKING-CHECKING-CHECKING-CHECKING--' );

insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXA',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXB',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXC',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXD',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXE',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXF',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXG',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXH',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXI',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXJ',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXK',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXL',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXM',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXN',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXO',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXP',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXQ',TIMESTAMP '2019-11-03 21:22:23');
insert into ZIP_TO_DEST_HAS_DELTA(NETWORK,LAST_UPDATE_TMSTP) values('FXR',TIMESTAMP '2019-11-03 21:22:23');