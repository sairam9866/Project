DROP TABLE IF EXISTS TRX_ZIP_TO_DEST_DEMO;

create table TRX_ZIP_TO_DEST_DEMO
( 
		ID varchar(15),
      NETWORK varchar(5) not null,
      COUNTRY_CD numeric(3) not null,
      ZIP_CD varchar(15)not null,
	  DEST_TERMINAL varchar(6) not null,
	  STATE varchar(2),
	  CURRENT_FLG varchar(2),
	  CREATION_USER varchar(20),
	  TRANS_TYPE varchar(2),
	  PROCESSED varchar(2),
	  CANCELLED varchar(2),
	  UUID varchar(20),
	  CANCELLED_USER varchar(20),
	  
 	  EFFECTIVE_DT varchar(40),
	  PROCESSED_DT varchar(40),
	  CANCELLED_DT varchar(40)
);

/* Distribution table*/
create table if not exists zip_to_dest
( 
network varchar(5) not null, 
country_cd numeric(3) not null,
zip_cd varchar(11) not null, 
state char(2), 
dest_terminal numeric(10), 
last_update_tmstp timestamp, 
last_update_user varchar(32), 

primary key (network, country_cd, zip_cd)
);


/* Transaction table - Master 
create table if not exists TRX_ZIP_TO_DEST
( 
      NETWORK varchar(5) not null, 
      COUNTRY_CD numeric(3) not null,
      ZIP_CD varchar(11) NOT NULL,
      STATE char(2) NOT NULL,
      DEST_TERMINAL numeric(10) NOT NULL,
      CREATION_DATE_TMSTP timestamp,
      CREATION_USER varchar(32),
      EFFECTIVE_DATE_TMSTP timestamp,
      PROCESSED_FLG boolean NOT NULL,
 	  CURRENT_FLG boolean NOT NULL,
 	  UUID varchar(40),
 	  
    primary key(NETWORK,COUNTRY_CD,ZIP_CD,EFFECTIVE_DATE_TMSTP)
);*/

create table if not exists ZD_FACILITY_DELTA
(
	NETWORK varchar(5) not null, 
	FACILITY_ID numeric(4) not null,
	STATE varchar(2) not null,
	ZIP_CD varchar(6) NOT NULL,
	TRANS_TYPE char(1) not null,
	EFFECTIVE_DATE_TMSTP timestamp not null,
	UUID varchar(40) ,
	
	primary key(NETWORK,FACILITY_ID,ZIP_CD,EFFECTIVE_DATE_TMSTP)

);

CREATE TABLE IF NOT EXISTS ZIP_TO_DEST_HAS_DELTA(
	NETWORK VARCHAR(5) NOT NULL,
	LAST_UPDATE_TMSTP TIMESTAMP NOT NULL,
	PRIMARY KEY(NETWORK));