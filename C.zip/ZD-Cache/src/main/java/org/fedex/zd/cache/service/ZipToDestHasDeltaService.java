package org.fedex.zd.cache.service;

import java.util.List;

import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.model.ZipToDestHasDeltaOracle;

public interface ZipToDestHasDeltaService {
	public List<ZipToDestHasDeltaOracle> getAllZipToDestHasDeltaRecordsFromOracle();
	public RenderRedisResponse saveZipToDestHasDeltaOracleDataToRedis();

}
