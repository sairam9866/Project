package org.fedex.zd.cache.repository;

import java.util.List;
import java.util.Set;

import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;

@Repository("transactionalRepository")
public interface ZDRedisTransactionalRepository extends CrudRepository<ZDRedisTransactional, String>, QueryByExampleExecutor<ZDRedisTransactional> {
	


	public List<ZDRedisTransactional> findByCurrentAndProcessedAndCancelled(String current, String processed, String Cancelled);

	public List<ZDRedisTransactional> findByNetworkAndZipCode(String network, String zipCode);
	
	public List<ZDRedisTransactional> findByNetwork(String network);
	
	public List<ZDRedisTransactional> selectByEffectiveDate(Long from, Long to);
	
	public List<ZDRedisTransactional> selectByNetworkAndEffectiveDate(String network, Long from, Long to);
	
	public List<ZDRedisTransactional> selectByNetworkAndProcessedDate(String network, Long from, Long to);
	
	public List<ZDRedisTransactional> scanTransactionByNetwork(String network);
	
	public List<String> scanByZipcodeRange(String zipFrom, String zipTo);
	
	public List<ZDRedisTransactional> scanByNetworkAndZipCodeRange(String network, String zipFrom, String zipTo);

	public default List<ZDRedisTransactional> getTransactionsByCurrentFlag(String currentFlag) {
		ExampleMatcher exampleMatcher = ExampleMatcher.matching().withMatcher("current",
				GenericPropertyMatcher.of(StringMatcher.EXACT));
		ZDRedisTransactional test = new ZDRedisTransactional();
		
		test.setCurrent(currentFlag);
		Example<ZDRedisTransactional> example = Example.of(test, exampleMatcher);
		List<ZDRedisTransactional> currentTrans = (List<ZDRedisTransactional>) findAll(example);
		return currentTrans;
	}

	public default List<ZDRedisTransactional> getTransactionByNetworkAndZipCode(String network, String zipCode) {
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withMatcher("network", GenericPropertyMatcher.of(StringMatcher.EXACT));				

		ZDRedisTransactional test = new ZDRedisTransactional();
		test.setNetwork(network);		
		Example<ZDRedisTransactional> example = Example.of(test, exampleMatcher);
		return (List<ZDRedisTransactional>) findAll(example);
	}

}
