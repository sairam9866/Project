package org.fedex.zd.cache.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TRX_ZIP_TO_DEST_DEMO")
public class ZDOracleTransactional  implements Serializable{

	private static final long serialVersionUID = 1234567897847L;

	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "NETWORK")
	private String network;

	@Column(name = "COUNTRY_CD")
	private Integer countryCode;

	@Column(name = "ZIP_CD")
	private String zipCode;

	@Column(name = "DEST_TERMINAL")
	private String destinationTerminal;

	@Column(name = "STATE")
	private String state;

	@Column(name = "CURRENT_FLG")
	private String current;

	@Column(name = "CREATION_USER")
	private String createdBy;

	@Column(name = "TRANS_TYPE")
	private String transactionType;

	@Column(name = "PROCESSED")
	private String processed;

	@Column(name = "CANCELLED")
	private String cancelled;

	@Column(name = "UUID")
	private String uuid;

	@Column(name = "CANCELLED_USER")
	private String cancelledBy;

	@Column(name = "EFFECTIVE_DT")
	private String effectiveDateTime;

	// @Column(name = "CREATED_DT")
	// private Long createdDateTime;

	@Column(name = "PROCESSED_DT")
	private String processedDateTime;

	@Column(name = "CANCELLED_DT")
	private String cancelledDateTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getDestinationTerminal() {
		return destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCurrent() {
		return current;
	}

	public void setCurrent(String current) {
		this.current = current;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getProcessed() {
		return processed;
	}

	public void setProcessed(String processed) {
		this.processed = processed;
	}

	public String getCancelled() {
		return cancelled;
	}

	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public String getEffectiveDateTime() {
		return effectiveDateTime;
	}

	public void setEffectiveDateTime(String effectiveDateTime) {
		this.effectiveDateTime = effectiveDateTime;
	}

	// public Long getCreatedDateTime() {
	// return createdDateTime;
	// }
	//
	// public void setCreatedDateTime(Long createdDateTime) {
	// this.createdDateTime = createdDateTime;
	// }

	public String getProcessedDateTime() {
		return processedDateTime;
	}

	public void setProcessedDateTime(String processedDateTime) {
		this.processedDateTime = processedDateTime;
	}

	public String getCancelledDateTime() {
		return cancelledDateTime;
	}

	public void setCancelledDateTime(String cancelledDateTime) {
		this.cancelledDateTime = cancelledDateTime;
	}

}
