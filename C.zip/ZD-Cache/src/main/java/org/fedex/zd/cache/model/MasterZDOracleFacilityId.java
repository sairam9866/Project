package org.fedex.zd.cache.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ZD_FACILITY_DELTA")
public class MasterZDOracleFacilityId implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MasterZDOracleFacilityIdPK facilityIdPK;

	@Column(name = "TRANS_TYPE")
	private char transactionType;

	@Column(name = "UUID")
	private String uuId;

	@Column(name = "STATE")
	private String state;

	public MasterZDOracleFacilityId(MasterZDOracleFacilityIdPK facilityIdPK, char transactionType, String uuId, String state) {
		this.facilityIdPK = facilityIdPK;
		this.transactionType = transactionType;
		this.uuId = uuId;
		this.state = state;
	}

	public MasterZDOracleFacilityId() {
	}

	public MasterZDOracleFacilityIdPK getFacilityIdPK() {
		return facilityIdPK;
	}

	public void setFacilityIdPK(MasterZDOracleFacilityIdPK facilityIdPK) {
		this.facilityIdPK = facilityIdPK;
	}

	public char getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}

	public String getUuId() {
		return uuId;
	}

	public void setUuId(String uuId) {
		this.uuId = uuId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
}
