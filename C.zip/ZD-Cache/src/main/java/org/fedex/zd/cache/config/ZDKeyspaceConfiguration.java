package org.fedex.zd.cache.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.convert.KeyspaceConfiguration;

public class ZDKeyspaceConfiguration extends KeyspaceConfiguration {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZDKeyspaceConfiguration.class);

	// @Value("${spring.profiles.active:Unknown}")
	private String keyspace;

	public ZDKeyspaceConfiguration(String keyspace) {
		LOGGER.info("ZDKeyspaceConfiguration Construnctor - keyspace : {}", keyspace);
		this.keyspace = keyspace;
	}

	public String getKeyspace() {
		return keyspace;
	}

	public void setKeyspace(String keyspace) {
		this.keyspace = keyspace;
	}

	@Override
	public boolean hasSettingsFor(Class<?> type) {
		return true;
	}

	@Override
	public KeyspaceSettings getKeyspaceSettings(Class<?> type) {
		LOGGER.info("getKeyspaceSettings : Keyspace : {}", getKeyspace());
		String typeName = type.getSimpleName().toUpperCase();
		KeyspaceSettings settings = new KeyspaceSettings(type, getKeyspace().toUpperCase() +"-"+ typeName);
		return settings;
	}


}
