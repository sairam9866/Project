package org.fedex.zd.cache.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * 
 * @author 3818669
 *
 */
@Entity
@Table(name = "ZIP_TO_DEST_HAS_DELTA")
public class ZipToDestHasDeltaOracle implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8639927630636416281L;
	
	@Id
	@NotNull
	@Column(name = "network")
	private String network;
	
	@Column(name = "last_update_tmstp")
	private Timestamp lastUpdateTimestamp;

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public Timestamp getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	@Override
	public String toString() {
		return "ZipToDestHasDelta [network=" + network + ", lastUpdateTimestamp=" + lastUpdateTimestamp + "]";
	}	
}
