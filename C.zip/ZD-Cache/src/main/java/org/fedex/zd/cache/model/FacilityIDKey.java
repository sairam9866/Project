package org.fedex.zd.cache.model;

public interface FacilityIDKey {
	public void buildKey();

}