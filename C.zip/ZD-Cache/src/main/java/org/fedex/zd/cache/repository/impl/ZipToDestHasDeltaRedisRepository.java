package org.fedex.zd.cache.repository.impl;

import org.fedex.zd.cache.model.ZipToDestHasDeltaRedis;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ZipToDestHasDeltaRedisRepository extends CrudRepository<ZipToDestHasDeltaRedis, String> {

}
