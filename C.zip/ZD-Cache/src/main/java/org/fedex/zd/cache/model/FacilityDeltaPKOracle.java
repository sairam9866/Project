package org.fedex.zd.cache.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * @author 3818669
 *
 */
@Embeddable
public class FacilityDeltaPKOracle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "NETWORK")
	private String network;

	@Column(name = "FACILITY_ID")
	private int facilityId;

	@Column(name = "ZIP_CD")
	private String zipCode;

	@Column(name = "EFFECTIVE_DATE_TMSTP")
	private Timestamp effectiveDateTimestamp;	

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Timestamp getEffectiveDateTimestamp() {
		return effectiveDateTimestamp;
	}

	public void setEffectiveDateTimestamp(Timestamp effectiveDateTimestamp) {
		this.effectiveDateTimestamp = effectiveDateTimestamp;
	}

	@Override
	public String toString() {
		return "FacilityIdPK [network=" + network + ", facilityId=" + facilityId + ", zipCode=" + zipCode
				+ ", effectiveDateTimestamp=" + effectiveDateTimestamp + "]";
	}
}
