package org.fedex.zd.cache.model;

public class RenderRedisResponse {
	
	public String getNoOfRowsExistsInRedis() {
		return noOfRowsExistsInRedis;
	}
	public void setNoOfRowsExistsInRedis(String noOfRowsExistsInRedis) {
		this.noOfRowsExistsInRedis = noOfRowsExistsInRedis;
	}
	public String getNoOfnewRecordsInsertedInRedis() {
		return noOfnewRecordsInsertedInRedis;
	}
	public void setNoOfnewRecordsInsertedInRedis(String noOfnewRecordsInsertedInRedis) {
		this.noOfnewRecordsInsertedInRedis = noOfnewRecordsInsertedInRedis;
	}
	public String getNoOfRecordsLoadedFromOracle() {
		return noOfRecordsLoadedFromOracle;
	}
	public void setNoOfRecordsLoadedFromOracle(String noOfRecordsLoadedFromOracle) {
		this.noOfRecordsLoadedFromOracle = noOfRecordsLoadedFromOracle;
	}
	private String noOfRowsExistsInRedis;
	private String noOfnewRecordsInsertedInRedis;
	private String noOfRecordsLoadedFromOracle;
	
	@Override
	public String toString() {
		return "RenderRedisResponse [noOfRowsExistsInRedis=" + noOfRowsExistsInRedis
				+ ", noOfnewRecordsInsertedInRedis=" + noOfnewRecordsInsertedInRedis + ", noOfRecordsLoadedFromOracle="
				+ noOfRecordsLoadedFromOracle + "]";
	}

	
	
}
