package org.fedex.zd.cache.repository;

import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.MasterZDOracleFacilityIdPK;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ZDOracleFacilityrepository extends CrudRepository<MasterZDOracleFacilityId, MasterZDOracleFacilityIdPK> {

}
