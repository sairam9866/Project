package org.fedex.zd.cache.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Id;

import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

@RedisHash("ZipToDest")
public class MasterRedisZipToDestination implements Serializable,ZDRedisTransactionalKey {

	private static final long serialVersionUID = -8214873653043928399L;

	@Id
	private String id;

	@Indexed
	private String network;

	@Indexed
	private int countryCode;

	@Indexed
	private String zipCode;

	private String state;

	private int destination;

	private Long lastUpdateTimestamp;

	private String lastUpdateBy;

	public MasterRedisZipToDestination() {
	}

	public MasterRedisZipToDestination(String id, String network, int countryCode, String zipCode, String state, int destination,
			Long lastUpdateTimestamp, String lastUpdateBy) {
		this.id = id;
		this.network = network;
		this.countryCode = countryCode;
		this.zipCode = zipCode;
		this.state = state;
		this.destination = destination;
		this.lastUpdateTimestamp = lastUpdateTimestamp;
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		  this.id = id;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getDestination() {
		return destination;
	}

	public void setDestination(int destination) {
		this.destination = destination;
	}

	public Long getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Long lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + countryCode;
		result = prime * result + destination;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastUpdateBy == null) ? 0 : lastUpdateBy.hashCode());
		result = prime * result + ((lastUpdateTimestamp == null) ? 0 : lastUpdateTimestamp.hashCode());
		result = prime * result + ((network == null) ? 0 : network.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MasterRedisZipToDestination other = (MasterRedisZipToDestination) obj;
		if (countryCode != other.countryCode)
			return false;
		if (destination != other.destination)
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastUpdateBy == null) {
			if (other.lastUpdateBy != null)
				return false;
		} else if (!lastUpdateBy.equals(other.lastUpdateBy))
			return false;
		if (lastUpdateTimestamp == null) {
			if (other.lastUpdateTimestamp != null)
				return false;
		} else if (!lastUpdateTimestamp.equals(other.lastUpdateTimestamp))
			return false;
		if (network == null) {
			if (other.network != null)
				return false;
		} else if (!network.equals(other.network))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (zipCode == null) {
			if (other.zipCode != null)
				return false;
		} else if (!zipCode.equals(other.zipCode))
			return false;
		return true;
	}

	public void buildKey() {
		 setId(this.network + this.countryCode + this.zipCode);
	}

}
