package org.fedex.zd.cache.repository;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.util.ZipToDestConstants;
import org.fedex.zd.cache.util.ZipToDestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisZSetCommands;
import org.springframework.data.redis.connection.RedisZSetCommands.Range;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Repository;

@Repository("zdMasterRepository")
public class ZDMasterRepository implements ZDRedisTransactionalRepository {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZDMasterRepository.class);

	@Autowired
	@Qualifier("transactionalRepository")
	ZDRedisTransactionalRepository zipToDestRepository;

	@Autowired
	ZipToDestUtil zipToDestUtil;
	
	@Value(value = "${keyspace}")
	private String keyspace;

	// @Autowired
	// private RedisTemplate<String, ZDRedisTransactional> redisTemplate;

	@Autowired
	private RedisTemplate<String, String> redisStringTemplate;

	@Resource(name = "redisTemplate")
	private HashOperations<String, String, ZDRedisTransactional> hashOperations;

	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZDRedisTransactional> zSetOperations;

	private ZSetOperations<String, String> zipSetOperations;

	@PostConstruct
	public void init() {
		// hashOperations = redisTemplate.opsForHash();
		zipSetOperations = redisStringTemplate.opsForZSet();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ZDRedisTransactional save(ZDRedisTransactional entity) {

		zSetOperations.add(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY, entity, entity.getEffectiveDateTime());

		zipSetOperations.add(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_ZIP_KEY, entity.getZipCode(), ZipToDestConstants.ZIP_CODE_DEFAULT_SCORE);		

		return zipToDestRepository.save(entity);
	}

	@Override
	public <S extends ZDRedisTransactional> Iterable<S> saveAll(Iterable<S> entities) {

		return zipToDestRepository.saveAll(entities);
	}

	@Override
	public Optional<ZDRedisTransactional> findById(String id) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findById(id);
	}

	@Override
	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return zipToDestRepository.existsById(id);
	}

	@Override
	public Iterable<ZDRedisTransactional> findAll() {
		// TODO Auto-generated method stub
		return zipToDestRepository.findAll();
	}

	@Override
	public Iterable<ZDRedisTransactional> findAllById(Iterable<String> ids) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findAllById(ids);
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return zipToDestRepository.count();
	}

	@Override
	public void deleteById(String id) {
		Optional<ZDRedisTransactional> zipToDest = zipToDestRepository.findById(id);
		if(zipToDest.isPresent())	delete(zipToDest.get());
	}

	@Override
	public void delete(ZDRedisTransactional entity) {
		zipToDestRepository.delete(entity);
		zSetOperations.remove(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY, entity);
		zipSetOperations.remove(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_ZIP_KEY, entity.getZipCode());

	}

	@Override
	public void deleteAll(Iterable<? extends ZDRedisTransactional> entities) {
		zipToDestRepository.deleteAll(entities);

	}

	@Override
	public void deleteAll() {
		zipToDestRepository.deleteAll();
		redisStringTemplate.delete(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY);
		redisStringTemplate.delete(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_ZIP_KEY);

	}

	@Override
	public <S extends ZDRedisTransactional> Optional<S> findOne(Example<S> example) {

		return zipToDestRepository.findOne(example);
	}

	@Override
	public <S extends ZDRedisTransactional> Iterable<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findAll(example);
	}

	@Override
	public <S extends ZDRedisTransactional> Iterable<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findAll(example, sort);
	}

	@Override
	public <S extends ZDRedisTransactional> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findAll(example, pageable);
	}

	@Override
	public <S extends ZDRedisTransactional> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return zipToDestRepository.count(example);
	}

	@Override
	public <S extends ZDRedisTransactional> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return zipToDestRepository.exists(example);
	}

	@Override
	public List<ZDRedisTransactional> findByCurrentAndProcessedAndCancelled(String current, String processed,
			String Cancelled) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findByCurrentAndProcessedAndCancelled(current, processed, Cancelled);
	}

	@Override
	public List<ZDRedisTransactional> findByNetworkAndZipCode(String network, String zipCode) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findByNetworkAndZipCode(network, zipCode);
	}

	@Override
	public List<ZDRedisTransactional> selectByEffectiveDate(Long from, Long to) {
		Set<ZDRedisTransactional> list = zSetOperations.rangeByScore(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY,
				from, to);
		return new ArrayList<>(list);
	}

	@Override
	public List<ZDRedisTransactional> selectByNetworkAndEffectiveDate(String network, Long from, Long to) {
		Set<ZDRedisTransactional> lists = (Set<ZDRedisTransactional>) zSetOperations
				.rangeByScore(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY, from, to);

		List<ZDRedisTransactional> zipToDestList = zipToDestRepository.findByNetwork(network);

		Instant startTime = Instant.now();

		List<ZDRedisTransactional> output = new ArrayList<>();
		for (ZDRedisTransactional zipToDest1 : lists) {
			for (ZDRedisTransactional zipToDest2 : zipToDestList) {
				if (zipToDest1.getNetwork().equals(zipToDest2.getNetwork())
						&& zipToDest1.getEffectiveDateTime().equals(zipToDest2.getEffectiveDateTime())) {
					output.add(zipToDest1);
				}
			}
		}

		Instant finishTime = Instant.now();
		long elapsedTime = Duration.between(startTime, finishTime).toMillis();
		LOGGER.info("Elapsed Time : {} in millis", elapsedTime);
		return output;
	}

	@Override
	public List<ZDRedisTransactional> selectByNetworkAndProcessedDate(String network, Long from, Long to) {
		Set<ZDRedisTransactional> lists = (Set<ZDRedisTransactional>) zSetOperations
				.rangeByScore(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY, from, to);

		Instant startTime = Instant.now();

		List<ZDRedisTransactional> output = lists.stream().filter(trans -> trans.getNetwork().equals(network))
				.collect(Collectors.toList());

		Instant finishTime = Instant.now();
		long elapsedTime = Duration.between(startTime, finishTime).toMillis();
		LOGGER.info("Elapsed Time : {} in millis", elapsedTime);

		return output;
	}

	@Override
	public List<ZDRedisTransactional> findByNetwork(String network) {
		// TODO Auto-generated method stub
		return zipToDestRepository.findByNetwork(network);
	}

	@Override
	public List<ZDRedisTransactional> scanTransactionByNetwork(String network) {
		List<ZDRedisTransactional> list = new LinkedList<>();
		ScanOptions.ScanOptionsBuilder builder = new ScanOptions.ScanOptionsBuilder();
		builder.match("*");

		Cursor<ZSetOperations.TypedTuple<ZDRedisTransactional>> output = zSetOperations
				.scan(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY, builder.build());

		while (output.hasNext()) {
			TypedTuple<ZDRedisTransactional> obj = output.next();
			ZDRedisTransactional trans = obj.getValue();
			if (trans.getNetwork().equals(network)) {
				list.add(trans);
			}
		}
		if(output != null){
			try {
				output.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
		return list;
	}	
	
	@Override
	public List<ZDRedisTransactional> scanByNetworkAndZipCodeRange(String network, String zipFrom, String zipTo){
		List<ZDRedisTransactional> output = new ArrayList<>();	
		
		Set<String> zipCodes = zipSetOperations.rangeByLex(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_ZIP_KEY, Range.range().gte(zipFrom).lte(zipTo));
		
		for(String zipCode : zipCodes){
			output.addAll(findByNetworkAndZipCode(network, zipCode));
		}		
		return output;
	}

	@Override
	public List<String> scanByZipcodeRange(String zipFrom, String zipTo) {
		Set<String> zSetTransactions = zipSetOperations.rangeByLex(keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_ZIP_KEY,
				Range.range().gte(zipFrom).lte(zipTo));

		List<String> output = redisStringTemplate.execute(new RedisCallback<List<String>>() {
			@Override
			public List<String> doInRedis(RedisConnection connection) throws DataAccessException {
				List<String> outputs = new ArrayList<>();
				Set<byte[]> output = connection.zRangeByLex((keyspace + " - " + ZipToDestConstants.APP_TRANSACTION_ZIP_KEY).getBytes(),
						Range.range().gte(zipFrom).lte(zipTo));

				for (byte[] b : output) {
					String val = (String) redisStringTemplate.getHashValueSerializer().deserialize(b);
					outputs.add(val);
				}

				return outputs;
			}
		});

		System.out.println("################## : " + output);

		return new ArrayList<>(zSetTransactions);
	}

}
