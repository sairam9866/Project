package org.fedex.zd.cache.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 
 * @author 3818669
 *
 */
@Entity
@Table(name = "ZD_FACILITY_DELTA")
public class FacilityDeltaOracle implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private FacilityDeltaPKOracle facilityIdPK;

	@Column(name = "TRANS_TYPE")
	private char transactionType;

	@Column(name = "UUID")
	private String uuId;

	@Column(name = "STATE")
	private String state;
	
	public FacilityDeltaPKOracle getFacilityIdPK() {
		return facilityIdPK;
	}

	public void setFacilityIdPK(FacilityDeltaPKOracle facilityIdPK) {
		this.facilityIdPK = facilityIdPK;
	}

	public char getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}

	public String getUuId() {
		return uuId;
	}

	public void setUuId(String uuId) {
		this.uuId = uuId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "FacilityId [facilityIdPK=" + facilityIdPK + ", transactionType=" + transactionType + ", uuId=" + uuId
				+ ", state=" + state + "]";
	}
	
	
}
