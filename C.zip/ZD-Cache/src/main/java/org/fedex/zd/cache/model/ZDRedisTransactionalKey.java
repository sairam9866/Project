package org.fedex.zd.cache.model;

public interface ZDRedisTransactionalKey {
	public void buildKey();
}
