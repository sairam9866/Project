package org.fedex.zd.cache.service;

import java.util.List;

import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;

public interface MasterZDOracleZipToDestService {
  public List<MasterZDOracleZipToDestination> getAllZipTodestFromOracle();
}
