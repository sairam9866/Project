package org.fedex.zd.cache.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.model.ZipToDestHasDeltaOracle;
import org.fedex.zd.cache.model.ZipToDestHasDeltaRedis;
import org.fedex.zd.cache.repository.ZipToDestHasDeltaRepository;
import org.fedex.zd.cache.repository.impl.ZipToDestHasDeltaRedisRepository;
import org.fedex.zd.cache.service.ZipToDestHasDeltaService;
import org.fedex.zd.cache.util.ZipToDestConstants;
import org.fedex.zd.cache.util.ZipToDestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;

@Service
public class ZipToDestHasDeltaServiceImpl implements ZipToDestHasDeltaService {
	int rowsCount;
	int rowsExist;

	@Autowired
	ZipToDestHasDeltaRepository zipToDestHasDeltaRepository;

	@Autowired
	ZipToDestHasDeltaRedisRepository zipToDestHasDeltaRedisRepository;

	@Autowired
	ZipToDestUtil zipToDestUtil;

	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDestHasDeltaRedis> sortedzipToDestHasDeltaSetOperations;

	@Override
	public List<ZipToDestHasDeltaOracle> getAllZipToDestHasDeltaRecordsFromOracle() {
		return (List<ZipToDestHasDeltaOracle>) zipToDestHasDeltaRepository.findAll();
	}

	@Override
	public RenderRedisResponse saveZipToDestHasDeltaOracleDataToRedis() {
		rowsExist = 0;
		rowsCount = 0;

		List<ZipToDestHasDeltaOracle> zipToDestHasDeltaOracleList = (List<ZipToDestHasDeltaOracle>) zipToDestHasDeltaRepository
				.findAll();
		zipToDestHasDeltaOracleList.stream().forEach(zipToDestHasDeltaOracleRecord -> {
			ZipToDestHasDeltaRedis newObject = zipToDestUtil
					.saveZipToDestHasDeltaOracleDataToRedis(zipToDestHasDeltaOracleRecord);

			if (!zipToDestHasDeltaRedisRepository.existsById(newObject.getNetwork())) {
				
				sortedzipToDestHasDeltaSetOperations.add(ZipToDestConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY, newObject,
						newObject.getLastUpdateTimestamp());

				zipToDestHasDeltaRedisRepository.save(newObject);
				rowsCount++;
			} else {
				rowsExist++;
			}
		});
		RenderRedisResponse output = new RenderRedisResponse();
		output.setNoOfnewRecordsInsertedInRedis(String.valueOf(rowsCount));
		output.setNoOfRowsExistsInRedis(String.valueOf(rowsExist));
		output.setNoOfRecordsLoadedFromOracle(String.valueOf(zipToDestHasDeltaRepository.count()));
		return output;
	}
}
