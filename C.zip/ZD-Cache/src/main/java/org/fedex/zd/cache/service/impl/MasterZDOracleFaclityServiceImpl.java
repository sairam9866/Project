package org.fedex.zd.cache.service.impl;

import java.util.List;

import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.repository.ZDOracleFacilityrepository;
import org.fedex.zd.cache.service.MasterZDOracleFacilityService;
import org.springframework.beans.factory.annotation.Autowired;

public class MasterZDOracleFaclityServiceImpl implements MasterZDOracleFacilityService {

	@Autowired
	ZDOracleFacilityrepository zDOracleFacilityrepository;
	
	@Override
	public List<MasterZDOracleFacilityId> getAllFacilityIds() {
		return (List<MasterZDOracleFacilityId>)zDOracleFacilityrepository.findAll();
	}

}
