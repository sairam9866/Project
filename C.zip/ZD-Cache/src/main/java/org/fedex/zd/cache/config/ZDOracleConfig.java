/*package org.fedex.zd.cache.config;

import org.fedex.zd.cache.service.ZDOracleFacilityService;
import org.fedex.zd.cache.service.ZDOracleZipToDestService;
import org.fedex.zd.cache.service.impl.ZDOracleFaclityServiceImpl;
import org.fedex.zd.cache.service.impl.ZDOracleZipToDestServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ZDOracleConfig {
	
	@Bean
	public ZDOracleFacilityService faclityService(){
		
		return new ZDOracleFaclityServiceImpl();
	}
	
	@Bean
	ZDOracleZipToDestService zipTodestService(){
		return new ZDOracleZipToDestServiceImpl();
	}

}
*/