package org.fedex.zd.cache.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

@RedisHash
public class ZDRedisTransactional implements Serializable, ZDRedisTransactionalKey {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8171161542994882158L;

	@Id
	private String id;

	@Indexed
	private String network;

	private Integer countryCode;

	@Indexed
	private String zipCode;

	private String destinationTerminal;

	private String state;

	@Indexed
	private String transactionType;

	@Indexed
	private String processed;

	@Indexed
	private String current;

	@Indexed
	private String cancelled;

	private String uuid;

	private String createdBy;

	private String cancelledBy;
	
	@Indexed
	private Long effectiveDateTime;
	
	private Long createdDateTime;
	
	@Indexed
	private Long processedDateTime;
	
	private Long cancelledDateTime;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private transient LocalDateTime effectiveAt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private LocalDateTime createdAt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private transient LocalDateTime processedAt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private transient LocalDateTime cancelledAt;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		 this.id = id;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getDestinationTerminal() {
		return destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getProcessed() {
		return processed;
	}

	public void setProcessed(String processed) {
		this.processed = processed;
	}

	public String getCurrent() {
		return current;
	}

	public void setCurrent(String current) {
		this.current = current;
	}

	public String getCancelled() {
		return cancelled;
	}

	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Long getEffectiveDateTime() {
		return effectiveDateTime;
	}

	public void setEffectiveDateTime(Long effectiveDateTime) {
		this.effectiveDateTime = effectiveDateTime;
	}

	public Long getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Long createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Long getProcessedDateTime() {
		return processedDateTime;
	}

	public void setProcessedDateTime(Long processedDateTime) {
		this.processedDateTime = processedDateTime;
	}

	public Long getCancelledDateTime() {
		return cancelledDateTime;
	}

	public void setCancelledDateTime(Long cancelledDateTime) {
		this.cancelledDateTime = cancelledDateTime;
	}	

	
	public LocalDateTime getCreatedAt() {
		if(createdDateTime != null){
			createdAt = LocalDateTime.ofEpochSecond(createdDateTime, 0, ZoneOffset.UTC);
		}
		return createdAt;
	}

	public LocalDateTime getEffectiveAt() {
		if(effectiveDateTime != null){
			effectiveAt = LocalDateTime.ofEpochSecond(effectiveDateTime, 0, ZoneOffset.UTC);
		}
		return effectiveAt;
	}	

	public LocalDateTime getProcessedAt() {
		if(processedDateTime != null){
			processedAt = LocalDateTime.ofEpochSecond(processedDateTime, 0, ZoneOffset.UTC);
		}
		return processedAt;
	}

	public LocalDateTime getCancelledAt() {
		if(cancelledDateTime != null){
			cancelledAt = LocalDateTime.ofEpochSecond(cancelledDateTime, 0, ZoneOffset.UTC);
		}
		return cancelledAt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ZDRedisTransactional other = (ZDRedisTransactional) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ZipToDest [id=" + id + ", network=" + network + ", countryCode=" + countryCode + ", zipCode=" + zipCode
				+ ", destinationTerminal=" + destinationTerminal + ", state=" + state + ", transactionType="
				+ transactionType + ", processed=" + processed + ", current=" + current + ", cancelled=" + cancelled
				+ ", uuid=" + uuid + ", createdBy=" + createdBy + ", cancelledBy=" + cancelledBy
				+ ", effectiveDateTime=" + effectiveDateTime + ", createdDateTime=" + createdDateTime
				+ ", processedDateTime=" + processedDateTime + ", cancelledDateTime=" + cancelledDateTime + "]";
	}

	@Override
	public void buildKey() {		
		 setId(this.network + this.zipCode + this.destinationTerminal + this.createdDateTime);
	}

}
