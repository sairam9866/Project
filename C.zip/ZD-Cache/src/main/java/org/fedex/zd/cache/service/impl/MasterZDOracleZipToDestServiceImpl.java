package org.fedex.zd.cache.service.impl;

import java.util.List;

import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.repository.MasterZDOracleZipToDestRepository;
import org.fedex.zd.cache.service.MasterZDOracleZipToDestService;
import org.springframework.beans.factory.annotation.Autowired;

public class MasterZDOracleZipToDestServiceImpl implements MasterZDOracleZipToDestService {

	@Autowired
	MasterZDOracleZipToDestRepository masterZDOracleTransactionalRepository;
	
	
	@Override
	public List<MasterZDOracleZipToDestination> getAllZipTodestFromOracle() {

		return (List<MasterZDOracleZipToDestination>)masterZDOracleTransactionalRepository.findAll();
	}
}


