package org.fedex.zd.cache.config;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;

import org.springframework.context.annotation.PropertySource;

import org.springframework.http.HttpMethod;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration

@PropertySource(value = "classpath:application-lcl.properties")

public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	
/*
	@Value("${name}")

	private String user;*/ 

	/*@Value("${pwd}")

	private String pass;*/

	@Value("${admin}")
	private String admin;

	@Value("${adminPass}")
	private String adminPass;

	// Create 2 users for demo

	@Override

	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		System.out.println("---- newLang ----" + user);
//		System.out.println("Password --" + pass);

		auth.inMemoryAuthentication().withUser(admin).password(encoder().encode(adminPass)).roles("ADMIN");
		// .and().withUser(user).password(encoder().encode(pass)).roles("USER");
	}

	@Bean
	public PasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}

	// Secure the endpoins with HTTP Basic authentication

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
				// HTTP Basic authentication 
				.httpBasic().and().authorizeRequests().antMatchers(HttpMethod.POST, "/ziptodest/saveDataFromOracleToRedis").authenticated().anyRequest()
				.permitAll().and().httpBasic().and().csrf().disable();
	}

	
	  
	  @Bean public UserDetailsService userDetailsService() { //ok for demo
	  
	  User.UserBuilder users = User.withDefaultPasswordEncoder();
	 
	  
	  
	  InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
	 
	  manager.createUser(users.username("user").password("password").roles(
	  "USER").
	  
	  build());
	  
	  manager.createUser(users.username("admin").password("password").roles(
	  "USER",
	  
	  "ADMIN").build()); return manager; }
	  
	 

}
