package org.fedex.zd.cache.service;

import java.util.List;

import org.fedex.zd.cache.model.MasterZDOracleFacilityId;

public interface MasterZDOracleFacilityService {
	
	public List<MasterZDOracleFacilityId> getAllFacilityIds();
}
