package org.fedex.zd.cache.controller;

import java.util.List;

import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.model.ZipToDestAddRequest;
import org.fedex.zd.cache.repository.RedisRepository;
import org.fedex.zd.cache.util.ZipToDestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/redis")
public class RedisController {

	@Autowired
	ZipToDestUtil zipToDestUtil;

	@Autowired
	RedisRepository redisRepository;

	@PostMapping("/add")
	public String add(@RequestBody ZipToDestAddRequest zipToDestAddRequest) {
		ZDRedisTransactional zipToDest = zipToDestUtil.fromZipToDestAddRequest(zipToDestAddRequest);
		redisRepository.add(zipToDest);
		return "Done";
	}

	@GetMapping("/getall")
	public List<ZDRedisTransactional> getAllTransactions() {
		return redisRepository.findAll();
	}

	@DeleteMapping("/delete")
	public String delete(@RequestParam String id) {
		redisRepository.delete(id);
		return "Deleted";
	}

	@GetMapping("/findById")
	public ZDRedisTransactional findById(@RequestParam String id) {
		return redisRepository.findById(id);
	}
}
