package org.fedex.zd.cache.service;

import java.util.List;
import org.fedex.zd.cache.model.FacilityDeltaOracle;
import org.fedex.zd.cache.model.RenderRedisResponse;

public interface FacilityService {
	public List<FacilityDeltaOracle> getAllFacilityRecordsFromOracle();
	public RenderRedisResponse saveFacilityOracleFacilityDataToRedis();

}
