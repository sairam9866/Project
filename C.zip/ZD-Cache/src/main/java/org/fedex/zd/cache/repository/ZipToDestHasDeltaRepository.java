package org.fedex.zd.cache.repository;

import org.fedex.zd.cache.model.ZipToDestHasDeltaOracle;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ZipToDestHasDeltaRepository extends CrudRepository<ZipToDestHasDeltaOracle, String>{

}
