package org.fedex.zd.cache.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.fedex.zd.cache.model.MasterRedisFaclityID;
import org.fedex.zd.cache.model.MasterRedisZipToDestination;
import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.FacilityDeltaOracle;
import org.fedex.zd.cache.model.FacilityDeltaRedis;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestinationPK;
import org.fedex.zd.cache.model.ZDOracleTransactional;
import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.model.ZipToDestAddRequest;
import org.fedex.zd.cache.model.ZipToDestHasDeltaOracle;
import org.fedex.zd.cache.model.ZipToDestHasDeltaRedis;
import org.fedex.zd.cache.repository.MasterZDRedisZipToDestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.uuid.Generators;

@Component
public class ZipToDestUtil {
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestUtil.class);

	@Autowired
	MasterZDRedisZipToDestRepository masterZDRedisTransactionalRepository;
	
	private final SimpleDateFormat ZIP_TO_DEST_DATE_FORMAT = new SimpleDateFormat(ZipToDestConstants.APP_DATE_FORMAT);

	private final DateTimeFormatter ZIP_TO_DEST_DATE_TIME_FORMATTER = DateTimeFormatter
			.ofPattern(ZipToDestConstants.APP_DATE_FORMAT);

	public ZDRedisTransactional fromZipToDestAddRequest(ZipToDestAddRequest zipToDestAddRequest) {
		ZDRedisTransactional zipToDest = new ZDRedisTransactional();
		zipToDest.setNetwork(zipToDestAddRequest.getNetwork());
		zipToDest.setCountryCode(zipToDestAddRequest.getCountryCode());
		zipToDest.setState(zipToDestAddRequest.getState().toUpperCase());
		zipToDest.setZipCode((zipToDestAddRequest.getZipCode().trim()).toUpperCase());
		zipToDest.setDestinationTerminal(zipToDestAddRequest.getDestinationTerminal());
		zipToDest.setCreatedBy(zipToDestAddRequest.getCreationUser());
		zipToDest.setUuid(generateUuid());
		zipToDest.setEffectiveDateTime(
				getUtcEpochTime(zipToDestAddRequest.getEffectiveDate(), zipToDestAddRequest.getTimeZone()));
		zipToDest.setCreatedDateTime(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCurrent(ZipToDestConstants.FLAG_NO);
		zipToDest.setProcessed(ZipToDestConstants.FLAG_NO);
		zipToDest.setCancelled(ZipToDestConstants.FLAG_NO);
		zipToDest.setTransactionType(ZipToDestConstants.TRANS_TYPE_ADD);
		zipToDest.buildKey();
		return zipToDest;
	}
	
	public MasterZDOracleZipToDestination fromZipToDestAddRequesttoInMemory(ZipToDestAddRequest zipToDestAddRequest) throws ParseException {
		MasterZDOracleZipToDestination zipToDest = new MasterZDOracleZipToDestination();
		MasterZDOracleZipToDestinationPK ziptidestpk= new MasterZDOracleZipToDestinationPK();
		ziptidestpk.setCountryCode(12);
		ziptidestpk.setNetwork("ABC");
		ziptidestpk.setZipCode("12345");
		zipToDest.setDestination(Integer.parseInt(zipToDestAddRequest.getDestinationTerminal()));
		zipToDest.setState(zipToDestAddRequest.getState());
		zipToDest.setId(ziptidestpk);
		zipToDest.getZipToDestPK().setNetwork(zipToDestAddRequest.getNetwork());
		zipToDest.getZipToDestPK().setZipCode(zipToDestAddRequest.getZipCode());
		SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date= sft.parse(zipToDestAddRequest.getEffectiveDate());
		Timestamp timestamp = new Timestamp(date.getTime());
		zipToDest.setLastUpdateTimestamp(timestamp);
		zipToDest.setLastUpdateBy("ABC");
		//zipToDest.setLastUpdateTimestamp(zipToDestAddRequest.getEffectiveDate());
		return zipToDest;
	}

	public ZDRedisTransactional fromZipToDestDataToRedis(ZDOracleTransactional zipToDestData){
		ZDRedisTransactional zipToDest = new ZDRedisTransactional();
		zipToDest.setNetwork(zipToDestData.getNetwork());
		zipToDest.setCountryCode(zipToDestData.getCountryCode());
		zipToDest.setState(zipToDestData.getState());
		zipToDest.setZipCode(zipToDestData.getZipCode());
		zipToDest.setDestinationTerminal(zipToDestData.getDestinationTerminal());
		zipToDest.setCreatedBy(zipToDestData.getCreatedBy());
		zipToDest.setUuid(generateUuid());
		zipToDest.setEffectiveDateTime(getEpochTime(zipToDestData.getEffectiveDateTime()));
		zipToDest.setCreatedDateTime(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCurrent(ZipToDestConstants.FLAG_NO);
		zipToDest.setProcessed(ZipToDestConstants.FLAG_NO);
		zipToDest.setCancelled(ZipToDestConstants.FLAG_NO);		
		zipToDest.setTransactionType(ZipToDestConstants.TRANS_TYPE_ADD);
		zipToDest.setCancelledDateTime(getEpochTime(zipToDestData.getCancelledDateTime()));
		zipToDest.buildKey();
		return zipToDest;
	}
	
/***********User Story Start  ==> Populate data from oracle into Redis DB  ************/
	public MasterRedisZipToDestination zipToDestOracleDataToRedis(MasterZDOracleZipToDestination zipToDestData){
		MasterRedisZipToDestination zipToDest = new MasterRedisZipToDestination();
		zipToDest.setState(zipToDestData.getState());
		zipToDest.setDestination(zipToDestData.getDestination());
	    zipToDest.setLastUpdateTimestamp(zipToDestData.getLastUpdateTimestamp().getTime());
		zipToDest.setLastUpdateBy(zipToDestData.getLastUpdateBy());
		zipToDest.setNetwork(zipToDestData.getZipToDestPK().getNetwork());
		zipToDest.setCountryCode(zipToDestData.getZipToDestPK().getCountryCode());
		zipToDest.setZipCode(zipToDestData.getZipToDestPK().getZipCode());
		zipToDest.buildKey();
		return zipToDest;
	}
	
	public MasterRedisFaclityID faclityOracleDataToRedis(MasterZDOracleFacilityId facilityData){
		MasterRedisFaclityID masterRedisFaclityID= new MasterRedisFaclityID();
		masterRedisFaclityID.setTransactionType(facilityData.getTransactionType());
		masterRedisFaclityID.setUuId(facilityData.getUuId());
		masterRedisFaclityID.setState(facilityData.getState());
		masterRedisFaclityID.setNetwork(facilityData.getFacilityIdPK().getNetwork());
		masterRedisFaclityID.setFacilityId(facilityData.getFacilityIdPK().getFacilityId());
		masterRedisFaclityID.setZipCode(facilityData.getFacilityIdPK().getZipCode());
		masterRedisFaclityID.setEffectiveDateTime(facilityData.getFacilityIdPK().getEffectiveDateTimestamp().getTime());
		masterRedisFaclityID.buildKey();
		return masterRedisFaclityID;
	}
/***********User Story End  ==> Populate data from oracle into Redis DB  ************/	
	public String generateUuid() {
		return Generators.timeBasedGenerator().generate().toString();
	}

	public SimpleDateFormat instanceOfAppDateFormat() {
		return ZIP_TO_DEST_DATE_FORMAT;
	}

	
	public DateTimeFormatter instanceOfAppDateTimeFormatter() {
		return ZIP_TO_DEST_DATE_TIME_FORMATTER;
	}

	public long getUtcEpochTime(String dateTime, String timeZone) {
		LocalDateTime localDateTime = LocalDateTime.parse(dateTime, instanceOfAppDateTimeFormatter());
		int post = timeZone.trim().indexOf(')');
		String fromTimeZone = timeZone.substring(++post).trim();
		ZonedDateTime fromDateTimeZone = localDateTime.atZone(ZoneId.of(fromTimeZone));
		ZonedDateTime utcDateTime = fromDateTimeZone.withZoneSameInstant(ZoneOffset.UTC);
		return utcDateTime.toEpochSecond();
	}

	public long getEpochTime(String dateTime) {
		LocalDateTime localDateTime = LocalDateTime.parse(dateTime, instanceOfAppDateTimeFormatter());
		return localDateTime.atZone(ZoneId.systemDefault()).toInstant().getEpochSecond();

	}

	public LocalDateTime getLocalDateTimeFromEpoch(long epochTime) {
		return LocalDateTime.ofEpochSecond(epochTime, 0, ZoneOffset.UTC);
	}

	public String formatAppDateTime(LocalDateTime appLoclDateTime) {
		return (appLoclDateTime.format(instanceOfAppDateTimeFormatter()));
	}
	
	public boolean isValidCanadaZipCode(String zipCode) {
		boolean output = false;
		output = (ZipToDestConstants.PATTERN_CANADA_ZIP_CODE3.matcher(zipCode).matches()
				|| ZipToDestConstants.PATTERN_CANADA_ZIP_CODE6.matcher(zipCode).matches());
		return output;
	}
	
	public boolean isValidUsaZipCode(String zipCode) {
		return (ZipToDestConstants.PATTERN_US_ZIP_CODE.matcher(zipCode).matches());
	}
	
	
	/**************Facility and ZipToDestHasDelta *******************************/
	public FacilityDeltaRedis savefaclityOracleDataToRedis(FacilityDeltaOracle facilityDeltaOracle){
		FacilityDeltaRedis facilityDeltaRedis= new FacilityDeltaRedis();
		facilityDeltaRedis.setTransactionType(String.valueOf(facilityDeltaOracle.getTransactionType()));
		facilityDeltaRedis.setUuId(facilityDeltaOracle.getUuId());
		facilityDeltaRedis.setState(facilityDeltaOracle.getState());
		facilityDeltaRedis.setNetwork(facilityDeltaOracle.getFacilityIdPK().getNetwork());
		facilityDeltaRedis.setFacilityId(facilityDeltaOracle.getFacilityIdPK().getFacilityId());
		facilityDeltaRedis.setZipCode(facilityDeltaOracle.getFacilityIdPK().getZipCode());
		facilityDeltaRedis.setEffectiveDateTime(facilityDeltaOracle.getFacilityIdPK().getEffectiveDateTimestamp().getTime());//check this line what time it is comming here, whether it is UTC or change?
		facilityDeltaRedis.buildKey();
		return facilityDeltaRedis;
	}
	
	public ZipToDestHasDeltaRedis saveZipToDestHasDeltaOracleDataToRedis(ZipToDestHasDeltaOracle zipToDestHasDeltaOracle){
		ZipToDestHasDeltaRedis zipToDestHasDeltaRedis=new ZipToDestHasDeltaRedis();
		zipToDestHasDeltaRedis.setLastUpdateTimestamp(zipToDestHasDeltaOracle.getLastUpdateTimestamp().getTime());//need to check what time is comming
		zipToDestHasDeltaRedis.setNetwork(zipToDestHasDeltaOracle.getNetwork());
		return zipToDestHasDeltaRedis;
	}
}
