package org.fedex.zd.cache.repository.impl;

import org.fedex.zd.cache.model.FacilityDeltaRedis;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacilityRedisRepository extends CrudRepository<FacilityDeltaRedis, String> {
}
