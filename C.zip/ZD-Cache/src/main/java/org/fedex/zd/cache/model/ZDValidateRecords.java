package org.fedex.zd.cache.model;

public class ZDValidateRecords {
	public Long noOfRecordsInOracle;
	public Long noOfRecordsInRedis;

	public Long getNoOfRecordsInOracle() {
		return noOfRecordsInOracle;
	}

	public void setNoOfRecordsInOracle(Long noOfRecordsInOracle) {
		this.noOfRecordsInOracle = noOfRecordsInOracle;
	}

	public Long getNoOfRecordsInRedis() {
		return noOfRecordsInRedis;
	}

	public void setNoOfRecordsInRedis(Long noOfRecordsInRedis) {
		this.noOfRecordsInRedis = noOfRecordsInRedis;
	}

}
