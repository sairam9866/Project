package org.fedex.zd.cache.repository;

import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestinationPK;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


public interface MasterZDOracleZipToDestRepository extends CrudRepository<MasterZDOracleZipToDestination, MasterZDOracleZipToDestinationPK>{

}
