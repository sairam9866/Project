package org.fedex.zd.cache.repository;

import org.fedex.zd.cache.model.MasterRedisZipToDestination;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestinationPK;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

public interface MasterZDRedisZipToDestRepository extends CrudRepository<MasterRedisZipToDestination, String>, QueryByExampleExecutor<MasterRedisZipToDestination> {
	



}
