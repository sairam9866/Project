package org.fedex.zd.cache.service;

import java.util.List;

import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.model.ZDValidateRecords;
import org.fedex.zd.cache.model.ZipToDestAddRequest;

public interface ZipToDestService {

	public List<ZDRedisTransactional> getAllTransactions();

	public ZDRedisTransactional getZipToDestByKey(String key);

	public List<ZDRedisTransactional> getCurrentTransactions();

	public List<ZDRedisTransactional> getCurrentTrans(String current);

	public List<ZDRedisTransactional> getTransactionByNetwork(String network);

	public List<ZDRedisTransactional> getTransactionByNetworkAndZipCode(String network, String zipCode);

	public int modifyZipToDest(ZDRedisTransactional zipToDest);

	public int deleteZipToDest(ZDRedisTransactional zipToDest);

	public int deleteZipToDestById(String id);

	public ZDRedisTransactional insertZipToDest(ZipToDestAddRequest zipToDestAddRequest);

	public void saveDataToRedis();
	/***********User Story Start  ==> Populate data from oracle into Redis DB  ************/	
	public RenderRedisResponse saveZipTodestDataToRedis();
	public void deleteZipTodestRecordsFromRedis();
	public void deleteAllFacilityRecardsfromRedis();
	public RenderRedisResponse saveOracleFacilityDataToRedis();
	
	/***********User Story End  ==> Populate data from oracle into Redis DB  ************/	
	//public List<MasterRedisZipToDestination> getAllZipToDest();
	public List<ZDRedisTransactional> selectByEffectiveDate(String from, String to);
	public List<ZDRedisTransactional> selectByNetworkAndEffectiveDate(String network, String from, String to);
	public List<ZDRedisTransactional> selectByNetworkAndProcessedDate(String network, String from, String to);
	public List<ZDRedisTransactional> scanTransactionByNetwork(String network);
	public List<ZDRedisTransactional> scanByNetworkAndZipCodeRange(String network, String zipFrom, String zipTo);
	public List<String> scanByZipcodeRange(String zipFrom, String zipTo);
	
	public void deleteRecordsFromRedisMemory();
	
	
	
	public ZDValidateRecords getValidatedRecords();

	//public MasterZDOracleZipToDestination addRecordToZipTodestInMemory(ZipToDestAddRequest zipToDestAddRequest) throws ParseException;	
}
