package org.fedex.zd.cache.repository;

import org.fedex.zd.cache.model.ZDOracleTransactional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ZDOracleTransactionalRepository extends CrudRepository<ZDOracleTransactional, Long>{

}
