package org.fedex.zd.cache.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author 3790999
 *
 */
@Embeddable
public class MasterZDOracleZipToDestinationPK implements Serializable {


	private static final long serialVersionUID = 1L;

	@Column(name = "network")
	private String network;

	@Column(name = "country_cd")
	private int countryCode;

	@Column(name = "zip_cd")
	private String zipCode;

	public MasterZDOracleZipToDestinationPK(){
		
	}
	
	public MasterZDOracleZipToDestinationPK(String network, int countryCode, String zipCode){
		this();
		this.network = network;
		this.countryCode = countryCode;
		this.zipCode = zipCode;
	}
	
	public String getNetwork() {
		return network;
	}
	
	public int getCountryCode() {
		return countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}
	
	public void setNetwork(String network) {
		this.network = network;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

}
