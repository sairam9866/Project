package org.fedex.zd.cache.repository;

import java.util.List;
import java.util.Map;

import org.fedex.zd.cache.model.ZDRedisTransactional;

public interface RedisRepository {

	List<ZDRedisTransactional> findAll();
	
	void add(ZDRedisTransactional zipToDest);
	
	void delete(String id);
	
	ZDRedisTransactional findById(String id);
}
