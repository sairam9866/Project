package org.fedex.zd.cache.service.impl;

import java.util.List;
import java.util.Optional;

import org.fedex.zd.cache.model.MasterRedisFaclityID;
import org.fedex.zd.cache.model.MasterRedisZipToDestination;
import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.model.ZDOracleTransactional;
import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.model.ZDValidateRecords;
import org.fedex.zd.cache.model.ZipToDestAddRequest;
import org.fedex.zd.cache.repository.MasterZDOracleZipToDestRepository;
import org.fedex.zd.cache.repository.MasterZDRedisFacilityrepository;
import org.fedex.zd.cache.repository.MasterZDRedisZipToDestRepository;
import org.fedex.zd.cache.repository.ZDOracleFacilityrepository;
import org.fedex.zd.cache.repository.ZDOracleTransactionalRepository;
import org.fedex.zd.cache.repository.ZDRedisTransactionalRepository;
import org.fedex.zd.cache.service.ZipToDestService;
import org.fedex.zd.cache.util.ZipToDestConstants;
import org.fedex.zd.cache.util.ZipToDestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class ZipToDestServiceImpl implements ZipToDestService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestServiceImpl.class);
	
    int rowsCount;
	
	int rowsExist;
	
	@Autowired
	@Qualifier("zdMasterRepository")
	ZDRedisTransactionalRepository zdRedisTransactionalRepository;

	@Autowired
	ZipToDestUtil zipToDestUtil;
	
	@Autowired
	MasterZDRedisZipToDestRepository masterZDRedisZipToDestRepository;

	@Autowired
	ZDOracleTransactionalRepository zdOracleTransactionalRepository;
	
	@Autowired
	MasterZDOracleZipToDestRepository masterZDOracleZipToDestRepository;
	
	@Autowired
	ZDOracleFacilityrepository zDOracleFacilityrepository;
	
	@Autowired
	MasterZDRedisFacilityrepository masterZDRedisFacilityrepository;

	private int count;
	
	
	@Override
	public List<ZDRedisTransactional> getAllTransactions() {
		return (List<ZDRedisTransactional>) zdRedisTransactionalRepository.findAll();
	}

	@Override
	public ZDRedisTransactional getZipToDestByKey(String key) {
		Optional<ZDRedisTransactional> zipToDest = zdRedisTransactionalRepository.findById(key);
		return zipToDest.isPresent() ? zipToDest.get() : null;
	}

	@Override
	public List<ZDRedisTransactional> getCurrentTransactions() {
		return zdRedisTransactionalRepository.findByCurrentAndProcessedAndCancelled(ZipToDestConstants.FLAG_YES,
				ZipToDestConstants.FLAG_YES, ZipToDestConstants.FLAG_NO);
	}

	@Override
	public List<ZDRedisTransactional> getCurrentTrans(String current) {
		return (List<ZDRedisTransactional>) zdRedisTransactionalRepository.getTransactionsByCurrentFlag(current);
	}

	@Override
	public List<ZDRedisTransactional> getTransactionByNetwork(String network) {
		return zdRedisTransactionalRepository.findByNetwork(network);
	}

	@Override
	public List<ZDRedisTransactional> getTransactionByNetworkAndZipCode(String network, String zipCode) {
		return zdRedisTransactionalRepository.findByNetworkAndZipCode(network, zipCode);
	}

	@Override
	public int deleteZipToDest(ZDRedisTransactional zipToDest) {
		zdRedisTransactionalRepository.deleteById(zipToDest.getId());
		return 0;
	}

	@Override
	public int deleteZipToDestById(String id) {
		zdRedisTransactionalRepository.deleteById(id);
		return 0;
	}

	@Override
	public int modifyZipToDest(ZDRedisTransactional zipToDest) {
		zdRedisTransactionalRepository.save(zipToDest);
		return 0;
	}

	@Override
	public ZDRedisTransactional insertZipToDest(ZipToDestAddRequest zipToDestAddRequest) {
		return zdRedisTransactionalRepository.save(zipToDestUtil.fromZipToDestAddRequest(zipToDestAddRequest));
	}

	@Override
	public void saveDataToRedis() {
		List<ZDOracleTransactional> listOfRecords = (List<ZDOracleTransactional>) zdOracleTransactionalRepository
				.findAll();
		System.out.println("No of records in Hsql DB :- " + zdOracleTransactionalRepository.count());
		System.out.println("No of records in Redis DB before saving :- " + zdRedisTransactionalRepository.count());

		listOfRecords.stream().forEach(zipToDestData -> {
			zdRedisTransactionalRepository.save(zipToDestUtil.fromZipToDestDataToRedis(zipToDestData));
		});

		System.out.println("No of records in Redis DB after saving :- " + zdRedisTransactionalRepository.count());
	}	
	
	/***********User Story Start  ==> Populate data from oracle to Redis DB  ************/	
	@Override
	public RenderRedisResponse saveZipTodestDataToRedis() {
		rowsExist=0;
		rowsCount=0;
		List<MasterZDOracleZipToDestination> listOfRecords = (List<MasterZDOracleZipToDestination>) masterZDOracleZipToDestRepository
				.findAll();
		listOfRecords.stream().forEach(zipToDestData -> {
			MasterRedisZipToDestination newObject = zipToDestUtil.zipToDestOracleDataToRedis(zipToDestData);
			
			if(!masterZDRedisZipToDestRepository.existsById(newObject.getId())){
				masterZDRedisZipToDestRepository.save(newObject);
				rowsCount++;
			}else {                                                                                   
				rowsExist++;
			}
		});
		
		RenderRedisResponse output=new RenderRedisResponse();
		
		output.setNoOfnewRecordsInsertedInRedis(String.valueOf(rowsCount));
		output.setNoOfRowsExistsInRedis(String.valueOf(rowsExist));
		output.setNoOfRecordsLoadedFromOracle(String.valueOf(masterZDOracleZipToDestRepository.count()));
		return output;
	}	
	
	@Override
	public RenderRedisResponse saveOracleFacilityDataToRedis() {
		rowsExist=0;
		rowsCount=0;
		List<MasterZDOracleFacilityId> oracleFacilityIdList = (List<MasterZDOracleFacilityId>)zDOracleFacilityrepository.findAll(); 
		oracleFacilityIdList.stream().forEach(facilityId -> {
			MasterRedisFaclityID newObject = zipToDestUtil.faclityOracleDataToRedis(facilityId);
			
			if(!masterZDRedisFacilityrepository.existsById(newObject.getId())){
				masterZDRedisFacilityrepository.save(newObject);
				rowsCount++;
			}else {                                                                                   
				rowsExist++;
			}
		});
		RenderRedisResponse output=new RenderRedisResponse();
		output.setNoOfnewRecordsInsertedInRedis(String.valueOf(rowsCount));
		output.setNoOfRowsExistsInRedis(String.valueOf(rowsExist));
		output.setNoOfRecordsLoadedFromOracle(String.valueOf(zDOracleFacilityrepository.count()));
		return output;
	}
	
	@Override
	public void deleteZipTodestRecordsFromRedis() {
		masterZDRedisZipToDestRepository.deleteAll();
	}
	
	@Override
	public void deleteAllFacilityRecardsfromRedis() {
		masterZDRedisFacilityrepository.deleteAll();
	}

	
	/***********User Story End  ==> Populate data from oracle to Redis DB  ************/	
	/*@Override
	public List<MasterRedisZipToDestination> getAllZipToDest() {
		return (List<MasterRedisZipToDestination>) masterZDRedisZipToDestRepository.findAll(); 
	}*/
	
	@Override
	public List<ZDRedisTransactional> selectByEffectiveDate(String from, String to) {
		long dateFrom = zipToDestUtil.getUtcEpochTime(from, ZipToDestConstants.UTC_TIME_ZONE);
		long dateTo = zipToDestUtil.getUtcEpochTime(to,  ZipToDestConstants.UTC_TIME_ZONE);
		LOGGER.info("From Date : {}", dateFrom);
		LOGGER.info("To Date : {}", dateTo);
		return zdRedisTransactionalRepository.selectByEffectiveDate(dateFrom, dateTo);
	}

	@Override
	public List<ZDRedisTransactional> selectByNetworkAndEffectiveDate(String network, String from, String to) {
		long dateFrom = zipToDestUtil.getUtcEpochTime(from, ZipToDestConstants.UTC_TIME_ZONE);
		long dateTo = zipToDestUtil.getUtcEpochTime(to,  ZipToDestConstants.UTC_TIME_ZONE);
		LOGGER.info("Network : {}", network);
		LOGGER.info("From Date : {}", dateFrom);
		LOGGER.info("To Date : {}", dateTo);		
		
		return zdRedisTransactionalRepository.selectByNetworkAndEffectiveDate(network, dateFrom, dateTo);
	}
	
	@Override
	public List<ZDRedisTransactional> selectByNetworkAndProcessedDate(String network, String from, String to) {
		long dateFrom = zipToDestUtil.getUtcEpochTime(from, ZipToDestConstants.UTC_TIME_ZONE);
		long dateTo = zipToDestUtil.getUtcEpochTime(to,  ZipToDestConstants.UTC_TIME_ZONE);
		LOGGER.info("Network : {}", network);
		LOGGER.info("From Date : {}", dateFrom);
		LOGGER.info("To Date : {}", dateTo);
		
		return zdRedisTransactionalRepository.selectByNetworkAndProcessedDate(network, dateFrom, dateTo);		
	}
	
	@Override
	public List<ZDRedisTransactional> scanTransactionByNetwork(String network){
		return zdRedisTransactionalRepository.scanTransactionByNetwork(network);
	}
	
	@Override
	public List<ZDRedisTransactional> scanByNetworkAndZipCodeRange(String network, String zipFrom, String zipTo) {
		return zdRedisTransactionalRepository.scanByNetworkAndZipCodeRange(network, zipFrom, zipTo);
	}

	@Override
	public void deleteRecordsFromRedisMemory() {
		zdRedisTransactionalRepository.deleteAll();
	}

	@Override
	public ZDValidateRecords getValidatedRecords() {
		ZDValidateRecords zdValidateRecords = new ZDValidateRecords();
		zdValidateRecords.setNoOfRecordsInOracle(zdOracleTransactionalRepository.count());
		zdValidateRecords.setNoOfRecordsInRedis(zdRedisTransactionalRepository.count());
		return zdValidateRecords;
	}

	@Override
	public List<String> scanByZipcodeRange(String zipFrom, String zipTo) {
		
		return zdRedisTransactionalRepository.scanByZipcodeRange(zipFrom, zipTo);
	}

	/*@Override
	public MasterZDOracleZipToDestination addRecordToZipTodestInMemory(ZipToDestAddRequest zipToDestAddRequest) throws ParseException {
		
			return masterZDOracleZipToDestRepository.save(zipToDestUtil.fromZipToDestAddRequesttoInMemory(zipToDestAddRequest));
	}*/

}
