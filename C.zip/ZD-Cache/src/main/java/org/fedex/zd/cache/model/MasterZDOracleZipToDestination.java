package org.fedex.zd.cache.model;
import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;



/**
 * @author 3790999
 *
 */

@Entity
@Table(name = "zip_to_dest")
public class MasterZDOracleZipToDestination implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MasterZDOracleZipToDestinationPK id;

	public void setId(MasterZDOracleZipToDestinationPK id) {
		this.id = id;
	}

	public MasterZDOracleZipToDestinationPK getZipToDestPK() {
		return id;
	}
	
	public MasterZDOracleZipToDestination(){
		
	}
	
	public MasterZDOracleZipToDestination(MasterZDOracleZipToDestinationPK id, String state, int destination, Timestamp lastUpdateTimestamp, String lastUpdateBy){
		this();
		this.id = id;
		this.state = state;
		this.destination = destination;
		this.lastUpdateTimestamp = lastUpdateTimestamp;
		this.lastUpdateBy = lastUpdateBy;
	}
	
	@Column(name = "state")
	private String state;

	@Column(name = "dest_terminal")
	private int destination;

	@Column(name = "last_update_tmstp")
	private Timestamp lastUpdateTimestamp;

	@Column(name = "last_update_user")
	private String lastUpdateBy;
	
	public Timestamp getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public String getState() {
		return state;
	}
	
	public String getLastUpdateBy(){
		return lastUpdateBy;
	}

	public int getDestination() {
		return destination;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setDestination(int destination) {
		this.destination = destination;
	}

	public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}	

}
