package org.fedex.zd.cache.repository;

import org.fedex.zd.cache.model.MasterRedisFaclityID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

public interface MasterZDRedisFacilityrepository extends CrudRepository<MasterRedisFaclityID, String>, QueryByExampleExecutor<MasterRedisFaclityID> {

}
