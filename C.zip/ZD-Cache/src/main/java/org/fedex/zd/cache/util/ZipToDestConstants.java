package org.fedex.zd.cache.util;

import java.util.regex.Pattern;

public final class ZipToDestConstants {

	public static final String APP_HASH_KEY = "ZDTRANSACTIONS";
	public static final String APP_TRANSACTION_TMSTMP_KEY = "ZDTRANSACTIONS_TMSTMP";
	public static final String APP_TRANSACTION_ZIP_KEY = "TRANSACTIONS_ZIPCODES";
	public static final double ZIP_CODE_DEFAULT_SCORE = 1d;
	//public static final String APP_TRANSACTION_ZIP_CA_KEY = "TRANSACTION_CA";

	public static final String APP_DATE_FORMAT = "yyyy-MM-dd.HH:mm:ss";

	public static final String FLAG_YES = "Y";
	public static final String FLAG_NO = "N";

	public static final String TRANS_TYPE_ADD = "A";
	public static final String TRANS_TYPE_MODIFY = "M";
	public static final String TRANS_TYPE_DELETE = "D";

	public static final String UTC_TIME_ZONE = "UTC";
	
	//Facility
	public static final String FACILITY_HASH_KEY = "FACILITYDELTA";
	public static final String ZIP_TO_DEST_HAS_DELTA_HASH_KEY = "ZIPTODESTHASDELTA";
	
	public static final String ZIP_TO_DEST_NETWORKS = "ZIPTODESTNETWORKS";
	public static final String ZIP_TO_DEST = "ZIPTODEST";
	

	// US Zipcode Pattern
	public static final Pattern PATTERN_US_ZIP_CODE = Pattern.compile("[0-9]{5,5}");
	public static final Pattern PATTERN_CANADA_ZIP_CODE3 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z]$");
	public static final Pattern PATTERN_CANADA_ZIP_CODE6 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z][\\d][a-zA-Z][\\d]$");
}
