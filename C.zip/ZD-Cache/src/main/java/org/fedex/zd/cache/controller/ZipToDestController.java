package org.fedex.zd.cache.controller;

import java.util.List;

import org.fedex.zd.cache.model.FacilityDeltaOracle;
import org.fedex.zd.cache.model.MasterZDOracleFacilityId;
import org.fedex.zd.cache.model.MasterZDOracleZipToDestination;
import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.model.ZDValidateRecords;
import org.fedex.zd.cache.model.ZipToDestAddRequest;
import org.fedex.zd.cache.model.ZipToDestHasDeltaOracle;
import org.fedex.zd.cache.service.FacilityService;
import org.fedex.zd.cache.service.MasterZDOracleFacilityService;
import org.fedex.zd.cache.service.MasterZDOracleZipToDestService;
import org.fedex.zd.cache.service.ZipToDestHasDeltaService;
import org.fedex.zd.cache.service.ZipToDestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ziptodest")
public class ZipToDestController {

	@Autowired
	ZipToDestService zipToDestService;

	@Autowired
	MasterZDOracleZipToDestService masterzipToDestService;

	@Autowired
	MasterZDOracleFacilityService zdOracleFacilityService;

	@Autowired
	MasterZDOracleZipToDestService zdOracleZipToDestService;

	@Autowired
	RedisTemplate<String, Object> redisTemplate;

	// facility and ZipToDestHasDelta

	@Autowired
	FacilityService facilityService;

	@Autowired
	ZipToDestHasDeltaService zipToDestHasDeltaService;

	@GetMapping("/get")
	public ResponseEntity<List<ZDRedisTransactional>> getAllTransactions() {
		return new ResponseEntity<>(zipToDestService.getAllTransactions(), HttpStatus.OK);
	}

	@GetMapping("/get/{key}")
	public ResponseEntity<ZDRedisTransactional> getZipToDestByKey(@PathVariable String key) {
		ResponseEntity<ZDRedisTransactional> response = null;
		ZDRedisTransactional output = zipToDestService.getZipToDestByKey(key);
		if (output != null) {
			response = new ResponseEntity<>(output, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return response;
	}

	@GetMapping("/get/current")
	public ResponseEntity<List<ZDRedisTransactional>> getCurrentTransactions() {
		return (new ResponseEntity<>(zipToDestService.getCurrentTransactions(), HttpStatus.OK));
	}

	@GetMapping("/get/currentTrans/{flag}")
	public ResponseEntity<List<ZDRedisTransactional>> getCurrentTrans(@PathVariable String flag) {
		return (new ResponseEntity<>(zipToDestService.getCurrentTrans(flag), HttpStatus.OK));
	}

	@GetMapping("/get/networkAndZipcode")
	public ResponseEntity<List<ZDRedisTransactional>> getTransByNetwork(@RequestParam String network) {
		return (new ResponseEntity<>(zipToDestService.getTransactionByNetwork(network), HttpStatus.OK));
	}

	@GetMapping("/get/networksAndZipcodeQbe")
	public ResponseEntity<List<ZDRedisTransactional>> getTransByNetwork(@RequestParam String network,
			@RequestParam String zipcode) {
		return (new ResponseEntity<>(zipToDestService.getTransactionByNetworkAndZipCode(network, zipcode),
				HttpStatus.OK));
	}

	@PostMapping("/add")
	public ResponseEntity<ZDRedisTransactional> insertZipToDest(@RequestBody ZipToDestAddRequest zipToDestAddRequest) {
		ResponseEntity<ZDRedisTransactional> response = null;
		ZDRedisTransactional output = zipToDestService.insertZipToDest(zipToDestAddRequest);
		if (output != null) {
			response = new ResponseEntity<>(output, HttpStatus.CREATED);
		} else {
			response = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@PutMapping("/modify")
	public ResponseEntity<ZDRedisTransactional> modifyZipToDest(@RequestBody ZDRedisTransactional zipToDest) {
		ResponseEntity<ZDRedisTransactional> response = null;
		zipToDestService.modifyZipToDest(zipToDest);
		return response;
	}

	@DeleteMapping("/delete")
	public String deleteZipToDest(@RequestParam String id) {
		zipToDestService.deleteZipToDestById(id);
		return "Deleted";
	}

	@GetMapping("/selectByEffectiveDateRange")
	public List<ZDRedisTransactional> selectByEffectiveDate(@RequestParam String from, @RequestParam String to) {
		return zipToDestService.selectByEffectiveDate(from, to);
	}

	@GetMapping("/selectByNetworkEffectiveDateRange")
	public List<ZDRedisTransactional> selectByNetworkAndEffectiveDate(@RequestParam String network,
			@RequestParam String from, @RequestParam String to) {
		return zipToDestService.selectByNetworkAndEffectiveDate(network, from, to);
	}

	@GetMapping("/scanByNetwork")
	public List<ZDRedisTransactional> scanTransactionByNetwork(@RequestParam String network) {
		return zipToDestService.scanTransactionByNetwork(network);
	}

	@GetMapping("/selectByZipRange")
	public List<ZDRedisTransactional> selectByZipcodeRange(@RequestParam String network, @RequestParam String zipFrom,
			@RequestParam String zipTo) {
		return zipToDestService.scanByNetworkAndZipCodeRange(network, zipFrom, zipTo);
	}

	@GetMapping("/scanByZipRange")
	public List<String> scanByZipcodeRange(@RequestParam String zipFrom, @RequestParam String zipTo) {
		return zipToDestService.scanByZipcodeRange(zipFrom, zipTo);
	}

	// @GetMapping("/get/keyexist")
	public String isKeyExist(@RequestParam String key) {
		if (redisTemplate.hasKey(key)) {
			redisTemplate.execute(new RedisCallback<List<ZDRedisTransactional>>() {
				@Override
				public List<ZDRedisTransactional> doInRedis(RedisConnection connection) throws DataAccessException {

					ScanOptions.ScanOptionsBuilder builder = new ScanOptions.ScanOptionsBuilder();
					builder.match("{ZdTransaction}:processed:N");
					Cursor<byte[]> cursor = connection.scan(builder.build());

					while (cursor.hasNext()) {
						System.out.println(cursor.next());
					}

					return null;
				}
			});

			return "Key Exist";
		}
		return "Key Not Found";
	}

	@DeleteMapping("/deleteAll")
	public String deleteRecordsFromRedis() {
		zipToDestService.deleteRecordsFromRedisMemory();
		return "Deleted";
	}

	@PostMapping("/saveToRedis")
	public String saveRecordsToRedis() {
		zipToDestService.saveDataToRedis();
		return "Success";
	}

	/************ User Story Start ==> Populate data from oracle to Redis DB  ************/

	@GetMapping("/get/faclilityIds")
	public ResponseEntity<List<MasterZDOracleFacilityId>> getAllFacilityIds() {
		return new ResponseEntity<>(zdOracleFacilityService.getAllFacilityIds(), HttpStatus.OK);
	}

	@GetMapping("/get/ziptodest")

	public ResponseEntity<List<MasterZDOracleZipToDestination>> getAllZiptodests() {
		return new ResponseEntity<>(zdOracleZipToDestService.getAllZipTodestFromOracle(), HttpStatus.OK);
	}

	@PostMapping("/saveDataFromOracleToRedis")
	public RenderRedisResponse saveZipTodestDataFromOracleToRedis() {//ziptodest data
		return zipToDestService.saveZipTodestDataToRedis();
	}

	@PostMapping("/savefacilitydatatoredis")
	public RenderRedisResponse saveOracleFacilityDataToRedis() {//facility data
		return zipToDestService.saveOracleFacilityDataToRedis();
	}

	@DeleteMapping("/deleteAllziptodest")
	public String deleteAllZipToDestRecardsfromRedis() {
		zipToDestService.deleteZipTodestRecordsFromRedis();
		return "Records Deleted from Redis";
	}

	@DeleteMapping("/deleteAllFacility")
	public String deleteAllFacilityRecardsfromRedis() {
		zipToDestService.deleteAllFacilityRecardsfromRedis();
		return "Records Deleted from Redis";
	}

	/************ User Story End ==> Populate data from oracle to Redis DB ************/

	/*
	 * @GetMapping("/getAllZipToDest") public
	 * ResponseEntity<List<MasterRedisZipToDestination>> getAllZipToDest() {
	 * return new ResponseEntity<>(zipToDestService.getAllZipToDest(),
	 * HttpStatus.OK); }
	 */

	/*
	 * @PostMapping("/addRecordToZipTodest") public
	 * ResponseEntity<MasterZDOracleZipToDestination>
	 * addRecordToZipTodestInMemory(@RequestBody ZipToDestAddRequest
	 * zipToDestAddRequest) throws ParseException {
	 * ResponseEntity<MasterZDOracleZipToDestination> response = null;
	 * MasterZDOracleZipToDestination output =
	 * zipToDestService.addRecordToZipTodestInMemory(zipToDestAddRequest); if
	 * (output != null) { response = new ResponseEntity<>(output,
	 * HttpStatus.CREATED); } else { response = new
	 * ResponseEntity<>(HttpStatus.BAD_REQUEST); } return response; }
	 */

	@GetMapping("/updatedRecordsInRedis")
	public ZDValidateRecords getValidatedRecords() {
		return zipToDestService.getValidatedRecords();
	}

	/*********** Facility and ZipTodestHasDelta APIs ************/
	
	@GetMapping("/get/faclilityRecordsFromOracle")
	public ResponseEntity<List<FacilityDeltaOracle>> getAllFacilityRecordsFromOracle() {
		 return new  ResponseEntity<>(facilityService.getAllFacilityRecordsFromOracle(),HttpStatus.OK);
	}
	
	@GetMapping("/get/zipToDestHasDeltaRecordsFromOracle")
	public ResponseEntity<List<ZipToDestHasDeltaOracle>> getAllzipToDestHasDeltaFromOracle() {
		 return new ResponseEntity<>(zipToDestHasDeltaService.getAllZipToDestHasDeltaRecordsFromOracle(),HttpStatus.OK);
	}
	
	@PostMapping("/saveFacilityDataFromOracleToRedis")
	public RenderRedisResponse saveFacilityDataFromOracleToRedis() {
		return facilityService.saveFacilityOracleFacilityDataToRedis();
	}

	@PostMapping("/saveZipToDestHasDeltaDataFromOracleToRedis")
	public RenderRedisResponse saveZipToDestHasDeltaDataFromOracletoredis() {
		return zipToDestHasDeltaService.saveZipToDestHasDeltaOracleDataToRedis();
	}
	/********* End of Facility and ZipToDestHasDelta APIs***************/

}
