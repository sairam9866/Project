package org.fedex.zd.cache.repository.impl;

import java.util.List;

import javax.annotation.PostConstruct;

import org.fedex.zd.cache.model.ZDRedisTransactional;
import org.fedex.zd.cache.repository.RedisRepository;
import org.fedex.zd.cache.util.ZipToDestConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

@Repository
public class RedisRepositoryImpl implements RedisRepository{
	
	@Autowired
	private RedisTemplate<String, ZDRedisTransactional> redisTemplate;
	private HashOperations<String, String, ZDRedisTransactional> hashOperations;
	private ZSetOperations<String, ZDRedisTransactional> zSetOperations;
	
	
	@PostConstruct
	public void init(){
		hashOperations = redisTemplate.opsForHash();
		zSetOperations = redisTemplate.opsForZSet();
	}

	@Override
	public List<ZDRedisTransactional> findAll() {
		List<ZDRedisTransactional> allTransactions = (List<ZDRedisTransactional>) hashOperations.values(ZipToDestConstants.APP_HASH_KEY);
		return allTransactions;
	}

	@Override
	public void add(ZDRedisTransactional zipToDest) {
		hashOperations.put(ZipToDestConstants.APP_HASH_KEY, zipToDest.getId(), zipToDest);
		zSetOperations.add(ZipToDestConstants.APP_TRANSACTION_TMSTMP_KEY, zipToDest, zipToDest.getCreatedDateTime());
		
	}

	@Override
	public void delete(String id) {
		hashOperations.delete(ZipToDestConstants.APP_HASH_KEY, id);		
	}

	@Override
	public ZDRedisTransactional findById(String id) {
		return hashOperations.get(ZipToDestConstants.APP_HASH_KEY, id);
	}

}
