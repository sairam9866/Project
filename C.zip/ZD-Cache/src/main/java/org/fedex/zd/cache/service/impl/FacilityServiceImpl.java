package org.fedex.zd.cache.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.fedex.zd.cache.model.FacilityDeltaOracle;
import org.fedex.zd.cache.model.FacilityDeltaRedis;
import org.fedex.zd.cache.model.RenderRedisResponse;
import org.fedex.zd.cache.repository.FacilityRepository;
import org.fedex.zd.cache.repository.impl.FacilityRedisRepository;
import org.fedex.zd.cache.service.FacilityService;
import org.fedex.zd.cache.util.ZipToDestConstants;
import org.fedex.zd.cache.util.ZipToDestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;


@Service
public class FacilityServiceImpl implements FacilityService {
	int rowsCount;
	int rowsExist;

	@Autowired
	FacilityRepository facilityRepository;
	
	@Autowired
	FacilityRedisRepository facilityRedisRepository;
	@Autowired
	ZipToDestUtil zipToDestUtil;
	@Resource(name = "redisTemplate")
	private ZSetOperations<String, FacilityDeltaRedis> sortedFacilityRedisSetOperations;

	@Override
	public List<FacilityDeltaOracle> getAllFacilityRecordsFromOracle() {
		return (List<FacilityDeltaOracle>) facilityRepository.findAll();
	}

	@Override
	public RenderRedisResponse saveFacilityOracleFacilityDataToRedis() {
		rowsExist = 0;
		rowsCount = 0;
		List<FacilityDeltaOracle> oracleFacilityDeltaList = (List<FacilityDeltaOracle>) facilityRepository.findAll();
		oracleFacilityDeltaList.stream().forEach(facilityDeltaOracleRecord -> {
			FacilityDeltaRedis newObject = zipToDestUtil.savefaclityOracleDataToRedis(facilityDeltaOracleRecord);

			if (!facilityRedisRepository.existsById(newObject.getId())) {
				
				sortedFacilityRedisSetOperations.add(ZipToDestConstants.FACILITY_HASH_KEY, newObject, newObject.getEffectiveDateTime());
				
				facilityRedisRepository.save(newObject);
				rowsCount++;
			} else {
				rowsExist++;
			}
		});
		RenderRedisResponse output = new RenderRedisResponse();
		output.setNoOfnewRecordsInsertedInRedis(String.valueOf(rowsCount));
		output.setNoOfRowsExistsInRedis(String.valueOf(rowsExist));
		output.setNoOfRecordsLoadedFromOracle(String.valueOf(facilityRepository.count()));
		return output;
	}

}
