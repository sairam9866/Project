package org.fedex.zd.cache.model;

public interface FacilityDeltaKeyRedis {
	public void buildKey();
}
