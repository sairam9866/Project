package org.fedex.zd.cache.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MasterZDOracleFacilityIdPK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "NETWORK")
	private String network;

	@Column(name = "FACILITY_ID")
	private int facilityId;

	@Column(name = "ZIP_CD")
	private String zipCode;

	@Column(name = "EFFECTIVE_DATE_TMSTP")
	private Timestamp effectiveDateTimestamp;

	public MasterZDOracleFacilityIdPK(String network, int facilityId, String zipCode, Timestamp effectiveDateTimestamp) {
		this.network = network;
		this.facilityId = facilityId;
		this.zipCode = zipCode;
		this.effectiveDateTimestamp = effectiveDateTimestamp;
	}

	public MasterZDOracleFacilityIdPK() {
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Timestamp getEffectiveDateTimestamp() {
		return effectiveDateTimestamp;
	}

	public void setEffectiveDateTimestamp(Timestamp effectiveDateTimestamp) {
		this.effectiveDateTimestamp = effectiveDateTimestamp;
	}
}
