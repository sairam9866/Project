package com.fedex.ziptodest.distribution.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.model.ZipToDestination;
import com.fedex.ziptodest.distribution.repository.ZipToDestRepository;
import com.fedex.ziptodest.distribution.service.impl.ZipToDestValidatorServiceImpl;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

@RunWith(SpringRunner.class)
public class ZipToDestValidatorServiceImplTest {

	@InjectMocks
	ZipToDestValidatorServiceImpl zipToDestValidatorService;

	@Mock
	ZipToDestRepository zipToDestRepository;

	@Mock
	ZipToDestUtil zipToDestUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testIsNetworkExist() {
		ZipToDestination dest = new ZipToDestination("LPN"+840+"11355","LPN", 840, "11355", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		when(zipToDestRepository.findFirstByNetwork("LPN")).thenReturn(dest);
		assertTrue(zipToDestValidatorService.isNetworkExist("LPN"));
		assertFalse(zipToDestValidatorService.isNetworkExist(""));
	}

	@Test
	public void testIsValidFacilityIdInteger() {
		when(zipToDestUtil.isValidFacilityId(1245)).thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidFacilityId(1245));
		assertFalse(zipToDestValidatorService.isValidFacilityId(12045));
	}

	@Test
	public void testIsValidFacilityIdString() {
		when(zipToDestUtil.isValidFacilityId("1245")).thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidFacilityId("1245"));
		assertFalse(zipToDestValidatorService.isValidFacilityId("12045"));
	}

	@Test
	public void testIsValidEpochTime() {
		when(zipToDestUtil.isValidEpochTime("1567493798")).thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidEpochTime("1567493798"));
		assertFalse(zipToDestValidatorService.isValidEpochTime("-123"));
	}

	@Test
	public void testIsValidApiKey() {
		when(zipToDestUtil.isValidApiKey(ZipToDestConstants.API_KEY_DDS, "l7e3cec65912a94392a73b1e3ffa8957d7"))
				.thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_DDS,
				"l7e3cec65912a94392a73b1e3ffa8957d7"));
		assertFalse(zipToDestValidatorService.isValidApiKey("api.key.invalid", "A4218C67947A8"));
	}
}
