package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class InvalidFacilityIdExceptionTest {
	InvalidFacilityIdException invalidFacilityIdException;

	InvalidFacilityIdException invalidFacilityIdExceptionParam;

	@Before
	public void init() {
		invalidFacilityIdException = new InvalidFacilityIdException();
		invalidFacilityIdExceptionParam = new InvalidFacilityIdException("Invalid Facility Id.");
	}

	@Test
	public void testEpochTimeFormatException() {

		assertNotNull(invalidFacilityIdException);
		assertNotNull(invalidFacilityIdExceptionParam);
		assertNotNull(invalidFacilityIdExceptionParam.getMessage());
	}
}
