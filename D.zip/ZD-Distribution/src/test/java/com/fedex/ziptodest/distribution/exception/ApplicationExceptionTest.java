package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;

public class ApplicationExceptionTest {

	ApplicationException applicationException = new ApplicationException();

	Throwable t = new Throwable();

	ApplicationException applicationException1 = new ApplicationException("code", "msg");

	ApplicationException applicationException2 = new ApplicationException("msg", t);

	ApplicationException applicationException3 = new ApplicationException(null);

	@Test
	public void ApplicationExceptionTest_positive() {
		assertEquals("code", applicationException1.getCode());
	}

	@Test
	public void ApplicationExceptionTest_negitive() {		
		assertNotEquals("codes", applicationException1.getCode());
	}

}
