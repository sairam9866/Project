/**
 * 
 */
package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;

/**
 * @author 3790999
 *
 */
public class TimestampResponseTest {

	ZipToDestHasDeltaResponse timestampResponse = new ZipToDestHasDeltaResponse();
	Timestamp timeStamp = Timestamp.valueOf(LocalDateTime.now());
	Boolean hasChanged = true;

	@Before
	public void addResponse() {
		timestampResponse.setNetwork("LPN");
		timestampResponse.setTimestamp(timeStamp);
		timestampResponse.setHasChanged(hasChanged);
	}

	@Test
	public void testTimestampResponse() {
		assertEquals("LPN", timestampResponse.getNetwork());
		assertEquals(timeStamp, timestampResponse.getTimestamp());
		assertEquals(hasChanged, timestampResponse.isHasChanged());
		timestampResponse.toString();
	}
}
