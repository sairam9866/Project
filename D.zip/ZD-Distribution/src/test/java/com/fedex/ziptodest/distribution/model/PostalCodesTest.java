/**
 * 
 */
package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;

/**
 * @author 3790999
 *
 */
public class PostalCodesTest {

	PostalCodes postalCodes = new PostalCodes();
	LocalDateTime time = LocalDateTime.now();
	PostalCodes postalCodes1 = new PostalCodes("801",time,"Hour","1091");
	
	@Before
	public void addPostalCode() {
		postalCodes.setCountryCd("840");
		postalCodes.setEffectiveTmstp(time);
		postalCodes.setExpirationTmstp("");
		postalCodes.setPostalCd("11235");
		
	}

	@Test
	public void testPostalCode_Positive() {
		assertEquals("840", postalCodes.getCountryCd());
		assertEquals(time, postalCodes.getEffectiveTmstp());
		assertEquals("", postalCodes.getExpirationTmstp());
		assertEquals("11235", postalCodes.getPostalCd());
		assertEquals("801",postalCodes1.getCountryCd());
		assertEquals("Hour",postalCodes1.getExpirationTmstp());
	}
	
	@Test
	public void testPostalCode_Negative() {
		assertNotEquals("844", postalCodes.getCountryCd());
		assertNotEquals("Time", postalCodes.getEffectiveTmstp());
		assertNotEquals("Minute", postalCodes.getExpirationTmstp());
		assertNotEquals("11233", postalCodes.getPostalCd());
		assertNotEquals("809",postalCodes1.getCountryCd());
		assertNotEquals("Half",postalCodes1.getExpirationTmstp());
	}
}
