package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;

public class HasDeltaByNetworkTest {

	HasDeltaByNetwork hasDeltaByNetwork=new HasDeltaByNetwork();
	Boolean hasChanged = true;
	
	
	@Before
	public void hasDeltaByNetwork(){
		hasDeltaByNetwork.setHasChanged(hasChanged);
		hasDeltaByNetwork.setNetwork("LPN");
	}
	
	@Test
	public void hasDeltaByNetwork_Positive(){
		assertEquals(hasChanged,hasDeltaByNetwork.isHasChanged());
		assertEquals("LPN",hasDeltaByNetwork.getNetwork());
	}
	
	@Test
	public void hasDeltaByNetwork_Negative(){
		assertNotEquals("false",hasDeltaByNetwork.isHasChanged());
		assertNotEquals("LPL",hasDeltaByNetwork.getNetwork());
	}
}
