package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class ExceptionResponseTest {

	List<String> list = new ArrayList<>();
	ExceptionResponse exceptionResponse = new ExceptionResponse("OK", "Valid");
	ExceptionResponse exceptionResponseParams = new ExceptionResponse("OK", "Valid", list);
	
	
	
	

	@Test
	public void testExceptionResponse_N() {
		exceptionResponse.setMessage("OK");
		exceptionResponse.setStatusCd("Valid");
		assertEquals("OK",exceptionResponse.getMessage());
		assertEquals("Valid",exceptionResponse.getStatusCd());
		assertEquals("Valid", exceptionResponse.getStatusCd());
		assertEquals("OK",exceptionResponse.getMessage());
		assertEquals("OK", exceptionResponseParams.getStatusCd());
		assertEquals("Valid",exceptionResponseParams.getMessage());
		assertNotNull(list);
	}

}
