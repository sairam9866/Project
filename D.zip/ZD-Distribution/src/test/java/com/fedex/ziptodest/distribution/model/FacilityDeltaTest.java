package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class FacilityDeltaTest {

	Long epoch = 1572816143L;
	FacilityDelta facilityDelta = new FacilityDelta();
	String toStringCheck = "FacilityDelta [id=NewId, network=LPZ, facilityId=105, zipCode=A0A, effectiveDateTime=1572816143, transactionType=A, uuId=Abcd, state=Canada]";

	@Before
	public void FacilityId_Positive() {

		facilityDelta.setState("Canada");
		facilityDelta.setTransactionType("A");
		facilityDelta.setUuId("Abcd");
		facilityDelta.setFacilityId(105);
		facilityDelta.setNetwork("LPZ");
		facilityDelta.setZipCode("A0A");
		facilityDelta.setEffectiveDateTime(epoch);
		facilityDelta.setId("NewId");

	}

	@Test
	public void TestFacilityId_Positive() {

		assertEquals("Canada", facilityDelta.getState());
		assertEquals("A", facilityDelta.getTransactionType());
		assertEquals("Abcd", facilityDelta.getUuId());
		assertNotNull(facilityDelta.getFacilityId());
		assertEquals("LPZ", facilityDelta.getNetwork());
		assertEquals("A0A", facilityDelta.getZipCode());
		assertEquals(epoch, facilityDelta.getEffectiveDateTime());
		assertEquals("NewId", facilityDelta.getId());

	}

	@Test
	public void hashCodeTest() {
		assertNotNull(facilityDelta.hashCode());

	}

	@Test
	public void toStringTest() {
		assertEquals(toStringCheck, facilityDelta.toString());
	}

	@Test
	public void equalsTest() {
		FacilityDelta secound = new FacilityDelta();
		secound.buildKey();
		secound.setEffectiveDateTime(1234L);
		secound.setFacilityId(12);
		secound.setId("OldId");
		secound.setNetwork("LPN");
		assertEquals(false, facilityDelta.equals(secound));
	}
}
