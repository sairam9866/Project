package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class ZipToDestHasDeltaTest {

	ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
	Long epoch = 1572816143L;
	String toStringCheck = "ZipToDestHasDelta [network=LPN, lastUpdateTimestamp=1572816143]";

	@Before
	public void zipToDestIntialData() {
		zipToDestHasDelta.setLastUpdateTimestamp(epoch);
		zipToDestHasDelta.setNetwork("LPN");
		zipToDestHasDelta.toString();
	}

	@Test
	public void networkEpochTest() {
		Long local = zipToDestHasDelta.getLastUpdateTimestamp();
		assertNotNull(local);
		assertEquals("LPN", zipToDestHasDelta.getNetwork());

	}

	@Test
	public void toStringTest() {
		assertEquals(toStringCheck, zipToDestHasDelta.toString());
	}

	@Test
	public void hashCodeTest() {
		assertNotNull(zipToDestHasDelta.hashCode());

	}

	@Test
	public void equalsTest() {
		ZipToDestHasDelta secound = new ZipToDestHasDelta();
		secound.setLastUpdateTimestamp(1572816143L);
		secound.setNetwork("LPN");
		assertEquals(true, zipToDestHasDelta.equals(secound));
	}

}
