package com.fedex.ziptodest.distribution.controllers;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.model.FacilityDeltaResponse;
import com.fedex.ziptodest.distribution.model.FacilityDistribution;
import com.fedex.ziptodest.distribution.model.TimestampResponseDelta;
import com.fedex.ziptodest.distribution.model.ZipToDestHasDeltaResponse;
import com.fedex.ziptodest.distribution.service.ZipToDestHasDeltaService;
import com.fedex.ziptodest.distribution.service.ZipToDestService;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

@RunWith(SpringRunner.class)
public class ZipToDestControllerTest {

	@InjectMocks
	private ZipToDestController zipToDestController;

	@Mock
	ZipToDestService zipToDestService;

	@Mock
	ZipToDestHasDeltaService zipToDestHasDeltaService;

	@Mock
	ZipToDestValidatorService zipToDestValidatorService;

	@Mock
	ZipToDestUtil zipToDestUtil;

	@Test
	public void testGetCanadaDistributions() {
		String network = "LPN";
		List<String> allCanadaDistributions = new ArrayList<>();
		Mockito.doReturn(allCanadaDistributions).when(zipToDestService).getAllDistributions(network);
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist(network);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		zipToDestController.getAllDistributions(network, "l7f607f4c712a84f1fb199811ff3a22a67");
		assertNotNull(zipToDestController);
	}

	// Start -- On hold this test cases for time being.
	@Test
	public void testGetAllFacilityDistributions() {
		String network = "LPN";
		List<FacilityDistribution> allFacilityDistributions = new ArrayList<>();
		Mockito.doReturn(allFacilityDistributions).when(zipToDestService).getAllFacilityDistributionsByNetwork(network);
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist(network);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		zipToDestController.getAllFacilityDistributionsByNetwork(network, "l7f607f4c712a84f1fb199811ff3a22a67");
		assertNotNull(zipToDestController);
	}
	// End

	@Test
	public void testGetFacilityDistributionsByID() {
		Mockito.doReturn(facilityDistributionResponse()).when(zipToDestService).getFacilityDistributionsByID("0011");
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidFacilityId("0011");
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		ResponseEntity<FacilityDistribution> facilityDistribution = zipToDestController
				.getFacilityDistributionByID("0011", "l7f77f456afcd24b51a145feb7d3997b84");
		assertNotNull(facilityDistribution);
	}

	@Test
	public void testGetTimeStampChange() {
		String network = "FXGL";
		String epochTime = "1568801193";
		Timestamp userGivenTimestamp = Timestamp.valueOf("2019-9-18 10:06:33");
		ZipToDestHasDeltaResponse timestampResponse = new ZipToDestHasDeltaResponse();

		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist(network);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidEpochTime(epochTime);

		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		Mockito.doReturn(userGivenTimestamp).when(zipToDestUtil).getTimestampFromEpochTime(epochTime);

		timestampResponse.setNetwork(network);
		timestampResponse.setTimestamp(userGivenTimestamp);
		timestampResponse.setHasChanged(false);
		Long longValue=1568801193L;
		Mockito.doReturn(timestampResponse).when(zipToDestHasDeltaService).isDeltaExist(network, longValue);

		zipToDestController.getTimeStampChange(network, epochTime, "l7f607f4c712a84f1fb199811ff3a22a67");
		assertNotNull(zipToDestController);
	}

	@Test
	public void testChangedDistributions() {
		String network = "LPN";
		Timestamp userGivenTimestamp = Timestamp.valueOf("2019-06-05 00:00:00.00");
		List<String> changes = new ArrayList<>();
		Long longValue=1568801193L;
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist(network);
		Mockito.doReturn(true).when(zipToDestValidatorService)
				.isValidEpochTime(Long.toString(userGivenTimestamp.toInstant().getEpochSecond()));
		Mockito.doReturn(changes).when(zipToDestService).changedNetworks(network, longValue);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		zipToDestController.getChangedDistributions(network,
				Long.toString(userGivenTimestamp.toInstant().getEpochSecond()), "l7f607f4c712a84f1fb199811ff3a22a67");
		assertNotNull(zipToDestController);
	}

	@Test
	public void testDestination() {
		String network = "LPN";
		String zipCode = "A0B0A0";
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist(network);
		Mockito.doReturn(true).when(zipToDestUtil).isValidUsCanadaZipCode(zipCode);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_DDS,
				"l7e3cec65912a94392a73b1e3ffa8957d7");
		zipToDestController.getDestination(network, zipCode, "l7e3cec65912a94392a73b1e3ffa8957d7");
		assertNotNull(zipToDestController);
	}

	@Test
	public void testGetDeltaByFacilityId() {
		Timestamp userGivenTimestamp = Timestamp.valueOf("2019-06-05 00:00:00.00");
		Long longValue=1568801193L;
		List<FacilityDeltaResponse> facilityResponseList = new ArrayList<>();
		Mockito.doReturn(true).when(zipToDestValidatorService)
				.isValidEpochTime(Long.toString(userGivenTimestamp.toInstant().getEpochSecond()));
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidFacilityId(1234);
		Mockito.doReturn(facilityResponseList).when(zipToDestService).getDeltasByFacilityId(1234, longValue);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		zipToDestController.getDeltaByFacilityId(1234, Long.toString(userGivenTimestamp.toInstant().getEpochSecond()),
				"l7f77f456afcd24b51a145feb7d3997b84");
		assertNotNull(zipToDestController);
	}

	@Test
	public void testGetHasDeltaByFacilityId() {
		Timestamp userGivenTimestamp = Timestamp.valueOf("2019-06-05 00:00:00.00");
		Long longValue=1568801193L;
		Mockito.doReturn(timestampResponseDeltaResponse()).when(zipToDestService).getHasDeltaByFacilityId(1234,
		longValue);
		Mockito.doReturn(true).when(zipToDestValidatorService)
				.isValidEpochTime(Long.toString(userGivenTimestamp.toInstant().getEpochSecond()));
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidFacilityId(1234);
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		ResponseEntity<TimestampResponseDelta> timestampResponseDelta = zipToDestController.getHasDeltaByFacilityId(
				1234, Long.toString(userGivenTimestamp.toInstant().getEpochSecond()),
				"l7f77f456afcd24b51a145feb7d3997b84");
		assertNotNull(timestampResponseDelta);
	}

	private FacilityDeltaResponse facilityResponse() {
		Multimap<String, String> innerMap = ArrayListMultimap.create();
		Map<String, Map<String, Collection<String>>> changeNetworks = new HashMap<>();
		// Map<String, Map<String, Collection<String>>> outerMap = new
		// HashMap<>();
		FacilityDeltaResponse facilityResponse = new FacilityDeltaResponse();
		innerMap.put("PA", "12345");
		changeNetworks.put("FXG", innerMap.asMap());
		facilityResponse.setFacilityId(1234);
		facilityResponse.setTransactionType("A");
		facilityResponse.setChangeNetworks(changeNetworks);
		return facilityResponse;
	}

	private FacilityDistribution facilityDistributionResponse() {
		Multimap<String, String> innerMap = ArrayListMultimap.create();
		Map<String, Map<String, Collection<String>>> assignedPostalCodes = new HashMap<>();
		innerMap.put("PA", "12345");
		assignedPostalCodes.put("FXG", innerMap.asMap());
		FacilityDistribution facilityDistribution = new FacilityDistribution();
		facilityDistribution.setCountryCD("124");
		facilityDistribution.setLegacyLocationNumber("1234");
		facilityDistribution.setOperationType("FCLTY");
		facilityDistribution.setAssignedPostalCodes(assignedPostalCodes);
		return facilityDistribution;
	}

	private TimestampResponseDelta timestampResponseDeltaResponse() {
		Set<String> networks = new HashSet<>();
		networks.add("LPN");
		TimestampResponseDelta timestampResponseDelta = new TimestampResponseDelta();
		timestampResponseDelta.setFacilityId(1234);
		/*
		 * timestampResponseDelta.setHasChanged(true);
		 * timestampResponseDelta.setNetwork(networks);
		 */
		return timestampResponseDelta;
	}
}