package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

public class FacilityDeltaResponseTest {

	Map<String, Map<String, Collection<String>>> outerMap = new HashMap<>();
	Multimap<String, String> innerMap = ArrayListMultimap.create();
	FacilityDeltaResponse FacilityDeltaResponse = new FacilityDeltaResponse();
	FacilityDeltaResponse FacilityDeltaResponseParam = new FacilityDeltaResponse();

	@Before
	public void testFacilityDeltaResponse() {

		FacilityDeltaResponse.setChangeNetworks(outerMap);
		FacilityDeltaResponse.setFacilityId(212);
		FacilityDeltaResponse.setTransactionType("Y");

	}

	@Test
	public void testFacilityDeltaResponse_Positive() {

		assertEquals(outerMap, FacilityDeltaResponse.getChangeNetworks());
		assertEquals(212, FacilityDeltaResponse.getFacilityId());
		assertEquals("Y", FacilityDeltaResponse.getTransactionType());
		assertEquals(0, FacilityDeltaResponseParam.getFacilityId());
	}

	@Test
	public void testFacilityDeltaResponse_Negative() {

		assertNotEquals(innerMap, FacilityDeltaResponse.getChangeNetworks());
		assertNotEquals(211, FacilityDeltaResponse.getFacilityId());
		assertNotEquals('N', FacilityDeltaResponse.getTransactionType());
		assertNotEquals(221, FacilityDeltaResponseParam.getFacilityId());
	}

}
