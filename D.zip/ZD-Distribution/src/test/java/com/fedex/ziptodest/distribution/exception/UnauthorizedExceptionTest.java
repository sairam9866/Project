package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class UnauthorizedExceptionTest {

	private UnauthorizedException unauthorizedException;
	private UnauthorizedException unauthorizedExceptionParam;

	@Before
	public void init() {
		unauthorizedException = new UnauthorizedException();
		unauthorizedExceptionParam = new UnauthorizedException("Unauthorized, Invalid API Key.");
	}

	@Test
	public void testEpochTimeFormatException() {
		assertNotNull(unauthorizedException);
		assertNotNull(unauthorizedExceptionParam);
		assertNotNull(unauthorizedExceptionParam.getMessage());
	}
}
