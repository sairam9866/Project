package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class HTTPInternalServerExceptionTest {

	HTTPInternalServerException httpInternalServerException=new HTTPInternalServerException();
	HTTPInternalServerException httpInternalServerExceptionParam=new HTTPInternalServerException("OK");
	
	@Test
	public void testHTTPInternalServerExceptionTest(){
		
		assertEquals("OK", httpInternalServerExceptionParam.getMessage());
	}
	
}
