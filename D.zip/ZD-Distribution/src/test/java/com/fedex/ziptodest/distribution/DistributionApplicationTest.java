/*package com.fedex.ziptodest.distribution;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;

import com.fedex.ziptodest.distribution.controllers.ZipToDestController;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@ContextConfiguration
@ComponentScan("com.fedex.ziptodest.distribution")
@SpringBootTest(classes = DistributionApplication.class)
@WebAppConfiguration
@RestController
@ActiveProfiles("local")
public class DistributionApplicationTest extends TestCase {

	private MockMvc mockMvc;
	@Autowired
	private WebApplicationContext context;

	@MockBean
	ZipToDestValidatorService zipToDestValidatorService;

	private HttpMessageConverter jackson2HttpMessageConverter;

	@Autowired
	private ZipToDestController zipToDestController;

	@Autowired
	void setConverters(HttpMessageConverter<?>[] converters) {
		this.jackson2HttpMessageConverter = Arrays.asList(converters).stream()
				.filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter).findAny().orElse(null);

		assertNotNull("the JSON message converter must not be null", this.jackson2HttpMessageConverter);
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	@Test
	public void testDistributionController() throws Exception {
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f77f456afcd24b51a145feb7d3997b84");
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist("LPN");
		mockMvc.perform(
				get("/zipToDest/distribution/byNetwork/LPN").header("apiKey", "l7f77f456afcd24b51a145feb7d3997b84"))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));

	}

	@Test
	public void contextLoads() {
		assertThat(zipToDestController).isNotNull();
	}

}
*/
