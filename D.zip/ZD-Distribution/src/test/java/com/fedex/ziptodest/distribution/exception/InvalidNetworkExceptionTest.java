package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class InvalidNetworkExceptionTest {

	private InvalidNetworkException invalidNetworkException;

	private InvalidNetworkException invalidNetworkExceptionParam;

	@Before
	public void init() {
		invalidNetworkException = new InvalidNetworkException();
		invalidNetworkExceptionParam = new InvalidNetworkException("Invalid Network.");
	}

	@Test
	public void testEpochTimeFormatException() {
		assertNotNull(invalidNetworkException);
		assertNotNull(invalidNetworkExceptionParam);
		assertNotNull(invalidNetworkExceptionParam.getMessage());
	}
}
