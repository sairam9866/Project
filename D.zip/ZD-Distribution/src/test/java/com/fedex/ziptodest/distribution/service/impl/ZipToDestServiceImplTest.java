package com.fedex.ziptodest.distribution.service.impl;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.exception.ApplicationException;
import com.fedex.ziptodest.distribution.exception.InvalidNetworkException;
import com.fedex.ziptodest.distribution.model.FacilityDelta;
import com.fedex.ziptodest.distribution.model.FacilityDeltaResponse;
import com.fedex.ziptodest.distribution.model.FacilityDistribution;
import com.fedex.ziptodest.distribution.model.TimestampResponseDelta;
import com.fedex.ziptodest.distribution.model.ZipToDestination;
import com.fedex.ziptodest.distribution.repository.FacilityRepository;
import com.fedex.ziptodest.distribution.repository.ZipToDestRepository;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;

@RunWith(SpringRunner.class)
public class ZipToDestServiceImplTest {

	@InjectMocks
	private ZipToDestServiceImpl zipToDestServiceImpl;

	@Mock
	private ZipToDestValidatorService zipToDestValidatorService;

	@Mock
	private FacilityRepository facilityRepository;

	@Mock
	ZipToDestRepository zipToDestRepo;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllDistrbutions() {
		String network = "LPN";
		when(zipToDestValidatorService.isNetworkExist(Mockito.anyString())).thenReturn(true);
		zipToDestServiceImpl.getAllDistributions(network);
	}

	@Test
	public void testGetAllDistrbutionsNegative() {
		String network = "LPN";
		assertThatExceptionOfType(InvalidNetworkException.class)
				.isThrownBy(() -> zipToDestServiceImpl.getAllDistributions(network));
	}

	@Test
	public void testGetDestinationCanada() {
		String network = "LPN";
		String zipCode = "A0D0A5";
		ZipToDestination dest = new ZipToDestination("LPN" + 840 + "11355", "LPN", 840, "11355", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		when(zipToDestRepo.findByNetworkAndZipCode(Mockito.anyString(), Mockito.anyString())).thenReturn(dest);
		zipToDestServiceImpl.getDestinationByNetworkAndZipCode(network, zipCode);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetDestinationUsa() {
		String network = "LPN";
		String zipCode = "11355";
		ZipToDestination dest = new ZipToDestination("LPN" + 840 + "11355", "LPN", 840, "11355", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		when(zipToDestRepo.findByNetworkAndZipCode(Mockito.anyString(), Mockito.anyString())).thenReturn(dest);
		zipToDestServiceImpl.getDestinationByNetworkAndZipCode(network, zipCode);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetChangedNetworks() {
		String network = "LPN";
		Timestamp userGivenTimestamp = Timestamp.valueOf(LocalDateTime.now());
		Long longValue=1568801193L;
		zipToDestServiceImpl.changedNetworks(network, longValue);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetCanadaDistributions() {
		String network = "FXG";
		zipToDestServiceImpl.getCanadaDistributions(network);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetUsaDistributions() {
		String network = "LPN";
		zipToDestServiceImpl.getUsaDistributions(network);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetAllFacilityDistributions() {
		String network = "LPN";
		zipToDestServiceImpl.getAllFacilityDistributionsByNetwork(network);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testgetFacilityDistributionsByID() {
		String facilityID = "6011";
		Sort sort = Sort.by(Sort.Order.asc("id.network"), Sort.Order.asc("id.zipCode"));
		when(zipToDestRepo.findByDestination(facilityID)).thenReturn(listOfZipToDestination());
		FacilityDistribution facilityDistribution = zipToDestServiceImpl.getFacilityDistributionsByID(facilityID);
		assertNotNull(facilityDistribution);
		facilityDistribution = zipToDestServiceImpl.getFacilityDistributionsByID("1234");
		assertNotNull(facilityDistribution);
	}

	@Test
	public void testgetFacilityDistributionsByIDNegative() {
		String facilityID = "";
		assertThatExceptionOfType(ApplicationException.class)
				.isThrownBy(() -> zipToDestServiceImpl.getFacilityDistributionsByID(facilityID))
				.withMessage(ZipToDestConstants.MSG_INVALID_REQUEST);
	}

	@Test
	public void testGetDistributionList() {
		List<String> distributionList = zipToDestServiceImpl.getDistributionsList(listOfZipToDestination());
		assertNotNull(distributionList);
	}

	@Test
	public void testsetFacilityDistribution() {
		List<FacilityDistribution> distributionList = zipToDestServiceImpl
				.setFacilityDistributions(new ArrayList<FacilityDistribution>(), listOfZipToDestination());
		assertNotNull(distributionList);
	}

	@Test
	public void testGetDeltasByFacilityId() {
		String addTransactionType = "A";
		Timestamp userGivenTimestamp = Timestamp.valueOf("2019-06-05 00:00:00.00");

		FacilityDelta facilityDelta = new FacilityDelta();
		facilityDelta.setNetwork("LPN");
		facilityDelta.setZipCode("1234");
		facilityDelta.setEffectiveDateTime(123L);
		facilityDelta.setFacilityId(12);
		facilityDelta.setId("Some");
		facilityDelta.setState("ABC");
		facilityDelta.setTransactionType(addTransactionType);

		List<FacilityDelta> deltaFacilityList = new ArrayList<>();
		deltaFacilityList.add(facilityDelta);

		Long longValue=1568801193L;
		when(facilityRepository.findByFacilityId(addTransactionType, facilityDelta.getFacilityId(), longValue))
				.thenReturn(deltaFacilityList);

		List<FacilityDeltaResponse> facilityResponse = zipToDestServiceImpl
				.getDeltasByFacilityId(facilityDelta.getFacilityId(), longValue);
		assertNotNull(facilityResponse);
	}

	@Test
	public void testsetFacilityResponse() {
		Timestamp userGivenTimestamp = new Timestamp(20190806);
		String addTransactionType = "A";
		int facilityId = 1241;
		Long longValue=1568801193L;
		List<FacilityDelta> addFacilitylist = facilityRepository.findByFacilityId(addTransactionType, facilityId,
				longValue);
		FacilityDeltaResponse facilityResponseList = zipToDestServiceImpl.setFacilityResponse(addFacilitylist);
		assertNotNull(facilityResponseList);
	}

	@Test
	public void testGetHasDeltaByFacilityId() {
		List<String> networks = new ArrayList<String>();
		networks.add("FXG");
		networks.add("FXO");

		FacilityDelta facilityIdPK = new FacilityDelta();
		facilityIdPK.setNetwork("LPN");
		facilityIdPK.setNetwork("FXO");
		facilityIdPK.setZipCode("1234");

		List<FacilityDelta> hasDeltaFacilityList = new ArrayList<>();
		FacilityDelta facilityId = new FacilityDelta();
		facilityId.setState("PA");
		hasDeltaFacilityList.add(facilityId);

		Timestamp userGivenTimestamp = Timestamp.valueOf("2019-06-05 00:00:00.00");
		when(zipToDestRepo.findDistinctNetwork()).thenReturn(networks);
		Long longValue=1568801193L;
		when(facilityRepository.findFacilityHasDelta(1234, longValue)).thenReturn(hasDeltaFacilityList);
/*
		TimestampResponseDelta timestampResponseDelta = zipToDestServiceImpl.getHasDeltaByFacilityId(1234,
				longValue);
		assertNotNull(timestampResponseDelta);*/
	}

	private List<ZipToDestination> listOfZipToDestination() {
		ZipToDestination dest1 = new ZipToDestination("LPN" + 124 + "A0D0B1", "LPN", 124, "A0D0B1", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest2 = new ZipToDestination("LPN" + 124 + "A0C", "LPN", 124, "A0C", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest3 = new ZipToDestination("LPN" + 124 + "A0A", "LPN", 124, "A0A", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest4 = new ZipToDestination("LPN" + 124 + "A0D0A3", "LPN", 124, "A0D0A3", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest5 = new ZipToDestination("LPN" + 124 + "A0B", "LPN", 124, "A0B", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest6 = new ZipToDestination("LPN" + 124 + "A0D0A1", "LPN", 124, "A0D0A1", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");

		List<ZipToDestination> zipToDest = Arrays.asList(dest1, dest2, dest3, dest4, dest5, dest6);
		return zipToDest;
	}

}
