/**
 * 
 */
package com.fedex.ziptodest.distribution.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

/**
 * @author 3790999
 *
 */
@Ignore
public class ZipToDestServiceImplTest {

	/**
	 * Test method for {@link com.fedex.ziptodest.distribution.service.impl.ZipToDestServiceImpl#getCanadaDestinations()}.
	 */
	@Test
	public void testGetCanadaDestinations() {
		fail("Not yet implemented"); 
	}

	/**
	 * Test method for {@link com.fedex.ziptodest.distribution.service.impl.ZipToDestServiceImpl#getUsaDestinations()}.
	 */
	@Test
	public void testGetUsaDestinations() {
		fail("Not yet implemented"); 
	}

}
