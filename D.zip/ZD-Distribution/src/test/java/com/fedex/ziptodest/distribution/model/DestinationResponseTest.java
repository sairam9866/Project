/**
 * 
 */
package com.fedex.ziptodest.distribution.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * @author 3790999
 *
 */
public class DestinationResponseTest {

	DestinationResponse destResponse = new DestinationResponse();

	@Before
	public void addDestination() {
		destResponse.setDestination("FXG");
	}

	@Test
	public void testDestinationResponse() {
		assertEquals("FXG", destResponse.getDestination());
		destResponse.toString();
	}

	
}
