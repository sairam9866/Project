package com.fedex.ziptodest.distribution.model;

public class HasDeltaByNetwork {
	private String network;
	private boolean hasChanged;

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public boolean isHasChanged() {
		return hasChanged;
	}

	public void setHasChanged(boolean hasChanged) {
		this.hasChanged = hasChanged;
	}

}
