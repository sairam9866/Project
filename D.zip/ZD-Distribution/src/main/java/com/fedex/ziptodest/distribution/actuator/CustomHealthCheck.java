package com.fedex.ziptodest.distribution.actuator;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;


@Component
public class CustomHealthCheck implements HealthIndicator {

    private static final Logger log = LoggerFactory.getLogger(CustomHealthCheck.class);

    @Autowired
    DataSource dataSource;
    
    @Autowired
	CacheManager cacheManager;
    
    //@Value("${app.status}")
    @Value("true")
    private Boolean appStatus;

    @Override
    public Health health() {
    	
    	  // check cache is available 
        Cache cache = cacheManager.getCache("allDistributions");
        
        if (cache == null) {
        	log.warn("Cache not available");
            return Health.down().withDetail("smoke test", "cache not available").build();
        }
        // check db available
        try (Connection connection = dataSource.getConnection()) {
        	log.info("Connected DB");
        } catch (SQLException e) {
            log.warn("DB not available");
            return Health.down().withDetail("smoke test", e.getMessage()).build();
        }
        
        //app status
        if(appStatus){
            log.info("In service");
            return Health.up().withDetail("ZD-Distribution status ","In service").build();
        }else {
        log.info("Not in service");
        return Health.outOfService().withDetail("ZD-Distribution status","Out of service").build();
        }
        
    }
}

