package com.fedex.ziptodest.distribution.controllers;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.distribution.exception.EpochTimeFormatException;
import com.fedex.ziptodest.distribution.exception.InvalidFacilityIdException;
import com.fedex.ziptodest.distribution.exception.InvalidNetworkException;
import com.fedex.ziptodest.distribution.exception.InvalidZipCodeException;
import com.fedex.ziptodest.distribution.exception.UnauthorizedException;
import com.fedex.ziptodest.distribution.model.DestinationResponse;
import com.fedex.ziptodest.distribution.model.FacilityDeltaResponse;
import com.fedex.ziptodest.distribution.model.FacilityDistribution;
import com.fedex.ziptodest.distribution.model.TimestampResponseDelta;
import com.fedex.ziptodest.distribution.model.ZipToDestHasDeltaResponse;
import com.fedex.ziptodest.distribution.service.CachingService;
import com.fedex.ziptodest.distribution.service.ZipToDestHasDeltaService;
import com.fedex.ziptodest.distribution.service.ZipToDestService;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author 3790999
 *
 */

@RestController
@RequestMapping("/zipToDest/distribution")
public class ZipToDestController {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestController.class);

	@Autowired
	ZipToDestService zipToDestService;

	@Autowired
	ZipToDestHasDeltaService zipToDestHasDeltaService;

	@Autowired
	CachingService cachingService;

	@Autowired
	ZipToDestValidatorService zipToDestValidatorService;

	@Autowired
	ZipToDestUtil zipToDestUtil;

	/**
	 * Shows output of all destinations zipcode association in ranges format for
	 * a particular network.
	 * 
	 * @param network
	 *            Network Code
	 * @param apiKey
	 *            Rest API Key
	 * 
	 * @return Return a list of networks.
	 */
	@ApiOperation(notes = "All destinations zipcode association", value = "Shows output of all destinations zipcode association in ranges format for a particular network")
	@ApiResponses(value = { @ApiResponse(code = 404, message = ZipToDestConstants.STATUS_CODE_INVALID_NETWORK),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/byNetwork/{network}")
	public ResponseEntity<List<String>> getAllDistributions(@PathVariable("network") String network,
			@RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getAllDistributions - Network Code : {}", network);
		LOGGER.debug("ZipToDestController::getAllDistributions - API Key : {}", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_SORT_X, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		}

		List<String> distributions = zipToDestService.getAllDistributions(network);
		LOGGER.debug("ZipToDestController::getAllDistributions - Returning {} Distribution(s) for Network Code - {}",
				distributions.size(), network);

		return new ResponseEntity<>(distributions, HttpStatus.OK);
	}

	/**
	 * Shows output of all destination zip associations for a particular
	 * network.
	 * 
	 * @param network
	 *            Network Code
	 * @param apiKey
	 *            Rest API Key
	 * @return Returns a list.
	 */
	@ApiOperation(notes = "All locations for a network", value = "Shows output of all destination zip associations for a particular network")
	@ApiResponses(value = { @ApiResponse(code = 404, message = ZipToDestConstants.STATUS_CODE_INVALID_NETWORK),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success.") })
	// On hold for time being
	// @GetMapping(value = "/locationAllByNetwork/{network}")
	public ResponseEntity<List<FacilityDistribution>> getAllFacilityDistributionsByNetwork(
			@PathVariable("network") String network, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getAllFacilityDistributionsByNetwork - Network Code : {}", network);
		LOGGER.debug("ZipToDestController::getAllFacilityDistributionsByNetwork - API Key : {}", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_SORT_X, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isNetworkExist(network)) {
			throw new InvalidNetworkException(ZipToDestConstants.MSG_NETWORK_NOT_FOUND);
		}

		List<FacilityDistribution> allFacilityDistByNetwork = zipToDestService
				.getAllFacilityDistributionsByNetwork(network.toUpperCase());

		LOGGER.debug(
				"ZipToDestController::getAllFacilityDistributionsByNetwork - Returning {} Facility Distribution By Network - {}.",
				allFacilityDistByNetwork.size(), network);
		return new ResponseEntity<>(allFacilityDistByNetwork, HttpStatus.OK);
	}

	/**
	 * Shows output of zip associations for a particular destination terminal in
	 * a network.
	 * 
	 * @param network
	 *            Network Code.
	 * @param facilityId
	 *            Facility Id
	 * @param apiKey
	 *            Rest API Key.
	 * @return
	 */
	@ApiOperation(notes = "Location by Facility ID", value = "Shows output of zip associations for a particular destination terminal in a network")
	@ApiResponses(value = { @ApiResponse(code = 400, message = ZipToDestConstants.STATUS_CODE_INVALID_FACILITY_ID),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success.", response = FacilityDistribution.class) })
	@GetMapping(value = "/locationByFacilityID/{facilityID}")
	public ResponseEntity<FacilityDistribution> getFacilityDistributionByID(
			@PathVariable("facilityID") String facilityId, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getFacilityDistributionByID - facilityId : {}", facilityId);
		LOGGER.debug("ZipToDestController::getFacilityDistributionByID - apiKey : {}", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isValidFacilityId(facilityId)) {
			throw new InvalidFacilityIdException(ZipToDestConstants.MSG_FACILITY_ID_NOT_FOUND);
		}

		FacilityDistribution facilityDistributions = zipToDestService.getFacilityDistributionsByID(facilityId);

		LOGGER.debug("ZipToDestController::getFacilityDistributionByID - Returning {} by facilityId - {}",
				facilityDistributions, facilityId);

		return new ResponseEntity<>(facilityDistributions, HttpStatus.OK);
	}

	/**
	 * Checks if changes exist for network since given epoch time in seconds
	 * string
	 * 
	 * @param network
	 *            Network Code
	 * @param userGivenTimestamp
	 *            Epoch time
	 * @param apiKey
	 *            REST API Key.
	 * @return returns TimestampResponse
	 */
	@ApiOperation(notes = "Timestamp API follows the GMT timestamp", value = "Checks if changes exist for network since given epoch time in seconds string")
	@ApiResponses(value = { @ApiResponse(code = 404, message = ZipToDestConstants.STATUS_CODE_INVALID_NETWORK),
			@ApiResponse(code = 400, message = ZipToDestConstants.STATUS_CODE_INVALID_EPOCH_TIME),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success.", response = ZipToDestHasDeltaResponse.class) })
	@GetMapping(value = "/hasDelta/{network}/{epochTime}")
	public ResponseEntity<ZipToDestHasDeltaResponse> getTimeStampChange(@PathVariable("network") String network,
			@PathVariable("epochTime") String epochTime, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getTimeStampChange - Network Code : {}", network);
		LOGGER.debug("ZipToDestController::getTimeStampChange - Epoch Time : {}", epochTime);
		LOGGER.debug("ZipToDestController::getTimeStampChange - apiKey : {}", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_SORT_X, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isNetworkExist(network)) {
			throw new InvalidNetworkException(ZipToDestConstants.MSG_NETWORK_NOT_FOUND);
		} else if (!zipToDestValidatorService.isValidEpochTime(epochTime)) {
			throw new EpochTimeFormatException(ZipToDestConstants.MSG_EPOCH_TIME_BAD_REQUEST);
		}

		ZipToDestHasDeltaResponse zipToDestHasDeltaResponse = zipToDestHasDeltaService.isDeltaExist(network,
				Long.parseLong(epochTime));

		if (zipToDestHasDeltaResponse.isHasChanged()) {
			LOGGER.info("Caching evicted as data has changed");
			cachingService.evictAllCaches();
		}

		LOGGER.debug("ZipToDestController::getTimeStampChange - Returning response as {}. ", zipToDestHasDeltaResponse);
		return new ResponseEntity<>(zipToDestHasDeltaResponse, HttpStatus.OK);
	}

	/**
	 * Shows output of changed distributions in a network since given timestamp
	 * 
	 * @param network
	 *            Network Code
	 * @param userGivenTimestamp
	 *            Epoch Time
	 * @param apiKey
	 *            REST API Key
	 * @return Returns a list.
	 */
	@ApiOperation(notes = "Shows deltas", value = "Shows output of changed distributions in a network since given timestamp")
	@ApiResponses(value = { @ApiResponse(code = 404, message = ZipToDestConstants.STATUS_CODE_INVALID_NETWORK),
			@ApiResponse(code = 400, message = ZipToDestConstants.STATUS_CODE_INVALID_EPOCH_TIME),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success.") })
	@GetMapping(value = "/deltas/byNetwork/{network}/{epochTime}")
	public ResponseEntity<List<String>> getChangedDistributions(@PathVariable("network") String network,
			@PathVariable("epochTime") String epochTime, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getChangedDistributions - Network Code : {} ", network);
		LOGGER.debug("ZipToDestController::getChangedDistributions - epochTime : {} ", epochTime);
		LOGGER.debug("ZipToDestController::getChangedDistributions - apiKey : {} ", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_SORT_X, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isNetworkExist(network)) {
			throw new InvalidNetworkException(ZipToDestConstants.MSG_NETWORK_NOT_FOUND);
		} else if (!zipToDestValidatorService.isValidEpochTime(epochTime)) {
			throw new EpochTimeFormatException(ZipToDestConstants.MSG_EPOCH_TIME_BAD_REQUEST);
		}

		List<String> changes = zipToDestService.changedNetworks(network.toUpperCase(), Long.parseLong(epochTime));

		LOGGER.debug("ZipToDestController::getChangedDistributions - Returning {} Changed Dsitribution(s). ",
				changes.size());
		return new ResponseEntity<>(changes, HttpStatus.OK);
	}

	/**
	 * Populate destination which is filter with the combination of network and
	 * zipcode
	 * 
	 * @param network
	 *            User inputs - Network Code
	 * @param zipCode
	 *            User input either USA zipCode or Canada postal code.
	 * @param apiKey
	 *            REST API KEy
	 * @return Returns DestinationResponse
	 */
	@ApiOperation(value = "Populate destination which is filter with the combination of network and zipcode")
	@ApiResponses(value = {
			@ApiResponse(code = 404, message = ZipToDestConstants.STATUS_CODE_INVALID_NETWORK + " / "
					+ ZipToDestConstants.STATUS_CODE_INVALID_ZIPCODE),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 204, message = ZipToDestConstants.STATUS_CODE_NO_CONTENT),
			@ApiResponse(code = 200, message = "Success.", response = DestinationResponse.class) })
	@GetMapping(value = "/byNetworkAndZipCode/{network}/{zipCode}")
	public ResponseEntity<DestinationResponse> getDestination(@PathVariable("network") String network,
			@PathVariable("zipCode") String zipCode, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getDestination - Network Code : {} ", network);
		LOGGER.debug("ZipToDestController::getDestination - Zip Code : {} ", zipCode);
		LOGGER.debug("ZipToDestController::getDestination - apiKey : {} ", apiKey);
		ResponseEntity<DestinationResponse> response = null;

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_DDS, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isNetworkExist(network)) {
			throw new InvalidNetworkException(ZipToDestConstants.MSG_NETWORK_NOT_FOUND);
		} else if (!zipToDestUtil.isValidUsCanadaZipCode(zipCode)) {
			throw new InvalidZipCodeException(ZipToDestConstants.MSG_ZIPCODE_NOT_FOUND);
		}

		DestinationResponse destinationResponse = zipToDestService
				.getDestinationByNetworkAndZipCode(network.toUpperCase(), zipCode.toUpperCase());

		LOGGER.debug("ZipToDestController::getDestination - Returning Destination response as {}. ",
				destinationResponse);

		if (destinationResponse != null && StringUtils.isNotEmpty(destinationResponse.getDestination())) {
			response = new ResponseEntity<>(destinationResponse, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(destinationResponse, HttpStatus.NO_CONTENT);
		}
		return response;
	}

	/**
	 * Delta by facility id
	 * 
	 * @param facilityId
	 *            Facility Id
	 * @param userGivenTimestamp
	 *            Epoch Time
	 * @param apiKey
	 *            REST API Key
	 * @return Returns a list of FacilityResponse
	 */
	@ApiOperation(value = "Delta by facility id.")
	@ApiResponses(value = {
			@ApiResponse(code = 400, message = ZipToDestConstants.STATUS_CODE_INVALID_FACILITY_ID + " / "
					+ ZipToDestConstants.STATUS_CODE_INVALID_EPOCH_TIME),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success.") })
	@GetMapping(value = "/deltaByFacilityId/{facilityId}/{epochTime}")
	public ResponseEntity<List<FacilityDeltaResponse>> getDeltaByFacilityId(@PathVariable("facilityId") int facilityId,
			@PathVariable("epochTime") String epochTime, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getDeltaByFacilityId - facilityId : {}", facilityId);
		LOGGER.debug("ZipToDestController::getDeltaByFacilityId - epochTime : {}", epochTime);
		LOGGER.debug("ZipToDestController::getDeltaByFacilityId - apiKey : {}", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isValidFacilityId(facilityId)) {
			throw new InvalidFacilityIdException(ZipToDestConstants.MSG_FACILITY_ID_NOT_FOUND);
		} else if (!zipToDestValidatorService.isValidEpochTime(epochTime)) {
			throw new EpochTimeFormatException(ZipToDestConstants.MSG_EPOCH_TIME_BAD_REQUEST);
		}

		List<FacilityDeltaResponse> facilityResponse = zipToDestService.getDeltasByFacilityId(facilityId,
				Long.parseLong(epochTime));

		LOGGER.debug("ZipToDestController::getDeltaByFacilityId - Returning {} FacilityResponse(s). ",
				facilityResponse.size());
		return new ResponseEntity<>(facilityResponse, HttpStatus.OK);
	}

	/**
	 * Response contains FacilityId, userGivenTimestamp, and
	 * hasDeltaNetworkChanged with true if timestamp is greater then the
	 * userGivenTimestamp else false.
	 * 
	 * @param facilityId
	 *            User gives facility as input.
	 * @param userGivenTimestamp
	 *            User gives userGivenTimestamp as input.
	 * @param REST
	 *            API Key
	 * @return
	 */
	@ApiOperation(value = "Delta by facility id and epoch time.")
	@ApiResponses(value = {
			@ApiResponse(code = 400, message = ZipToDestConstants.STATUS_CODE_INVALID_FACILITY_ID + " / "
					+ ZipToDestConstants.STATUS_CODE_INVALID_EPOCH_TIME),
			@ApiResponse(code = 401, message = ZipToDestConstants.STATUS_CODE_UNAUTHORIZED),
			@ApiResponse(code = 200, message = "Success.", response = TimestampResponseDelta.class) })
	@GetMapping(value = "/hasDeltaByFacilityId/{facilityId}/{epochTime}")
	public ResponseEntity<TimestampResponseDelta> getHasDeltaByFacilityId(@PathVariable("facilityId") int facilityId,
			@PathVariable("epochTime") String epochTime, @RequestHeader("apiKey") String apiKey) {
		LOGGER.debug("ZipToDestController::getHasDeltaByFacilityId - facilityId : {} ", facilityId);
		LOGGER.debug("ZipToDestController::getHasDeltaByFacilityId - epochTime : {} ", epochTime);
		LOGGER.debug("ZipToDestController::getHasDeltaByFacilityId - epochTime : {} ", apiKey);

		if (!zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL, apiKey)) {
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		} else if (!zipToDestValidatorService.isValidFacilityId(facilityId)) {
			throw new InvalidFacilityIdException(ZipToDestConstants.MSG_FACILITY_ID_NOT_FOUND);
		} else if (!zipToDestValidatorService.isValidEpochTime(epochTime)) {
			throw new EpochTimeFormatException(ZipToDestConstants.MSG_EPOCH_TIME_BAD_REQUEST);
		}

		TimestampResponseDelta timestampResponseDelta = zipToDestService.getHasDeltaByFacilityId(facilityId,
				Long.parseLong(epochTime));

		LOGGER.debug("ZipToDestController::getHasDeltaByFacilityId - Returning TimestampResponseDelta response as {}.",
				timestampResponseDelta);
		return new ResponseEntity<>(timestampResponseDelta, HttpStatus.OK);
	}

}
