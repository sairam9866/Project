package com.fedex.ziptodest.distribution.service.impl;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.distribution.exception.ApplicationException;
import com.fedex.ziptodest.distribution.exception.HTTPInternalServerException;
import com.fedex.ziptodest.distribution.exception.InvalidNetworkException;
import com.fedex.ziptodest.distribution.exception.InvalidZipCodeException;
import com.fedex.ziptodest.distribution.model.DestinationResponse;
import com.fedex.ziptodest.distribution.model.FacilityDelta;
import com.fedex.ziptodest.distribution.model.FacilityDeltaResponse;
import com.fedex.ziptodest.distribution.model.FacilityDistribution;
import com.fedex.ziptodest.distribution.model.HasDeltaByNetwork;
import com.fedex.ziptodest.distribution.model.PostalCodes;
import com.fedex.ziptodest.distribution.model.TimestampResponseDelta;
import com.fedex.ziptodest.distribution.model.ZipToDestination;
import com.fedex.ziptodest.distribution.repository.FacilityRepository;
import com.fedex.ziptodest.distribution.repository.ZipToDestRepository;
import com.fedex.ziptodest.distribution.service.ZipToDestService;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDest;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants.CountryCode;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

/**
 * @author 3790999
 *
 */
@Service
public class ZipToDestServiceImpl implements ZipToDestService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestServiceImpl.class);

	@Autowired
	ZipToDestRepository zipToDestRepo;

	@Autowired
	FacilityRepository facilityRepository;

	@Autowired
	ZipToDestValidatorService zipToDestValidatorService;
	
	@Autowired
	ZipToDestUtil zipToDestUtil;

	@Override
	@Cacheable(value = "allDistributions", key = "#network")
	public List<String> getAllDistributions(String network) {

		if (!zipToDestValidatorService.isNetworkExist(network)) {
			throw new InvalidNetworkException(ZipToDestConstants.MSG_NETWORK_NOT_FOUND);
		}

		LOGGER.debug("ZipToDestServiceImpl::getCanadaDistributions - Network Code : {} ", network);
		List<String> distributions = new ArrayList<>();
		try {
			List<String> canadaDistributions = getCanadaDistributions(network.toUpperCase());
			List<String> usaDistributions = getUsaDistributions(network.toUpperCase());

			distributions.addAll(canadaDistributions);
			distributions.addAll(usaDistributions);
			LOGGER.debug(
					"ZipToDestServiceImpl::getAllDistributions - Returning {} Distribution(s) for Network Code - {}",
					distributions.size(), network);
		} catch (Exception e) {
			throw new HTTPInternalServerException(ZipToDestConstants.STATUS_CODE_INVALID_SERVER_ERROR);
		}
		return distributions;
	}

	public List<String> getCanadaDistributions(String network) {
		LOGGER.debug("ZipToDestServiceImpl::getCanadaDistributions - Network Code : {} ", network);
		List<ZipToDestination> destinations = new ArrayList<>();
		int countryCode = (CountryCode.CA.getCode());
		// 3 digit zip codes
		zipToDestRepo.findByCountryCodeAndNetwork(countryCode, network).forEach(destinations::add);
		List<String> digit3Destinations = getDistributionsList(destinations);
		LOGGER.debug("Found {} 3 digit canadian zipcode destination.", digit3Destinations.size());

		destinations = new ArrayList<>();
		return digit3Destinations;
	}

	public List<String> getUsaDistributions(String network) {
		LOGGER.debug("ZipToDestServiceImpl::getUsaDistributions - Network Code : {} ", network);

		List<ZipToDestination> destinations = new ArrayList<>();
		List<String> usaDistributions;
		zipToDestRepo.findByCountryCodeAndNetwork(CountryCode.US.getCode(), network).forEach(destinations::add);
		sortZipCodes(destinations);
		usaDistributions = getDistributionsList(destinations);
		LOGGER.debug(
				"ZipToDestServiceImpl::getUsaDistributions - : Returning {} USA Distribution by Network code - {} ",
				usaDistributions.size(), network);

		return usaDistributions;
	}

	@Override
	public List<FacilityDistribution> getAllFacilityDistributionsByNetwork(String network) {
		LOGGER.debug("ZipToDestServiceImpl::getAllFacilityDistributionsByNetwork - Network Code - {} ", network);

		List<FacilityDistribution> allLocationsByNetwork = new ArrayList<>();
		List<ZipToDestination> allDestinations = new ArrayList<>();

		if (null != network) {
			Sort sort = Sort.by(Sort.Order.asc("countryCode"), Sort.Order.asc("destination"),
					Sort.Order.asc("zipCode"));
			zipToDestRepo.findByNetwork(sort, network).forEach(allDestinations::add);
		}
		allLocationsByNetwork = setFacilityDistributions(allLocationsByNetwork, allDestinations);
		LOGGER.debug(
				"ZipToDestServiceImpl::getAllFacilityDistributionsByNetwork - Returning {} Facility Distribution(s).",
				allLocationsByNetwork.size());

		return allLocationsByNetwork;
	}

	@Override
	public FacilityDistribution getFacilityDistributionsByID(String facilityId) {
		LOGGER.debug("ZipToDestServiceImpl::getFacilityDistributionsByID - facilityID : {} ", facilityId);

		if (StringUtils.isNotEmpty(facilityId)) {
			List<ZipToDestination> allDestinations = zipToDestRepo.findByDestination(facilityId);

			FacilityDistribution facilityDistribution = setFacilityZipCodesDistributions(allDestinations);
			LOGGER.debug("ZipToDestServiceImpl::getFacilityDistributionsByID - Returning  FacilityDistribution.");

			return facilityDistribution;
		} else {
			throw new ApplicationException("400", ZipToDestConstants.MSG_INVALID_REQUEST);
		}
	}

	/**
	 * @param allLocations
	 * @param allDestinations
	 * @return
	 */
	protected FacilityDistribution setFacilityZipCodesDistributions(List<ZipToDestination> allDestinations) {

		ListIterator<ZipToDestination> iterator = allDestinations.listIterator();
		Map<String, Map<String, Collection<String>>> outerMap = new HashMap<>();
		Multimap<String, String> innerMap = ArrayListMultimap.create();
		FacilityDistribution facilityDist = new FacilityDistribution();
		facilityDist.setOperationType(ZipToDestConstants.OPERATION_TYPE);
		String previousNetwork = "";

		while (iterator.hasNext()) {
			ZipToDestination destination = iterator.next();

			facilityDist.setLegacyLocationNumber(StringUtils.leftPad(destination.getDestination(), 4, '0'));
			facilityDist.setCountryCD(String.valueOf(destination.getCountryCode()));
			final String currentNetwork = destination.getNetwork();

			if ((StringUtils.compareIgnoreCase(previousNetwork, currentNetwork) != 0)) {
				innerMap = ArrayListMultimap.create();
			}

			if (destination.getCountryCode() == 840) {
				innerMap.put(destination.getState(), StringUtils.truncate(destination.getZipCode(), 5));
			} else {
				innerMap.put(destination.getState(), destination.getZipCode());
			}

			outerMap.put(currentNetwork, innerMap.asMap());

			previousNetwork = currentNetwork;
		}
		facilityDist.setAssignedPostalCodes(outerMap);
		//System.out.println(outerMap);
		return facilityDist;
	}

	@Override
	public List<String> changedNetworks(String network, Long userGivenTimestamp) {
		LOGGER.debug("ZipToDestServiceImpl::changedNetworks - Network Code : {} ", network);
		LOGGER.debug("ZipToDestServiceImpl::changedNetworks - Timestamp : {} ", userGivenTimestamp);

		int canada = (CountryCode.CA.getCode());
		int usa = (CountryCode.US.getCode());

		List<ZipToDestination> changedCANList = zipToDestRepo.findByLastUpdatedTimestamp(canada, network,
				userGivenTimestamp);
		LOGGER.debug(
				"ZipToDestServiceImpl::changedNetworks - Found {} last updated timestamp for the country Canada and network code {}. ",
				changedCANList.size(), network);

		List<ZipToDestination> changedUSAList = zipToDestRepo.findByLastUpdatedTimestamp(usa, network,
				userGivenTimestamp);
		LOGGER.debug(
				"ZipToDestServiceImpl::changedNetworks - Found {} last updated timestamp for the country USA and network code {}. ",
				changedUSAList.size(), network);

		sortZipCodes(changedCANList);
		sortZipCodes(changedUSAList);
		changedCANList.addAll(changedUSAList);
		LOGGER.debug("ZipToDestServiceImpl::changedNetworks -  Returning {} network.", changedCANList.size());

		return getDistributionsList(changedCANList);
	}

	@Override
	public DestinationResponse getDestinationByNetworkAndZipCode(String network, String zipCode) {
		LOGGER.debug("getDestinationByNetworkAndZipCode - Network Code : {}", network);
		LOGGER.debug("getDestinationByNetworkAndZipCode - Zip Code : {}", zipCode);

		DestinationResponse destinationResponse = null;
		String destination = "";

		if (ZipToDestConstants.PATTERN_US_ZIP_CODE.matcher(zipCode).matches()) {
			destinationResponse = new DestinationResponse();
			ZipToDestination dest = zipToDestRepo.findByNetworkAndZipCode(network,
					StringUtils.rightPad(zipCode, 11, '0'));
			destination = dest.getDestination();
			if (null != destination) {
				destinationResponse.setDestination(StringUtils.leftPad(destination, 4, '0'));
				LOGGER.debug(
						"getDestinationByNetworkAndZipCode - Returning Destination {} by network code {} and USA zip code {} ",
						destinationResponse, network, zipCode);
			}
		} else if (ZipToDestConstants.PATTERN_CANADA_ZIP_CODE.matcher(zipCode).matches()) {
			destinationResponse = new DestinationResponse();
			ZipToDestination dest = zipToDestRepo.findByNetworkAndZipCode(network, zipCode);
			if (null == dest) {
				dest = zipToDestRepo.findByNetworkAndZipCode(network, zipCode.substring(0, 3));
			}
			destination = dest.getDestination();
			if (null != destination) {
				destinationResponse.setDestination(StringUtils.leftPad(destination, 4, '0'));
				LOGGER.debug(
						"getDestinationByNetworkAndZipCode - Returning Destination {} by network code {} and Canada zip code {} ",
						destinationResponse, network, zipCode);
			}
		}
		if (StringUtils.isBlank(destination)) {
			throw new InvalidZipCodeException(ZipToDestConstants.MSG_ZIPCODE_NOT_FOUND);
		}
		return destinationResponse;
	}

	/**
	 * @param allLocations
	 * @param allDestinations
	 * @return
	 */
	protected List<FacilityDistribution> setFacilityDistributions(List<FacilityDistribution> allLocations,
			List<ZipToDestination> allDestinations) {
		List<PostalCodes> postalCodes = new ArrayList<>();
		ListIterator<ZipToDestination> iterator = allDestinations.listIterator();
		boolean isEnd = false;

		while (iterator.hasNext()) {
			ZipToDestination destination = iterator.next();
			FacilityDistribution facilityDist = new FacilityDistribution();
			facilityDist.setOperationType(ZipToDestConstants.OPERATION_TYPE);
			facilityDist.setLegacyLocationNumber(destination.getDestination());

			if (iterator.hasNext()) {
				String currentDest = destination.getDestination();
				do {
					postalCodes.add(setPostalCodes(destination));
					if (iterator.nextIndex() == allDestinations.size()) {
						isEnd = true;
						break;
					}
					destination = allDestinations.get(iterator.nextIndex());
					iterator.next();
				} while (currentDest.equals(destination.getDestination()));
				if (!isEnd)
					iterator.previous();
			} else {
				postalCodes.add(setPostalCodes(destination));
			}
			allLocations.add(facilityDist);
			postalCodes = new ArrayList<>();
		}
		return allLocations;
	}

	/**
	 * 
	 * @param destinations
	 * @param isUsDistributions
	 * @return
	 */
	protected List<String> getDistributionsList(List<ZipToDestination> destinations) {
		List<String> distributions = new ArrayList<>();

		int increment = 0;
		ZipToDestination zipToDest = new ZipToDestination();
		boolean canInsert = false;
		boolean isInserted = false;
		String zipCodeTo;

		sortZipCodes(destinations);

		ListIterator<ZipToDestination> iterator = destinations.listIterator();

		while (iterator.hasNext()) {
			ZipToDestination current = iterator.next();
			zipCodeTo = ZipToDest.getZipCode(current.getCountryCode(), current.getZipCode());

			if (isInserted || increment == 0) {
				// zipToDest.setId(ZipToDest.ofZipToDestinationPK(current.getCountryCode(),
				// zipCodeTo));

				zipToDest.setCountryCode(current.getCountryCode());
				zipToDest.setZipCode(zipCodeTo);

				zipToDest.setDestination(current.getDestination());
				zipToDest.setState(current.getState());
			}

			if (iterator.nextIndex() == destinations.size()) {
				canInsert = true;
			} else {
				ZipToDestination nextDest = destinations.get(iterator.nextIndex());

				if (evaluateCondition(zipToDest, nextDest)) {
					canInsert = true;
				} else {
					canInsert = false;
					isInserted = false;
				}
			}

			if (canInsert) {
				List<String> distributionList = setDistributionList(zipToDest, zipCodeTo);
				distributions.add(String.join(";", distributionList));
				isInserted = true;
			}
			increment++;
		}
		return distributions;
	}

	/**
	 * @param currentDest
	 * @param nextDest
	 * @return
	 */
	private boolean evaluateCondition(ZipToDestination currentDest, ZipToDestination nextDest) {
		boolean output = false;
		String currentZip = currentDest.getZipCode();
		String nextZip = nextDest.getZipCode();
		int currentCountry = currentDest.getCountryCode();
		int nextCountry = nextDest.getCountryCode();

		if (currentZip.length() == 3 && !currentZip.equals(nextZip)) {
			output = true;
		} else if (currentZip.length() == 6 && (currentZip.substring(0, 3).equals(nextZip.substring(0, 3)))
				&& !(currentDest.getDestination().equals(nextDest.getDestination()))) {
			output = true;
		} else if (currentZip.length() == 6 && !currentZip.substring(0, 3).equals(nextZip.substring(0, 3))) {
			output = true;
		} else if (currentZip.length() == 5 && !(currentDest.getDestination().equals(nextDest.getDestination()))) {
			output = true;
		} else if (currentCountry != nextCountry) {
			output = true;
		} else {
			output = false;
		}
		return output;
	}

	/**
	 * @param zipToDest
	 * @param zipCodeTo
	 * @return
	 */
	private List<String> setDistributionList(ZipToDestination zipToDest, String zipCodeTo) {
		List<String> distributionList = new ArrayList<>();
		distributionList.add(String.valueOf(zipToDest.getCountryCode()));
		String zipCodeFrom = zipToDest.getZipCode();
		if (StringUtils.length(zipCodeFrom) == 3) {
			zipCodeFrom = StringUtils.rightPad(zipCodeFrom, 6, "0A0");
			zipCodeTo = StringUtils.rightPad(zipCodeTo, 6, "9Z9");
		}
		distributionList.add(StringUtils.rightPad(zipCodeFrom, 11, '0'));
		distributionList.add(StringUtils.rightPad(zipCodeTo, 11, '9'));
		distributionList.add(StringUtils.leftPad(zipToDest.getDestination(), 4, '0'));
		distributionList.add(zipToDest.getState());
		return distributionList;
	}

	/**
	 * @param zipToDest
	 * @return
	 */
	private PostalCodes setPostalCodes(ZipToDestination zipToDest) {

		PostalCodes postalCodes = new PostalCodes();

		for (CountryCode countrycd : CountryCode.values()) {
			if (countrycd.getCode() == zipToDest.getCountryCode())
				postalCodes.setCountryCd(countrycd.name());
		}
		postalCodes.setEffectiveTmstp(zipToDest.getLastUpdateTimestamp() != null
				? LocalDateTime.ofInstant(Instant.ofEpochMilli(zipToDest.getLastUpdateTimestamp()), ZoneOffset.UTC)
				: null);
		postalCodes.setExpirationTmstp("");
		postalCodes.setPostalCd(zipToDest.getZipCode());

		return postalCodes;
	}

	/**
	 * @param destinations
	 */
	private void sortZipCodes(List<ZipToDestination> destinations) {
		// Sort after getting data into list
		Collections.sort(destinations,
				(ZipToDestination o1, ZipToDestination o2) -> o1.getZipCode().compareToIgnoreCase(o2.getZipCode()));
	}

	@Override
	public List<FacilityDeltaResponse> getDeltasByFacilityId(int facilityId, Long userGivenTimestamp) {
		LOGGER.debug("ZipToDestServiceImpl::getDeltasByFacilityId - facilityId : {}", facilityId);
		LOGGER.debug("ZipToDestServiceImpl::getDeltasByFacilityId - Timestamp : {}", userGivenTimestamp);

		List<FacilityDeltaResponse> facilityResponseList = new ArrayList<>();
		String addTransactionType = ZipToDestConstants.ADD_TRANSACTION_TYPE;
		String deleteTransactionType = ZipToDestConstants.DELETE_TRANSACTION_TYPE;
		List<FacilityDelta> addFacilityDeltalist = facilityRepository.findByFacilityId(addTransactionType, facilityId,
				userGivenTimestamp);
		LOGGER.debug("ZipToDestServiceImpl::getDeltasByFacilityId - Found {} facilityId(s) of Transaction Type 'A' ",
				addFacilityDeltalist.size());

		List<FacilityDelta> deleteFacilityDeltalist = facilityRepository.findByFacilityId(deleteTransactionType,
				facilityId, userGivenTimestamp);
		LOGGER.debug("ZipToDestServiceImpl::getDeltasByFacilityId - Found {} facilityId(s) of Transaction Type 'D' ",
				deleteFacilityDeltalist.size());

		if (!addFacilityDeltalist.isEmpty()) {
			FacilityDeltaResponse addFacilityResponse = setFacilityResponse(addFacilityDeltalist);
			facilityResponseList.add(addFacilityResponse);
		}

		if (!deleteFacilityDeltalist.isEmpty()) {
			FacilityDeltaResponse deleteFacilityResponse = setFacilityResponse(deleteFacilityDeltalist);
			facilityResponseList.add(deleteFacilityResponse);
		}

		LOGGER.debug("ZipToDestServiceImpl::getDeltasByFacilityId - Returning {} Facility response.",
				facilityResponseList.size());
		return facilityResponseList;

	}

	protected FacilityDeltaResponse setFacilityResponse(List<FacilityDelta> facilityDeltaList) {
		ListIterator<FacilityDelta> iterator = facilityDeltaList.listIterator();
		Map<String, Map<String, Collection<String>>> outerMap = new HashMap<>();
		Multimap<String, String> innerMap = ArrayListMultimap.create();
		FacilityDeltaResponse facilityDeltaResponse = new FacilityDeltaResponse();
		String previousNetwork = "";

		while (iterator.hasNext()) {
			FacilityDelta id = iterator.next();
			facilityDeltaResponse.setFacilityId(id.getFacilityId());
			facilityDeltaResponse.setTransactionType(id.getTransactionType());
			final String currentNetwork = id.getNetwork();
			if ((StringUtils.compareIgnoreCase(previousNetwork, currentNetwork) != 0)) {
				innerMap = ArrayListMultimap.create();
			}
			innerMap.put(id.getState(), StringUtils.truncate(id.getZipCode(), 5));
			outerMap.put(currentNetwork, innerMap.asMap());
			previousNetwork = currentNetwork;

		}
		facilityDeltaResponse.setChangeNetworks(outerMap);
		return facilityDeltaResponse;
	}

	@Override
	public TimestampResponseDelta getHasDeltaByFacilityId(int facilityId, Long userGivenTimestamp) {
		LOGGER.debug("ZipToDestServiceImpl::getHasDeltaByFacilityId - facilityId : {} ", facilityId);
		LOGGER.debug("ZipToDestServiceImpl::getHasDeltaByFacilityId - user given Timestamp : {} ", userGivenTimestamp);

		List<String> distinctNetwork = zipToDestRepo.findDistinctNetwork();
		LOGGER.debug("ZipToDestServiceImpl::getHasDeltaByFacilityId - Found {} distinct network code. ",
				distinctNetwork.size());

		TimestampResponseDelta timestampResponseDelta = new TimestampResponseDelta();
		timestampResponseDelta.setFacilityId(facilityId);
		timestampResponseDelta.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));
		List<FacilityDelta> hasFacilityList = facilityRepository.findFacilityHasDelta(facilityId, userGivenTimestamp);

		HasDeltaByNetwork timeStampNetworkDelta;
		List<HasDeltaByNetwork> hasDeltaByNetworkList = new ArrayList<>();

		Set<String> listOfMatchedRecords = hasFacilityList.stream().distinct().map(e -> e.getNetwork())
				.collect(Collectors.toSet());

		for (String li : distinctNetwork) {
			timeStampNetworkDelta = new HasDeltaByNetwork();
			if (listOfMatchedRecords.contains(li)) {
				timeStampNetworkDelta.setHasChanged(true);
				timeStampNetworkDelta.setNetwork(li);
			} else {
				timeStampNetworkDelta.setHasChanged(false);
				timeStampNetworkDelta.setNetwork(li);
			}
			hasDeltaByNetworkList.add(timeStampNetworkDelta);
			timestampResponseDelta.setHasDeltaByNetwork(hasDeltaByNetworkList);
		}

		LOGGER.debug("ZipToDestServiceImpl::getHasDeltaByFacilityId - Returning response as TimestampResponseDelta.");
		return timestampResponseDelta;
	}
}
