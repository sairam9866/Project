package com.fedex.ziptodest.distribution.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class EpochTimeFormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EpochTimeFormatException(){
		super();
	}
	
	public EpochTimeFormatException(String message) {
		super(message);		
	}	

}
