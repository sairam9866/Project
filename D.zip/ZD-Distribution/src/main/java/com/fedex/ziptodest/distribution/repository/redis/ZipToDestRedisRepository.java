package com.fedex.ziptodest.distribution.repository.redis;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.model.ZipToDestination;

@Repository("ZipToDestRedisRepository")
public interface ZipToDestRedisRepository extends CrudRepository<ZipToDestination, String>, QueryByExampleExecutor<ZipToDestination> {
	
	public Iterable<ZipToDestination> findByCountryCodeAndNetwork(int countryCode, String network);

	public Iterable<ZipToDestination> findByNetwork(Sort page, String networkID);

	public List<ZipToDestination> findByDestination(String facilityID);

	@Query("SELECT z FROM ZipToDestination z WHERE countryCode=:givenCountryCode AND network=:givenNetwork  AND lastUpdateTimestamp > :userGivenTimestamp")
	public List<ZipToDestination> findByLastUpdatedTimestamp(@Param("givenCountryCode") int countryCode,
			@Param("givenNetwork") String givenNetwork, @Param("userGivenTimestamp") Long userGivenTimestamp);

	public ZipToDestination findByNetworkAndZipCode(String givenNetwork, String userGivenZipCode);

	@Query("SELECT DISTINCT zd.network FROM ZipToDestination zd")
	public List<String> findDistinctNetwork();

	public ZipToDestination findFirstByNetwork(String network);

}
