package com.fedex.ziptodest.distribution.service.impl;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.distribution.model.FacilityDelta;
import com.fedex.ziptodest.distribution.model.ZipToDestHasDelta;
import com.fedex.ziptodest.distribution.model.ZipToDestination;
import com.fedex.ziptodest.distribution.repository.FacilityRepository;
import com.fedex.ziptodest.distribution.repository.ZipToDestHasDeltaRepository;
import com.fedex.ziptodest.distribution.repository.ZipToDestRepository;
import com.fedex.ziptodest.distribution.service.EmbeddedRedisPayloadService;
import com.fedex.ziptodest.distribution.utils.CsvReader;

@Service
@Profile("local")
public class EmbeddedRedisPayloadServiceImpl implements EmbeddedRedisPayloadService {

	public static final Logger LOGGER = LoggerFactory.getLogger(EmbeddedRedisPayloadServiceImpl.class);
	@Autowired
	ZipToDestRepository zipToDestRepository;

	@Autowired
	FacilityRepository facilityRepository;

	@Autowired
	ZipToDestHasDeltaRepository ZipToDestHasDeltaRepository;

	@Override
	public void init() {
		saveDestinations();
		saveFacility();
		saveZipToDestHasDeltaRedis();
	}

	public void saveDestinations() {
		LOGGER.debug("EmbeddedRedisPayloadServiceImpl::Entering saveDestinations method");
		CsvReader<ZipToDestination> csvReader = new CsvReader<>();
		List<ZipToDestination> destinations;
		try {
			destinations = csvReader.beanBuilderExample(ZipToDestination.class, "zipToDest.csv");
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::ZipToDest records fetched from CSV file");
			for (ZipToDestination zipToDest : destinations) {
				zipToDest.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDest.buildKey();
				zipToDestRepository.save(zipToDest);
			}
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::ZipToDest records saved in Redis repository");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void saveFacility() {
		LOGGER.debug("EmbeddedRedisPayloadServiceImpl::Entering saveFacility method");
		CsvReader<FacilityDelta> csvReader = new CsvReader<>();
		List<FacilityDelta> facilityRecords;
		try {
			facilityRecords = csvReader.beanBuilderExample(FacilityDelta.class, "Facility.csv");
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::Facility records fetched from CSV file");
			for (FacilityDelta facilitySave : facilityRecords) {
				facilitySave.buildKey();
				facilityRepository.save(facilitySave);
			}
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::Fcility records saved in Redis repository");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void saveZipToDestHasDeltaRedis() {
		LOGGER.debug("EmbeddedRedisPayloadServiceImpl::Entering saveZipToDestHasDeltaRedis method");
		CsvReader<ZipToDestHasDelta> csvReader = new CsvReader<>();
		List<ZipToDestHasDelta> zipToDestHasDeltaRedisRecords;
		try {
			zipToDestHasDeltaRedisRecords = csvReader.beanBuilderExample(ZipToDestHasDelta.class,
					"ZipToDestHasDelta.csv");
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::ZipToDestHasDelta records fetched from CSV file");
			for (ZipToDestHasDelta zipToDestHasDeltaRedisSave : zipToDestHasDeltaRedisRecords) {
				ZipToDestHasDeltaRepository.save(zipToDestHasDeltaRedisSave);
			}
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::ZipToDestHasDeltaRedis records saved in Redis repository");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
