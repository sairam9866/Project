package com.fedex.ziptodest.distribution.configuration;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import redis.clients.jedis.JedisPoolConfig;

@Configuration
@ServletComponentScan
@EnableRedisRepositories
public class DistributionRedisPoolConfig {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(DistributionRedisPoolConfig.class);
	
	@Value("${spring.profiles.active:Unknown}")
	private String activeProfile;
	
	@Value("${spring.redis.port}")
	private Integer redisPort;

	@Value("${spring.redis.host}")
	private String redisHostName;
	
	@Value("${spring.redis.password}")
	private String redisPassword;
	
	
	@Value("${spring.redis.pool.maxidle}")
	private Integer maxIdle;
	
	@Value("${spring.redis.pool.minidle}")
	private Integer minIdle;

	@Value("${spring.redis.pool.timeout}")
	private Integer timeOut;
	
	  @Bean
	  JedisConnectionFactory zipToDestJedisConnectionFactory(){
	        RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisHostName, redisPort);
	        if (StringUtils.isNotBlank(redisPassword)) {
				redisStandaloneConfiguration.setPassword(redisPassword);
			}
	        JedisClientConfiguration.JedisClientConfigurationBuilder jedisClientConfigurationBuilder=JedisClientConfiguration.builder();
	        jedisClientConfigurationBuilder.usePooling();
	        return new JedisConnectionFactory(redisStandaloneConfiguration,jedisClientConfigurationBuilder.build());
	    }
	
	@Bean(name = "zipToDestRedisTemplate")
	RedisTemplate<?, ?> zipToDestRedisTemplate() {
		RedisTemplate<String, Object> zipToDestRedisTemplate = new RedisTemplate<>();
		zipToDestRedisTemplate.setConnectionFactory(zipToDestJedisConnectionFactory());
		zipToDestRedisTemplate.setKeySerializer(new StringRedisSerializer());

		zipToDestRedisTemplate.setHashKeySerializer(new StringRedisSerializer());
		zipToDestRedisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
		zipToDestRedisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		zipToDestRedisTemplate.afterPropertiesSet();
		zipToDestRedisTemplate.setEnableTransactionSupport(true);
		return zipToDestRedisTemplate;
	}
	
	@Bean
	JedisPoolConfig pool(){
		
		JedisPoolConfig jedisPoolConfig=new JedisPoolConfig();
		jedisPoolConfig.setMaxIdle(maxIdle);
		jedisPoolConfig.setMinIdle(minIdle);
		jedisPoolConfig.setMaxWaitMillis(timeOut);
		
		return jedisPoolConfig;
		
	}
		
	
	
}

	
	
