package com.fedex.ziptodest.distribution.model;

public class DestinationResponse {
	private String destination;

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "DestinationResponse [destination=" + destination + "]";
	}
	
}
