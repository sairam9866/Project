package com.fedex.ziptodest.distribution.model;

public interface FacilityDeltaKey {
	public void buildKey();
}
