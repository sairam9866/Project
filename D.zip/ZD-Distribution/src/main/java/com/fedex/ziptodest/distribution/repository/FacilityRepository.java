package com.fedex.ziptodest.distribution.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.model.FacilityDelta;
import com.fedex.ziptodest.distribution.repository.redis.FacilityRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

@Repository("facilityRepository")
public class FacilityRepository implements FacilityRedisRepository {

	@Resource(name = "redisTemplate")
	private ZSetOperations<String, FacilityDelta> sortedFacilitySetOperations;

	@Autowired
	@Qualifier("facilityRedisRepository")
	FacilityRedisRepository facilityRedisRepository;


	@Override
	public <S extends FacilityDelta> S save(S entity) {
		sortedFacilitySetOperations.add(ZipToDestConstants.FACILITY_HASH_KEY, entity, entity.getEffectiveDateTime());
		return facilityRedisRepository.save(entity);
	}

	@Override
	public <S extends FacilityDelta> Iterable<S> saveAll(Iterable<S> entities) {
		return facilityRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<FacilityDelta> findById(Long id) {
		return facilityRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(Long id) {
		return false;
	}

	@Override
	public Iterable<FacilityDelta> findAll() {
		return facilityRedisRepository.findAll();
	}

	@Override
	public Iterable<FacilityDelta> findAllById(Iterable<Long> ids) {
		return facilityRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return 0;
	}

	@Override
	public void deleteById(Long id) {

	}

	@Override
	public void delete(FacilityDelta entity) {

	}

	@Override
	public void deleteAll(Iterable<? extends FacilityDelta> entities) {

	}

	@Override
	public void deleteAll() {
		facilityRedisRepository.deleteAll();
	}

	@Override
	public List<FacilityDelta> findByFacilityId(String givenTransactionType, int givenfacilityId,
			Long userGivenTimestamp) {

		List<FacilityDelta> sentList = new ArrayList<>();

		Set<FacilityDelta> facilitySet = sortedFacilitySetOperations.rangeByScore(ZipToDestConstants.FACILITY_HASH_KEY, userGivenTimestamp, Long.MAX_VALUE);

		for (FacilityDelta delta : facilitySet) {
			if (delta.getTransactionType().equalsIgnoreCase(givenTransactionType) && delta.getFacilityId() == givenfacilityId) {
				FacilityDelta facilityDelta = new FacilityDelta();
				facilityDelta.setNetwork(delta.getNetwork());
				facilityDelta.setFacilityId(delta.getFacilityId());
				facilityDelta.setZipCode(delta.getZipCode());
				facilityDelta.setEffectiveDateTime(delta.getEffectiveDateTime());
//						zipToDestUtil.getTimestampFromEpochTime(String.valueOf(sort.getEffectiveDateTime())));
				facilityDelta.setState(delta.getState());
				facilityDelta.setTransactionType(delta.getTransactionType());
				facilityDelta.setUuId(delta.getUuId());
				sentList.add(facilityDelta);
			}

		}

		return sentList;

	}

	@Override
	public List<FacilityDelta> findFacilityHasDelta(int givenfacilityId, Long userGivenTimestamp) {
		
		List<FacilityDelta> sentList = new ArrayList<>();
		Set<FacilityDelta> facilitySet = sortedFacilitySetOperations.rangeByScore(ZipToDestConstants.FACILITY_HASH_KEY, userGivenTimestamp, Long.MAX_VALUE);

		for (FacilityDelta delta : facilitySet) {
			if (delta.getFacilityId() == givenfacilityId) {
				FacilityDelta facilityDelta = new FacilityDelta();
				facilityDelta.setNetwork(delta.getNetwork());
				facilityDelta.setFacilityId(delta.getFacilityId());
				facilityDelta.setZipCode(delta.getZipCode());
				facilityDelta.setEffectiveDateTime(delta.getEffectiveDateTime());
				facilityDelta.setState(delta.getState());
				facilityDelta.setTransactionType(delta.getTransactionType());
				facilityDelta.setUuId(delta.getUuId());
				sentList.add(facilityDelta);
			}
		}
		return sentList;
	}
}

