package com.fedex.ziptodest.distribution.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.model.ZipToDestination;
import com.fedex.ziptodest.distribution.repository.redis.ZipToDestRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;

@Repository("ZipToDestRepository")
public class ZipToDestRepository implements ZipToDestRedisRepository {

	@Autowired
	ZipToDestRedisRepository zipToDestRedisRepository;
	
	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDestination> sortedzipToDestSetOperations;

	@Resource(name = "redisTemplate")
	private SetOperations<String, String> normalzipToDestSetOperations;

	@Override
	public Iterable<ZipToDestination> findByCountryCodeAndNetwork(int countryCode, String network) {

		return zipToDestRedisRepository.findByCountryCodeAndNetwork(countryCode, network);
	}

	@Override
	public Iterable<ZipToDestination> findByNetwork(Sort page, String networkID) {
		return zipToDestRedisRepository.findByNetwork(page, networkID);
	}

	@Override
	public List<ZipToDestination> findByDestination(String facilityID) {
		return zipToDestRedisRepository.findByDestination(facilityID);
	}

	@Override
	public List<ZipToDestination> findByLastUpdatedTimestamp(int countryCode, String givenNetwork,
			Long userGivenTimestamp) {

		List<ZipToDestination> sentList = new ArrayList<>();
		Set<ZipToDestination> zipToDestSet = sortedzipToDestSetOperations.rangeByScore(ZipToDestConstants.ZIP_TO_DEST,
				userGivenTimestamp, Long.MAX_VALUE);
		for (ZipToDestination sort : zipToDestSet) {

			if (sort.getCountryCode() == countryCode && sort.getNetwork().equalsIgnoreCase(givenNetwork)) {
				ZipToDestination localZipToDestination = new ZipToDestination();
				localZipToDestination.setCountryCode(sort.getCountryCode());
				localZipToDestination.setDestination(sort.getDestination());
				localZipToDestination.setId(sort.getId());
				localZipToDestination.setLastUpdateBy(sort.getLastUpdateBy());
				localZipToDestination.setLastUpdateTimestamp(sort.getLastUpdateTimestamp());
				localZipToDestination.setNetwork(sort.getNetwork());
				localZipToDestination.setState(sort.getState());
				localZipToDestination.setZipCode(sort.getZipCode());
				sentList.add(localZipToDestination);
			}
		}
		return sentList;
	}

	@Override
	public ZipToDestination findByNetworkAndZipCode(String givenNetwork, String userGivenZipCode) {
		return zipToDestRedisRepository.findByNetworkAndZipCode(givenNetwork, userGivenZipCode);
	}

	@Override
	public List<String> findDistinctNetwork() {
		Set<String> checkSet = normalzipToDestSetOperations.members(ZipToDestConstants.ZIP_TO_DEST_NETWORKS);
		List<String> distinctNetworks = new ArrayList<String>();
		distinctNetworks.addAll(checkSet);
		return distinctNetworks;
	}

	@Override
	public ZipToDestination findFirstByNetwork(String network) {
		return zipToDestRedisRepository.findFirstByNetwork(network);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ZipToDestination save(ZipToDestination zipToDest) {
		normalzipToDestSetOperations.add(ZipToDestConstants.ZIP_TO_DEST_NETWORKS, zipToDest.getNetwork());
		sortedzipToDestSetOperations.add(ZipToDestConstants.ZIP_TO_DEST, zipToDest, zipToDest.getLastUpdateTimestamp());
		return zipToDestRedisRepository.save(zipToDest);
	}

	@Override
	public long count() {
		return 0;
	}

	@Override
	public void delete(ZipToDestination entity) {

	}

	@Override
	public void deleteAll(Iterable<? extends ZipToDestination> entities) {

	}

	@Override
	public void deleteAll() {

	}

	@Override
	public Optional<ZipToDestination> findById(String id) {
		return null;
	}

	@Override
	public boolean existsById(String id) {
		return false;
	}

	@Override
	public void deleteById(String id) {

	}

	@Override
	public List<ZipToDestination> findAll() {
		return null;
	}

	@Override
	public List<ZipToDestination> findAllById(Iterable<String> ids) {
		return null;
	}

	@Override
	public <S extends ZipToDestination> List<S> saveAll(Iterable<S> entities) {
		return null;
	}

	@Override
	public <S extends ZipToDestination> Optional<S> findOne(Example<S> example) {
		return null;
	}

	@Override
	public <S extends ZipToDestination> Iterable<S> findAll(Example<S> example) {
		return null;
	}

	@Override
	public <S extends ZipToDestination> Iterable<S> findAll(Example<S> example, Sort sort) {
		return null;
	}

	@Override
	public <S extends ZipToDestination> Page<S> findAll(Example<S> example, Pageable pageable) {
		return null;
	}

	@Override
	public <S extends ZipToDestination> long count(Example<S> example) {
		return 0;
	}

	@Override
	public <S extends ZipToDestination> boolean exists(Example<S> example) {
		return false;
	}
	
}
