package com.fedex.ziptodest.distribution.utils;

import java.util.regex.Pattern;

/**
 * @author 3790999
 *
 */
public final class ZipToDestConstants {

	private ZipToDestConstants() {
		throw new AssertionError("No com.fedex.ziptodest.distribution.utils.ZipToDestConstants instances for you!");
	}

	public static final String PROP_ACTIVE_PROFILE = "active_profile";
	public static final String PROP_SORTATION_ROLE = "sortation_role";
	public static final String PROP_SVM_ROLE = "svm_role";
	public static final String PROP_JDBC_URL = "jdbc_url";
	public static final String PROP_DRIVER_CLASS = "jdbc_driver_class";
	public static final String PROP_JDBC_USER = "jdbc_username";
	public static final String PROP_JDBC_PD = "jdbc_password";
	public static final String PROP_CONTEXT_PATH = "context_path";
	public static final String PROP_SERVER_PORT = "server_port";
	public static final String PROP_SESSION_TIMEOUT = "session_timeout";
	public static final String PROP_LOG_LEVEL_FEDEX = "log_level_fedex";
	public static final String PROP_LOG_LEVEL_SPRING = "log_level_spring";
	public static final String PROP_LPI_BASE_URL = "base_url";
	public static final String PROP_LDAP_WS_URL = "ldap_ws_url";
	public static final String OPERATION_TYPE = "FCLTY";

	// Messages
	public static final String MSG_FACILITY_ID_BAD_REQUEST = "Bad Request. Facility Id parameter requires leading zeros.";
	public static final String MSG_FACILITY_ID_NOT_FOUND = "Invalid Facility Id supplied. Facility Id must be an integer value between 1 and 9999";
	public static final String MSG_NETWORK_NOT_FOUND = "Network not found - Invalid Network code supplied.";
	public static final String MSG_ZIPCODE_NOT_FOUND = "Zip Code not found - Invalid Zipcode supplied.";
	public static final String MSG_EPOCH_TIME_BAD_REQUEST = "Invalid Epoch Time supplied - Epoch time must be a positive number and not after current date epoch time.";
	public static final String MSG_API_KEY_UNAUTHORIZED = "Invalid API Key supplied.";
	public static final String MSG_INVALID_REQUEST = "Invalid request";

	public static final String STATUS_CODE_INVALID_NETWORK = "Invalid Network";
	public static final String STATUS_CODE_INVALID_ZIPCODE = "Invalid Zipcode";
	public static final String STATUS_CODE_INVALID_FACILITY_ID = "Invalid Facility Id";
	public static final String STATUS_CODE_UNAUTHORIZED = "Unauthorized";
	public static final String STATUS_CODE_INVALID_EPOCH_TIME = "Invalid Epoch Time";
	public static final String STATUS_CODE_INVALID_SERVER_ERROR = "Internal Server Error";
	public static final String STATUS_CODE_NO_CONTENT = "No Content";

	// Facility
	public static final String FACILITY_HASH_KEY = "FACILITYDELTA";
	public static final String ZIP_TO_DEST_HAS_DELTA_HASH_KEY = "ZIPTODESTHASDELTA";
	public static final String ADD_TRANSACTION_TYPE = "A";
	public static final String DELETE_TRANSACTION_TYPE = "D";

	public static final String ZIP_TO_DEST_NETWORKS = "ZIPTODESTNETWORKS";
	public static final String ZIP_TO_DEST = "ZIPTODEST";

	// API Keys
	public static final String API_KEY_LINEHAUL = "apikey.linehaul";
	public static final String API_KEY_SORT_X = "apikey.sortx";
	public static final String API_KEY_DDS = "apikey.dds";
	// Chache Keys
	public static final String CACHE_SORTX = "cache.sortx";

	// Chache Keys
	public static final String CONFIG_API_KEY = "ziptodest.config";

	// Zipcode Pattern
	public static final Pattern PATTERN_US_ZIP_CODE = Pattern.compile("[0-9]{5,5}");
	public static final Pattern PATTERN_CANADA_ZIP_CODE = Pattern.compile("[a-zA-Z][\\d][a-zA-Z][\\d][a-zA-Z][\\d]$");

	public enum CountryCode {
		CA(124), US(840), MX(484);

		private int code;

		private CountryCode(int code) {
			this.setCode(code);
		}

		public int getCode() {
			return code;
		}

		private void setCode(int code) {
			this.code = code;
		}
	}
	
}
