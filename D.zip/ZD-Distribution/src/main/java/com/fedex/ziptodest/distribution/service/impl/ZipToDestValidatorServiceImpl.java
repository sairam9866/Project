/**
 * 
 */
package com.fedex.ziptodest.distribution.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.distribution.model.ZipToDestination;
import com.fedex.ziptodest.distribution.repository.ZipToDestRepository;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

/**
 * @author 3818669
 *
 */
@Service
public class ZipToDestValidatorServiceImpl implements ZipToDestValidatorService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestValidatorServiceImpl.class);

	@Autowired
	ZipToDestRepository zipToDestRepository;

	@Autowired
	ZipToDestUtil zipToDestUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fedex.ziptodest.distribution.service.ZipToDestValidatorService#
	 * isNetworkExist()
	 */
	@Override
	public boolean isNetworkExist(String network) {
		LOGGER.debug("::isNetworkExist - User Input Netword Code - {}", network);
		boolean output = false;
		if (!StringUtils.isEmpty(network)) {
			ZipToDestination destination = zipToDestRepository.findFirstByNetwork(network.toUpperCase());
			if(null != destination)
				output = true;
		}
		LOGGER.debug("::isNetworkExist - Returning boolean value {}.", output);
		return output;
	}

	/**
	 * 
	 */
	@Override
	public boolean isValidFacilityId(int facilityId) {
		LOGGER.debug("::isZipCodeExist - User input zipcode - {}", facilityId);
		boolean output = false;
		output = zipToDestUtil.isValidFacilityId(facilityId);
		LOGGER.debug("::isValidFacilityId - Returning boolean value {}.", output);
		return output;
	}

	public boolean isValidFacilityId(String facilityId) {
		LOGGER.debug("::isValidFacilityId - User input facilityId - {}", facilityId);
		boolean output = false;
		output = zipToDestUtil.isValidFacilityId(facilityId);
		LOGGER.debug("::isValidFacilityId - Returning boolean value {}.", output);
		return output;
	}

	@Override
	public boolean isValidEpochTime(String epochTime) {
		LOGGER.debug("::isValidEpochTime - User input epochTime - {}", epochTime);
		boolean output = false;
		output = zipToDestUtil.isValidEpochTime(epochTime);
		LOGGER.debug("::isValidEpochTime - Returning boolean value {}.", output);
		return output;
	}

	@Override
	public boolean isValidApiKey(String key, String value) {
		LOGGER.debug("::isValidApiKey - User input key - {}", key);
		LOGGER.debug("::isValidApiKey - User input value - {}", value);
		boolean output = false;
		output = zipToDestUtil.isValidApiKey(key, value);
		LOGGER.debug("::isValidApiKey - Returning boolean value {}.", output);
		return output;
	}

}
