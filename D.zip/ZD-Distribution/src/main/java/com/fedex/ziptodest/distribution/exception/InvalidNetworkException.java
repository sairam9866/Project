/**
 * 
 */
package com.fedex.ziptodest.distribution.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author 3818669
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class InvalidNetworkException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	

	public InvalidNetworkException() {
		super();
	}

	public InvalidNetworkException(String message) {
		super(message);		
	}
}
