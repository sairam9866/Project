package com.fedex.ziptodest.distribution.repository.redis;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.model.ZipToDestHasDelta;

@Repository("zipToDestHasDeltaRedisRepository")
public interface ZipToDestHasDeltaRedisRepository extends CrudRepository<ZipToDestHasDelta, String> {

	public ZipToDestHasDelta isDeltaExist(String network, Long userGivenTimestamp);
}
