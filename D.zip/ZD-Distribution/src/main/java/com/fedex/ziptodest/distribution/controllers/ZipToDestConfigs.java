package com.fedex.ziptodest.distribution.controllers;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.distribution.exception.UnauthorizedException;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

@RestController
@RequestMapping("/zipToDest/distribution")
public class ZipToDestConfigs {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestConfigs.class);
	@Autowired
	private ConfigurableEnvironment  env;
	
	@Autowired
	ZipToDestUtil zipToDestUtil;
	
	@GetMapping(value = "/getProperties")
	public Map<String,Object> getAllProperties(@RequestHeader("apiKey") String apiKey)
	{
		if(!zipToDestUtil.isValidApiKey(ZipToDestConstants.CONFIG_API_KEY, apiKey)){
			LOGGER.debug("::getAllProperties - The key {} is invalid.", apiKey);
			throw new UnauthorizedException(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
		}
		
	    Map<String,Object> result = new HashMap<>();
	    if (env instanceof ConfigurableEnvironment) {
	        for (PropertySource<?> propertySource : ((ConfigurableEnvironment) env).getPropertySources()) {
	            if (propertySource instanceof EnumerablePropertySource) {
	                for (String key : ((EnumerablePropertySource) propertySource).getPropertyNames()) {
	                	result.put(key, propertySource.getProperty(key));
	                }
	            }
	        }
	    }
	    return result;
	}
}
	
	