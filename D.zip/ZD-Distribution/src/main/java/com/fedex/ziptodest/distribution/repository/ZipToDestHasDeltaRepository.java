package com.fedex.ziptodest.distribution.repository;

import java.util.Optional;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.model.ZipToDestHasDelta;
import com.fedex.ziptodest.distribution.repository.redis.ZipToDestHasDeltaRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

/**
 * 
 * @author 3818669
 *
 */
@Repository("zipToDestHasDeltaRepository")
public class ZipToDestHasDeltaRepository implements ZipToDestHasDeltaRedisRepository {

	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDestHasDelta> sortedzipToDestHasDeltaSetOperations;

	@Autowired
	@Qualifier("zipToDestHasDeltaRedisRepository")
	ZipToDestHasDeltaRedisRepository zipToDestHasDeltaRedisRepository;

	@Override
	public <S extends ZipToDestHasDelta> S save(S entity) {
		sortedzipToDestHasDeltaSetOperations.add(ZipToDestConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY, entity,
				entity.getLastUpdateTimestamp());
		return zipToDestHasDeltaRedisRepository.save(entity);
	}

	@Override
	public <S extends ZipToDestHasDelta> Iterable<S> saveAll(Iterable<S> entities) {
		return zipToDestHasDeltaRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<ZipToDestHasDelta> findById(String id) {
		return zipToDestHasDeltaRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(String id) {
		return false;
	}

	@Override
	public Iterable<ZipToDestHasDelta> findAll() {
		return zipToDestHasDeltaRedisRepository.findAll();
	}

	@Override
	public Iterable<ZipToDestHasDelta> findAllById(Iterable<String> ids) {
		return zipToDestHasDeltaRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return 0;
	}

	@Override
	public void deleteById(String id) {

	}

	@Override
	public void delete(ZipToDestHasDelta entity) {

	}

	@Override
	public void deleteAll(Iterable<? extends ZipToDestHasDelta> entities) {

	}

	@Override
	public void deleteAll() {

	}

	@Override
	public ZipToDestHasDelta isDeltaExist(String network, Long userGivenTimestamp) {

		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		Set<ZipToDestHasDelta> setZipToDestHasDelta = sortedzipToDestHasDeltaSetOperations
				.rangeByScore(ZipToDestConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY, userGivenTimestamp, Long.MAX_VALUE);

		for (ZipToDestHasDelta delta : setZipToDestHasDelta) {
			if (delta.getNetwork().equalsIgnoreCase(network)) {
				zipToDestHasDelta.setLastUpdateTimestamp(delta.getLastUpdateTimestamp());
				zipToDestHasDelta.setNetwork(network);
			}
		}

		return zipToDestHasDelta;

	}
}
