package com.fedex.ziptodest.distribution.service;


public interface CachingService {

	public void evictAllCaches();
}
