package com.fedex.ziptodest.distribution.configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.fedex.ziptodest.distribution.service.EmbeddedRedisPayloadService;

import redis.embedded.RedisServer;
import redis.embedded.RedisServerBuilder;


@Configuration
@Profile("local")
public class RedisServerConfig {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisServerConfig.class);

	private RedisServer redisServer;
	@Autowired
	EmbeddedRedisPayloadService embeddedRedisPayloadService;
	
	@Value(value = "${spring.redis.host}")
	private String redishost;
	@Value(value = "${spring.redis.port}")
	private String redisport;
	/*@Value(value = "${spring.redis.password}")
	private String redispwd;
	@Value(value = "${spring.redis.jedis.pool.max-active}")
	private String maxTotal;
	@Value(value = "${spring.redis.jedis.pool.max-idle}")
	private String maxIdle;
	@Value(value = "${spring.redis.jedis.pool.min-idle}")
	private String minIdle;*/
	
	
	@SuppressWarnings("deprecation")
	@Bean
	JedisConnectionFactory jedisConnectionFactory() {
		JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
		return jedisConnectionFactory;
	}

	@Bean
	RedisTemplate<?, ?> redisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
    	redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
    	redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}

	
	@PostConstruct
	public void init() {
		redisServer = new RedisServerBuilder().port(Integer.parseInt(redisport)).setting("maxmemory 256M").build();
		redisServer.start();
		 if(redisServer.isActive()) embeddedRedisPayloadService.init();
	}

	@PreDestroy
	public void destroy() {
		redisServer.stop();
	}
}
