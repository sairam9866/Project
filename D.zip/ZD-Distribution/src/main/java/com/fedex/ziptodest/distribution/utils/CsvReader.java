package com.fedex.ziptodest.distribution.utils;

import java.io.File;
import java.io.Reader;
import java.nio.file.Files;
import java.util.Collections;
import java.util.List;

import org.springframework.core.io.ClassPathResource;

import com.opencsv.bean.CsvToBeanBuilder;

public class CsvReader<T> {

	public List<T> beanBuilderExample(Class<T> entity, String fileName) throws Exception {
		try {
			File csvFile = new ClassPathResource(fileName).getFile();
			Reader reader = Files.newBufferedReader(csvFile.toPath());
			List<T> list = new CsvToBeanBuilder<T>(reader).withType(entity).build().parse();
			reader.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return Collections.emptyList();
		} 
	}
}
