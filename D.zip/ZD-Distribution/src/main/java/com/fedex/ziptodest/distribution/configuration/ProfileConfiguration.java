package com.fedex.ziptodest.distribution.configuration;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;

/**
 * @author 3790999
 *
 */
@Configuration
public class ProfileConfiguration {

	public static final Logger log = LoggerFactory.getLogger(ProfileConfiguration.class);
	
	private String profile;
	private String sortationRole;
	private String serviceMeasurementRole;
	private String jdbcDriverClass;
	private String jdbcUrl;
	private String jdbcUsername;
	private String jdbcPassword;
	private String contextPath;
	private String serverPort;
	private String sessionTimeout;
	private String loggingLevelFedex;
	private String loggingLevelSpring;
	private String baseUrl;
	private String ldapWSUri;

	/**
	 * @return
	 */
	@Profile({"dev","local"})
	@Bean
	public Map<String, String> initializeApplicationPropMap() {
		log.debug("Initializing Application properties");
		Map<String, String>propMap = new LinkedHashMap<>();
		propMap = initializeProfile(propMap, this);
		return propMap;
	}
	
	/**
	 * @param propMap
	 * @param profileConfig
	 * @return
	 */
	public Map<String, String> initializeProfile(Map<String, String> propMap, ProfileConfiguration profileConfig) {
		propMap.put(ZipToDestConstants.PROP_ACTIVE_PROFILE, profileConfig.profile);
		propMap.put(ZipToDestConstants.PROP_SORTATION_ROLE, profileConfig.sortationRole);
		propMap.put(ZipToDestConstants.PROP_SVM_ROLE, profileConfig.serviceMeasurementRole);
		propMap.put(ZipToDestConstants.PROP_JDBC_URL, profileConfig.jdbcUrl);
		propMap.put(ZipToDestConstants.PROP_JDBC_USER, profileConfig.jdbcUsername);
		propMap.put(ZipToDestConstants.PROP_JDBC_PD, profileConfig.jdbcPassword);
		propMap.put(ZipToDestConstants.PROP_DRIVER_CLASS, profileConfig.jdbcDriverClass);
		propMap.put(ZipToDestConstants.PROP_LPI_BASE_URL, profileConfig.baseUrl);
		propMap.put(ZipToDestConstants.PROP_LDAP_WS_URL, profileConfig.ldapWSUri);
		propMap.put(ZipToDestConstants.PROP_CONTEXT_PATH, profileConfig.contextPath);
		propMap.put(ZipToDestConstants.PROP_SERVER_PORT, profileConfig.serverPort);
		propMap.put(ZipToDestConstants.PROP_SESSION_TIMEOUT, profileConfig.sessionTimeout);
		propMap.put(ZipToDestConstants.PROP_LOG_LEVEL_FEDEX, profileConfig.loggingLevelFedex);
		propMap.put(ZipToDestConstants.PROP_LOG_LEVEL_SPRING, profileConfig.loggingLevelSpring);

		return propMap;
	}
}
