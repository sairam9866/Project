package com.fedex.ziptodest.distribution.service;

import com.fedex.ziptodest.distribution.model.ZipToDestHasDeltaResponse;

/**
 * 
 * @author 3818669
 *
 */
public interface ZipToDestHasDeltaService {

	public ZipToDestHasDeltaResponse isDeltaExist(String network, Long userGivenTimestamp);
}
