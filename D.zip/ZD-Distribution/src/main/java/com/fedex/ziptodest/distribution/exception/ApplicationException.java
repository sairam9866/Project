package com.fedex.ziptodest.distribution.exception;
/*
 *  Application Exception class is the Customized Exception class for user defined exceptions
 */
public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String code;

	public ApplicationException(){
		this.code = null;
	}

	public String getCode() {
		return code;
	}	

	/**
	 * @param message
	 */

	public ApplicationException(String code, String message) {
		super(message);
		this.code = code;
	}

	/**
	 * @param exception
	 */

	public ApplicationException(Exception exception) {
		super(exception);
		this.code = null;
	}

	/**
	 * @param message
	 * @param throwable
	 */
	public ApplicationException(String message, Throwable throwable) {
		super(message, throwable);
		this.code = null;
	}

}
