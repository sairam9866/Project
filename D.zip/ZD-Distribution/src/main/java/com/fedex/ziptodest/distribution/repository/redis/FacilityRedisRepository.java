package com.fedex.ziptodest.distribution.repository.redis;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.model.FacilityDelta;

@Repository("facilityRedisRepository")
public interface FacilityRedisRepository extends CrudRepository<FacilityDelta, Long> {

	public List<FacilityDelta> findByFacilityId(String givenTransactionType, int givenfacilityId,
			Long userGivenTimestamp);

	public List<FacilityDelta> findFacilityHasDelta(int givenfacilityId, Long userGivenTimestamp);

}
