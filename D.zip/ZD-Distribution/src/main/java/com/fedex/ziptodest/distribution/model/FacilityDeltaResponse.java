package com.fedex.ziptodest.distribution.model;

import java.util.Collection;
import java.util.Map;

public class FacilityDeltaResponse {

	private int facilityId;
	private String transactionType;
	private Map<String, Map<String, Collection<String>>> changeNetworks;

	public FacilityDeltaResponse() {
	}
	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Map<String, Map<String, Collection<String>>> getChangeNetworks() {
		return changeNetworks;
	}

	public void setChangeNetworks(Map<String, Map<String, Collection<String>>> changeNetworks) {
		this.changeNetworks = changeNetworks;
	}

}
