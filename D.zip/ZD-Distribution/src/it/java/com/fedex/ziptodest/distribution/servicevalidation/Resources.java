package com.fedex.ziptodest.distribution.servicevalidation;

public class Resources {
	
	// zipcode and network
	public static final String byZipcode_network = "/zipToDest/distribution/byNetworkAndZipCode";
	
	// zipcode and network invalid URL
	public static final String byZipcode_network_invalid = "/zipToDest/distribution/byNetworkAnZipCode";
	
	// network
	public static final String byNetwork = "/zipToDest/distribution/byNetwork";
	
	//network
	public static final String byNetwork_invalid = "/zipToDest/distribution/byNtwork";

	
}
