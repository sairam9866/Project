package com.fedex.ziptodest.distribution.cucumber.stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static com.fedex.ziptodest.distribution.utils.ConfigFileReader.DistributionAPIProp;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;

import com.fedex.ziptodest.distribution.cucumber.SpringBootBaseIntegrationTest;
import com.fedex.ziptodest.distribution.servicevalidation.Resources;
import com.fedex.ziptodest.distribution.servicevalidation.ReusableMethods.java.ReusableMethods;


@Ignore
public class DistributionAPIStepDefinition extends SpringBootBaseIntegrationTest{

	Response response;
	ValidatableResponse json;
	
	Date date =new Date();
	String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
	
	@Given("^The base URI is up and running for Distribution for \"([^\"]*)\"$")
    public void the_base_URI_is_up_and_running_distribution(String network) {
		
		RestAssured.baseURI = DistributionAPIProp.getProperty("HostDistributionAPILocal")+"/"+network;
    }
    
    @Then("^User should see the status code (\\d+)$")
	public void user_should_see_the_status_code(int statuscode) {
   	
		json = response.then().assertThat().statusCode(statuscode);
		json.log().all().extract();
		
	}
    
    @When("^User verifies distribution ID$")
    public void user_verifies_distribution() {
       
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get();
    	
    }
    
    @When("^user performs invalid request$")
	public void user_perform_invalid_request() {
   	
       response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get(DistributionAPIProp.getProperty("DistributionAPIInvalidParameter"));
    
	}
    
    @And("^verify rows of Distribution API \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
   	public void verify_first_row_of_Distribution_API(String countryjson, String zipfromjson
   			, String ziptojson, String destjson, String statejson, int row) {
      	
        response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get();
           
        List<String> rows = response.jsonPath().getList("$");
   		System.out.println("First row of Distribution API is: "+rows.get(row));
   		
   		String Country = rows.get(row).substring(0, 3);
   		System.out.println("First row country code is: "+Country);
   		assertEquals(countryjson, Country);
   		
   		String zipfrom = rows.get(row).substring(4, 15);
   		System.out.println("First row zip from is: "+zipfrom);
   		assertEquals(zipfromjson, zipfrom);
   		
   		String zipto = rows.get(row).substring(16, 27);
   		System.out.println("First row zip to is: "+zipto);
   		assertEquals(ziptojson, zipto);
   		
   		String destination = rows.get(row).substring(28, 32);
   		System.out.println("First row destination is: "+destination);
   		assertEquals(destjson, destination);
   		
   		String state = rows.get(row).substring(33, 35);
   		System.out.println("First row state code is: "+state);
   		assertEquals(statejson, state);
   	}
    
    @Given("^The base URI is up and running for Distribution for zipcode to network$")
    public void the_base_URI_is_up_and_running_distribution_zipcode_network() {
    	
    	RestAssured.baseURI = DistributionAPIProp.getProperty("Distribution.lcl.get");
    	
    }
    
    @When("^User sends network \"([^\"]*)\" and zipcode \"([^\"]*)\" to get destination$")
   	public void verify_user_sends_network_and_zipcode(String network, String zipcode) {
      	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byZipcode_network+"/"+network+"/"+zipcode);
        
   	}
    
    @And("^User verify destination \"([^\"]*)\"$")
   	public void User_verify_destination(String destination) {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		String dest = js.get("destination");
		
		assertEquals(destination, dest);
        
   	}
    
    @And("^User verify message \"([^\"]*)\"$")
   	public void User_verify_message(String message) {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		String invalidmessage = js.get("message");
		
		assertEquals(message, invalidmessage);
        
   	}
    
    @When("^User sends invalid URL network \"([^\"]*)\" and zipcode \"([^\"]*)\" to get destination$")
   	public void verify_user_sends_network_and_zipcode_invalid_URL(String network, String zipcode) {
      	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byZipcode_network_invalid+"/"+network+"/"+zipcode);
        
   	}
    
    @When("^User sends network \"([^\"]*)\" to get details$")
   	public void verify_user_sends_network_get_details(String network) {
      	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byNetwork+"/"+network);
        
   	}
    
    @When("^User sends invalid URL network \"([^\"]*)\" to get details$")
   	public void verify_user_sends_invalid_network_get_details(String network) {
      	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byNetwork_invalid+"/"+network);
        
   	}
    
}