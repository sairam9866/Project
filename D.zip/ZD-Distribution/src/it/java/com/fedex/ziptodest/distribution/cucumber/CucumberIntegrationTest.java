package com.fedex.ziptodest.distribution.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.fedex.ziptodest.distribution.utils.ConfigFileReader;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/it/resources/features/", 
plugin = {"pretty", "html:target/cucumber"})
public class CucumberIntegrationTest {
	
	@BeforeClass
	public static void setUp() throws IOException {

		ConfigFileReader.loadProperties();
		ConfigFileReader.writeProperties();
	}

	@AfterClass
	public static void writeExtentReport() { 
		
	}
}