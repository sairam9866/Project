package org.zd.batch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.model.ZipToDestHasDelta;
import org.zd.batch.model.ZipToDestination;
import org.zd.batch.temp.service.DataLoaderService;

@RestController
@RequestMapping("/batchrepo")
public class TransactionController {

	@Autowired
	DataLoaderService dataLoaderService;
	
	@GetMapping("/allTransactions")
	public List<ZipToDest> findAllTransaction() {
		return (List<ZipToDest>) dataLoaderService.findAllTransaction();
	}

	@GetMapping("/allFacilityDelta")
	public List<FacilityDelta> findAllFacilityDelta() {
		return ( List<FacilityDelta>) dataLoaderService.findAllFacilityDelta();
	}

	@GetMapping("/allFacilityHasDelta")
	public List<ZipToDestHasDelta> findAllFacilityHasDelta() {
		return (List<ZipToDestHasDelta>) dataLoaderService.findAllFacilityHasDelta();
	}

	@GetMapping("/allZipToDestination")
	public List<ZipToDestination> findAllZipToDestination() {		
		return (List<ZipToDestination>) dataLoaderService.findAllZipToDestination();
	}
}
