package org.zd.batch.temp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.model.ZipToDestHasDelta;
import org.zd.batch.model.ZipToDestination;
import org.zd.batch.repository.FacilityDeltaRepository;
import org.zd.batch.repository.ZipToDestHasDeltaRepository;
import org.zd.batch.repository.ZipToDestTransactionRepository;
import org.zd.batch.repository.ZipToDestinationRepository;
import org.zd.batch.temp.service.DataLoaderService;

@Service
public class DataLoaderServiceImpl implements DataLoaderService {

	@Autowired
	ZipToDestTransactionRepository zipToDestRepository;

	@Autowired
	private ZipToDestinationRepository zipToDestinationRepository;

	@Autowired
	private ZipToDestHasDeltaRepository zipToDestHasDeltaRepository;

	@Autowired
	FacilityDeltaRepository facilityIdRepository;

	@Override
	public List<ZipToDest> findAllTransaction() {
		return (List<ZipToDest>) zipToDestRepository.findAll();
	}

	@Override
	public List<FacilityDelta> findAllFacilityDelta() {
		return ( List<FacilityDelta>) facilityIdRepository.findAll();
	}

	@Override
	public List<ZipToDestHasDelta> findAllFacilityHasDelta() {
		return (List<ZipToDestHasDelta>) zipToDestHasDeltaRepository.findAll();
	}

	@Override
	public List<ZipToDestination> findAllZipToDestination() {		
		return (List<ZipToDestination>) zipToDestinationRepository.findAll();
	}

}
