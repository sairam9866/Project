package org.zd.batch.service.impl;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.model.ZipToDestination;
import org.zd.batch.repository.FacilityDeltaRepository;
import org.zd.batch.repository.ZipToDestTransactionRepository;
import org.zd.batch.repository.ZipToDestinationRepository;
import org.zd.batch.service.TransactionPayloadService;
import org.zd.batch.util.CsvReader;

@Service
public class TransactionPayloadServiceImpl implements TransactionPayloadService {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(TransactionPayloadServiceImpl.class);

	@Autowired
	ZipToDestTransactionRepository zipToDestTransactionRepository;

	@Autowired
	FacilityDeltaRepository facilityDeltaRepository;

	@Autowired
	ZipToDestinationRepository zipToDestinationRepository;

	@Override
	public void init() {
		saveZipToDest();
	}

	private void saveZipToDest() {
		CsvReader<ZipToDest> reader1 = new CsvReader<>();
		CsvReader<FacilityDelta> reader2 = new CsvReader<>();
		CsvReader<ZipToDestination> reader3 = new CsvReader<>();
		List<ZipToDest> records1 = reader1.read(ZipToDest.class, "transactions.csv");
		List<FacilityDelta> records2 = reader2.read(FacilityDelta.class, "Facility.csv");
		List<ZipToDestination> records3 = reader3.read(ZipToDestination.class, "zipToDest.csv");

		if (!records1.isEmpty()) {
			for (ZipToDest zipToDest : records1) {
				zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDest.setUuid(String.valueOf(System.currentTimeMillis()));
				zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDest.buildKey();
				LOGGER.info("Transaction : {} ",zipToDest);
				zipToDestTransactionRepository.save(zipToDest);
			}
		}

		if (!records2.isEmpty()) {
			for (FacilityDelta facilityDelta : records2) {
				facilityDelta.buildKey();
				LOGGER.info("Facility Delta : {} ",facilityDelta);
				facilityDeltaRepository.save(facilityDelta);
			}
		}

		if (!records3.isEmpty()) {
			for (ZipToDestination zipToDestination : records3) {
				zipToDestination.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDestination.buildKey();
				LOGGER.info("Zip To Destination : {} ",zipToDestination);
				zipToDestinationRepository.save(zipToDestination);
			}
		}

	}

}
