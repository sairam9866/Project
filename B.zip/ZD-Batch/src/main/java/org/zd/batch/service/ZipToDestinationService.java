package org.zd.batch.service;

import java.util.List;

import org.zd.batch.model.ZipToDest;

/**
 * 
 * @author 3818669
 *
 */
public interface ZipToDestinationService {
	public void addZipToDestination(List<ZipToDest> zipToDestList, Long jobDateTime);	
	
	public void deleteZipToDestination(List<ZipToDest> zipToDests);
}
