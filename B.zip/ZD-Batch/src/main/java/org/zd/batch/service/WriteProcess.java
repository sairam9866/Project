package org.zd.batch.service;

import org.springframework.batch.item.ExecutionContext;

public interface WriteProcess {	
	public int executeWriteProcess(ExecutionContext context, String transactionType, String keyUnprocessedType);
}
