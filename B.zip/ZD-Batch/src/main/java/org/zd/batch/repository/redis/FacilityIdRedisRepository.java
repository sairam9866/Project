package org.zd.batch.repository.redis;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.FacilityDelta;

@Repository("facilityIdRedisRepository")
public interface FacilityIdRedisRepository extends CrudRepository<FacilityDelta, String> {

	public List<FacilityDelta> findByNetworkAndZipCodeAndTransactionType(String network, String zipCode, String transactionType);
}
