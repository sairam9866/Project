package org.zd.batch.util;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.ExecutionContext;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.JobAuditResponse;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.model.ZipToDestHasDelta;
import org.zd.batch.model.ZipToDestination;

/**
 * A Utility class for ZD-Batch application.
 * 
 * @author 3818669
 *
 */
public final class ZipToDestBatchUtil {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestBatchUtil.class);

	public static final String TRANSACTION_TYPE_ADD = "A";
	public static final String TRANSACTION_TYPE_MODIFY = "M";
	public static final String TRANSACTION_TYPE_DELETE = "D";

	public static final String KEY_UNPROCESSED_ADDED = "unProcessedAddedTxn";
	public static final String KEY_UNPROCESSED_MODIFIED = "unProcessedModifiedTxn";
	public static final String KEY_UNPROCESSED_DELETED = "unProcessedDeletedTxn";
	public static final String STATUS_CODE_UNAUTHORIZED = "Unauthorized";
	public static final String STATUS_CODE_INVALID = "Invalid Resource";
	public static final String KEY_EXECUTION_COUNT = "executionCount";
	public static final String KEY_JOB_START_TIME = "jobDateTime";

	public static final String KEY_REFRESH = "app.refresh";

	public static final String FLAG_YES = "Y";
	public static final String FLAG_NO = "N";

	public static final Pattern PATTERN_US_ZIP_CODE = Pattern.compile("[0-9]{5,5}");
	public static final Pattern PATTERN_CANADA_ZIP_CODE3 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z]$");
	public static final Pattern PATTERN_CANADA_ZIP_CODE6 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z][\\d][a-zA-Z][\\d]$");

	public static final String ZD_DISTRIBUTION_CACHE_KEY = "zd.distribution.cache.key";
	public static final String ZD_DISTRIBUTION_APP_INSTANCE = "zd.distribution.app.instance";
	public static final String ZD_DISTRIBUTION_GUID = "zd.distribution.guid";
	public static final String ZD_DISTRIBUTION_INSTANCE_COUNT = "zd.distribution.instance.count";
	public static final String ZD_DISTRIBUTION_CACHE_URL = "zd.distribution.cache.url";

	private ZipToDestBatchUtil() {
		throw new AssertionError("No org.zd.batch.util.ZipToDestBatchUtil instances for you!");
	}

	/**
	 * Method to get the current ExecutionContext of spring batch Job.
	 * 
	 * ExecutionContext acts as Map, it internally using ConcurrentHashMap. With
	 * ExecutionContext we can store data as key:value pair. And this data will
	 * be available in whole Job execution life cycle.
	 * 
	 * Note that putting <code>null</code> value is equivalent to removing the
	 * entry for the given key.
	 * 
	 * @param chunkContext
	 *            contains information about Step and Job execution.
	 * @return current job's execution context.
	 */
	public static ExecutionContext getCurrentExecutionContext(ChunkContext chunkContext) {
		return (chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext());
	}

	/**
	 * A static factory method for creating a new instance of FacilityId.
	 * 
	 * @param -
	 *            ZipToDest(Transaction table) entity class.
	 * 
	 * @return a new instance of FacilityId class.
	 */
	public static FacilityDelta instanceOfFacilityId(ZipToDest zipToDest) {
		FacilityDelta facilityId = new FacilityDelta();		
		facilityId.setFacilityId(Integer.parseInt(zipToDest.getDestinationTerminal()));
		facilityId.setNetwork(zipToDest.getNetwork());
		facilityId.setZipCode(zipToDest.getZipCode());
		facilityId.setEffectiveDateTime(zipToDest.getEffectiveDateAt());		
		facilityId.setState(zipToDest.getState());
		facilityId.setTransactionType(zipToDest.getTransactionType());
		facilityId.setUuId(zipToDest.getUuid());
		facilityId.buildKey();
		return facilityId;
	}	

	/**
	 * A static factory method to get the new instance of ZipToDestination.
	 * 
	 * @param zipToDest
	 *            - ZipToDest(Transaction table) entity class.
	 * @return - new instance of ZipToDestination class.
	 */
	public static ZipToDestination instanceOfZipToDestination(ZipToDest zipToDest) {
		ZipToDestination zipToDestination = new ZipToDestination();
		zipToDestination.setCountryCode(zipToDest.getCountryCode());
		zipToDestination.setNetwork(zipToDest.getNetwork());
		zipToDestination.setZipCode(zipToDest.getZipCode());		
		zipToDestination.setDestination(zipToDest.getDestinationTerminal());
		zipToDestination.setState(zipToDest.getState());
		zipToDestination.setLastUpdateBy(zipToDest.getCreationUser());
		zipToDestination.setLastUpdateTimestamp(zipToDest.getEffectiveDateAt());
		zipToDestination.buildKey();
		return zipToDestination;
	}

	/**
	 * A static factory method to get the new instance of ZipToDestinationPK.
	 * 
	 * ZipToDestinationPK is a composite primary representation of
	 * ZipToDestination entity class.
	 * 
	 * @param zipToDest
	 *            - ZipToDest(Transaction table) entity class.
	 * 
	 * @return - new instance of ZipToDestinationPK class.
	 */
	/*public static ZipToDestinationPK instanceOfZipToDestinationPK(ZipToDest zipToDest) {
		ZipToDestinationPK zipToDestinationPK = new ZipToDestinationPK();
		zipToDestinationPK.setCountryCode(zipToDest.getCountryCode());
		zipToDestinationPK.setNetwork(zipToDest.getNetwork());
		zipToDestinationPK.setZipCode(zipToDest.getZipCode());
		return zipToDestinationPK;
	}*/

	/**
	 * 
	 * @param jobExecution
	 * @return
	 */
	public static JobAuditResponse instanceOfJobAuditResponse(JobExecution jobExecution) {
		JobAuditResponse jobAuditResponse = new JobAuditResponse();
		jobAuditResponse.setCreateTime(jobExecution.getCreateTime());
		jobAuditResponse.setEndTime(jobExecution.getEndTime());
		jobAuditResponse.setExitMessage(jobExecution.getExitStatus().getExitCode());
		jobAuditResponse.setLastUpdated(jobExecution.getLastUpdated());
		jobAuditResponse.setStartTime(jobExecution.getStartTime());
		jobAuditResponse.setStatus(jobExecution.getStatus().name());
		if (!jobExecution.getFailureExceptions().isEmpty()) {
			jobAuditResponse.setStackTrace(jobExecution.getFailureExceptions().get(0).getMessage());
		}
		return jobAuditResponse;
	}

	/**
	 * 
	 * @param zipToDestination
	 * @return
	 */
	public static ZipToDestHasDelta instanceOfZipToDestHasDelta(String network, Long effectiveDate) {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork(network);
		zipToDestHasDelta.setLastUpdateTimestamp(effectiveDate);
		return zipToDestHasDelta;
	}

	/**
	 * Method to get the current UTC time.
	 * 
	 * @return - <code>Timestamp</code> which holds the current UTC time.
	 */
	public static Timestamp getCurrentUtcTimestamp() {
		return Timestamp.valueOf(Instant.now().atZone(ZoneOffset.UTC).toLocalDateTime());
	}
	
	public static Long getCurrentUtcEpochTime() {
		return ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond();
	}

	/**
	 * Method to validate the given zipcode is a valid US zipcode or not.
	 * 
	 * @param zipCode
	 *            - zipcode value.
	 * 
	 * @return - true if the zipCode is a valid US zipcode otherwise return
	 *         false.
	 */
	public static boolean isValidUsaZipCode(String zipCode) {
		LOGGER.debug("Zip Code -> {}", zipCode);
		boolean output = false;
		output = (PATTERN_US_ZIP_CODE.matcher(zipCode).matches());
		LOGGER.debug("Is valid Us zipcode {} -> {}", zipCode, output);
		return output;
	}

	/**
	 * Method to validate the given zipcode is a valid Canadian zipcode or not.
	 * 
	 * @param zipCode
	 *            - zipcode value.
	 * 
	 * @return - true if the zipCode is a valid Canadian zipcode otherwise
	 *         return false.
	 */
	public static boolean isValidCanadaZipCode(String zipCode) {
		LOGGER.debug("Zip Code -> {}", zipCode);
		boolean output = false;
		output = (PATTERN_CANADA_ZIP_CODE3.matcher(zipCode).matches()
				|| PATTERN_CANADA_ZIP_CODE6.matcher(zipCode).matches());
		LOGGER.debug("Is valid Canadian zipcode {} -> {}", zipCode, output);
		return output;
	}

	public static String getActualZipcode(String zipCode) {
		return (zipCode.length() == 11 ? zipCode.substring(0, 5) : zipCode);
	}	
}
