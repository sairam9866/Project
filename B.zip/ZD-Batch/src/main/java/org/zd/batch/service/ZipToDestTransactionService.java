package org.zd.batch.service;

import java.util.List;

import org.zd.batch.model.ZipToDest;

/**
 * 
 * @author 3818669
 *
 */
public interface ZipToDestTransactionService {

	public List<ZipToDest> findUnProcessedTransactionByType(Long currentUtcTimestamp, String type);

	public List<ZipToDest> findOlderTransactions(String netwrok, String zipCode);

	public void updateNotProcessedTransactions(List<ZipToDest> zipToDests, Long processedAt, String joblFlow);

	public void updateOlderTransactions(List<ZipToDest> zipToDests, Long processedAt);	
	
}
