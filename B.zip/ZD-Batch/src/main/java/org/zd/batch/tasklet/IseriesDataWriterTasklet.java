package org.zd.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.zd.batch.model.CountryCode;
import org.zd.batch.model.Destination;
import org.zd.batch.model.Network;
import org.zd.batch.model.StateProvince;
import org.zd.batch.repository.NetworkRepository;
import org.zd.batch.repository.redis.CountryCodeRedisRepository;
import org.zd.batch.repository.redis.DestinationRedisRepository;
import org.zd.batch.repository.redis.StateProvinceRedisRepository;
import org.zd.batch.util.AppConstants;
import org.zd.batch.util.ZipToDestBatchUtil;

@Component
public class IseriesDataWriterTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(IseriesDataWriterTasklet.class);

	@Autowired
	CountryCodeRedisRepository countryCodeRedisRepository;

	@Autowired
	NetworkRepository networkRepository;

	@Autowired
	DestinationRedisRepository destinationRedisRepository;

	@Autowired
	StateProvinceRedisRepository stateProvinceRedisRepository;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);
		int countryCodesSize = 0;
		int networksSize = 0;
		int destinationsSize = 0;
		int stateProvinceSavedSize = 0;

		@SuppressWarnings("unchecked")
		List<CountryCode> countryCodes = (List<CountryCode>) context.get(AppConstants.KEY_COUNTRY_CODE);

		@SuppressWarnings("unchecked")
		List<Network> networks = (List<Network>) context.get(AppConstants.KEY_NETWORKS);

		@SuppressWarnings("unchecked")
		List<Destination> destinations = (List<Destination>) context.get(AppConstants.KEY_DESTINATIONS);

		@SuppressWarnings("unchecked")
		List<StateProvince> stateProvinces = (List<StateProvince>) context.get(AppConstants.KEY_STATE_PROVINCES);

		LOGGER.info("Writing Country Codes count : {}", countryCodes.size());
		LOGGER.info("Writing Network count : {}", networks.size());
		LOGGER.info("Writing Destination count : {}", destinations.size());
		LOGGER.info("Writing State Province count : {}", stateProvinces.size());

		if (!countryCodes.isEmpty()) {
			LOGGER.info("Writing Country Code to Redis");
			List<CountryCode> countryCodeSaved = (List<CountryCode>) countryCodeRedisRepository.saveAll(countryCodes);
			countryCodesSize = countryCodeSaved.size();
			LOGGER.info("Saved count of Country Code in Redis : {}", countryCodeSaved.size());	
			if(countryCodesSize > 0){
				LOGGER.info("Country Code saved successfully in Redis.");
			}
		}

		if (!networks.isEmpty()) {
			LOGGER.info("Writing Networks to Redis");
			List<Network> networkSaved = (List<Network>) networkRepository.saveAll(networks);
			networksSize = networkSaved.size();
			LOGGER.info("Saved count of Networks in Redis : {}", networkSaved.size());
			if(networksSize > 0){
				LOGGER.info("Networks saved successfully in Redis.");
			}
		}

		if (!destinations.isEmpty()) {
			LOGGER.info("Writing Destinations to Redis");
			List<Destination> destinationSaved = (List<Destination>) destinationRedisRepository.saveAll(destinations);
			destinationsSize = destinationSaved.size();
			LOGGER.info("Saved count of Destinations in Redis : {}", destinationSaved.size());
			if(destinationsSize > 0){
				LOGGER.info("Destination saved successfully in Redis.");
			}
		}

		if (!stateProvinces.isEmpty()) {
			LOGGER.info("Writing StateProvinces to Redis");
			List<StateProvince> stateProvinceSaved = (List<StateProvince>) stateProvinceRedisRepository.saveAll(stateProvinces);
			stateProvinceSavedSize = stateProvinceSaved.size();
			LOGGER.info("Saved Count of StateProvinces in Redis : {}", stateProvinceSaved.size());
			if(stateProvinceSavedSize > 0){
				LOGGER.info("StateProvince saved successfully in Redis.");
			}
		}

		return RepeatStatus.FINISHED;
	}

}
