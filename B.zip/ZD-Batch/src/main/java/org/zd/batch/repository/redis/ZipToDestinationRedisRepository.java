package org.zd.batch.repository.redis;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.ZipToDestination;

/**
 * 
 * @author 3818669
 *
 */

@Repository("zipToDestinationRedisRepository")
public interface ZipToDestinationRedisRepository extends CrudRepository<ZipToDestination, String>{

}
