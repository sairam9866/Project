package org.zd.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.zd.batch.config.IseriesJdbcTemplate;
import org.zd.batch.model.CountryCode;
import org.zd.batch.model.Destination;
import org.zd.batch.model.Network;
import org.zd.batch.model.StateProvince;
import org.zd.batch.model.mappers.CountryCodeRowMapper;
import org.zd.batch.model.mappers.DestionationRowMapper;
import org.zd.batch.model.mappers.NetworkRowMapper;
import org.zd.batch.model.mappers.StateProvinceRowMapper;
import org.zd.batch.util.AppConstants;
import org.zd.batch.util.ZipToDestBatchUtil;

@Component
public class IseriesDataReaderTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(IseriesDataReaderTasklet.class);

	@Autowired
	IseriesJdbcTemplate iseriesJdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

		JdbcTemplate jdbcTemplate = iseriesJdbcTemplate.getJdbcTemplate();

		List<CountryCode> countryCodes = jdbcTemplate.query(AppConstants.SQL_ALL_COUNTRY_CODE,
				new CountryCodeRowMapper());

		List<Network> networks = jdbcTemplate.query(AppConstants.SQL_ALL_NETWORKS, new NetworkRowMapper());

		List<Destination> destinations = jdbcTemplate.query(AppConstants.SQL_ALL_DESTINATIONS,
				new DestionationRowMapper());

		List<StateProvince> stateProvinces = jdbcTemplate.query(AppConstants.SQL_ALL_STATE_PROVINCES,
				new StateProvinceRowMapper());

		LOGGER.info("Country Codes count : {}", countryCodes.size());
		LOGGER.info("Network count : {}", networks.size());
		LOGGER.info("Destination count : {}", destinations.size());
		LOGGER.info("State Province count : {}", stateProvinces.size());

		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);

		context.put(AppConstants.KEY_COUNTRY_CODE, countryCodes);
		context.put(AppConstants.KEY_NETWORKS, networks);
		context.put(AppConstants.KEY_DESTINATIONS, destinations);
		context.put(AppConstants.KEY_STATE_PROVINCES, stateProvinces);

		return RepeatStatus.FINISHED;
	}

}
