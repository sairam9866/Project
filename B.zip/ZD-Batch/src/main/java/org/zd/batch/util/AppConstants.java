package org.zd.batch.util;

public final class AppConstants {

	private AppConstants(){		
	}
	
	public static final String SQL_ALL_COUNTRY_CODE = "select CYCODE,CYCLCU from ITLPF001";
	public static final String SQL_ALL_NETWORKS = "select ROW_ID,TERM_NUM,NETWORK_ID,CREATED_BY,CREATED_DT,UPDATED_BY,UPDATED_DT,MODEL_TYPE,COLOC_NUM from SRT509F";
	public static final String SQL_ALL_DESTINATIONS = "select TRMABR,TRMNUM,TRMSTS from SRTPF508";
	public static final String SQL_ALL_STATE_PROVINCES = "select STAPRO,SPNAME,CNTRYC from CANPF010";
	
	public static final String KEY_COUNTRY_CODE = "COUNTRY_CODE_KEY";
	public static final String KEY_NETWORKS = "NETWORKS_KEY";
	public static final String KEY_STATE_PROVINCES = "STATE_PROVINCES_KEY";
	public static final String KEY_DESTINATIONS = "DESTINATIONS_KEY";	
	
	public static final String HASH_KEY_NETWORK = "ISERIES_NETWORK";
	
	public static final String APP_PROFILE_LOCAL = "local";
	
	public static final String FACILITY_HASH_KEY = "FACILITYDELTA";
	public static final String ZIP_TO_DEST_NETWORKS = "ZIPTODESTNETWORKS";
	public static final String ZIP_TO_DEST = "ZIPTODEST";
	
	public static final String APP_TRANSACTION_TMSTMP_KEY = "ZDTRANSACTIONS_TMSTMP";
	public static final String APP_TRANSACTION_ZIP_US_KEY = "TRANSACTION_US";
	public static final String APP_TRANSACTION_ZIP_CA_KEY = "TRANSACTION_CA";
	public static final String APP_TRANSACTION_PROCESS_TMSTAMP_KEY = "PROCESS_TMSTMP";
	public static final String APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY = "SAVE_PROCESS_TMSTMP";	
	public static final String APP_TRANSACTION_ZIP_KEY = "TRANSACTIONS_ZIPCODES";
	public static final double ZIP_CODE_DEFAULT_SCORE = 1d;
	public static final String ZIP_TO_DEST_HAS_DELTA_HASH_KEY = "ZIPTODESTHASDELTA";
}
