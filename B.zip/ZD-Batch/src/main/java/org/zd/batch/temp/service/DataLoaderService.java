package org.zd.batch.temp.service;

import java.util.List;

import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.model.ZipToDestHasDelta;
import org.zd.batch.model.ZipToDestination;

public interface DataLoaderService {

	public List<ZipToDest> findAllTransaction();
	public List<FacilityDelta> findAllFacilityDelta();
	public List<ZipToDestHasDelta> findAllFacilityHasDelta();
	public List<ZipToDestination> findAllZipToDestination();
}
