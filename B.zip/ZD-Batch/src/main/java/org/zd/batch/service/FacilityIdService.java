package org.zd.batch.service;

import java.util.List;

import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;

/**
 * 
 * @author 3818669
 *
 */
public interface FacilityIdService {

	public void addZipToDestFacility(List<ZipToDest> zipToDests, Long jobStartTime);

	public void deleteZipToDestFacility(List<FacilityDelta> zipToDests, Long jobStartTime);

	public List<FacilityDelta> findZipcodeRangeByNetwork(String network, String zipCode);
}
