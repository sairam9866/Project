package org.zd.batch.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.repository.FacilityDeltaRepository;
import org.zd.batch.service.FacilityIdService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * 
 * The implementation class of FacilityIdService.
 * 
 * @author 3818669
 *
 */

@Service
public class FacilityIdServiceImpl implements FacilityIdService {

	public static final Logger LOGGER = LoggerFactory.getLogger(FacilityIdServiceImpl.class);

	@Autowired
	FacilityDeltaRepository facilityIdRepository;

	/**
	 * Method will return a list of facility by network and zip code.
	 * 
	 * @param network
	 *            - ZipToDest network code.
	 * @param zipCode
	 *            - ZipToDest zipcode.
	 * 
	 * @return Returns a list of facility
	 */
	@Override
	public List<FacilityDelta> findZipcodeRangeByNetwork(String network, String zipCode) {
		return facilityIdRepository.findZipcodeRangeByNetwork(network, zipCode);
	}

	/**
	 * Method will convert each transactions into corresponding Facility and
	 * inserting it into Facility master table.
	 * 
	 * @param zipToDests
	 *            - list of ZipToDest.
	 * @param jobStartTime
	 *            - jobStartTime.
	 */
	@Override
	public void addZipToDestFacility(List<ZipToDest> zipToDests, Long jobStartTime) {
		LOGGER.info("FacilityIdServiceImpl::saveZipToDestFacility - Inserting Transactions into Facilty master table.");
		LOGGER.debug("FacilityIdServiceImpl::saveZipToDestFacility - input ZipToDest list with size {} ",
				zipToDests.size());
		for (ZipToDest zipToDest : zipToDests) {

			LOGGER.debug("Transaction -> {}", zipToDest);

			FacilityDelta facilityId = ZipToDestBatchUtil.instanceOfFacilityId(zipToDest);
			facilityId.setTransactionType(ZipToDestBatchUtil.TRANSACTION_TYPE_ADD);
			facilityId.setEffectiveDateTime(jobStartTime);

			if (zipToDest.getZipCode().length() == 11) {
				facilityId.setZipCode(zipToDest.getZipCode().substring(0, 5));
			}
			facilityId.buildKey();
			LOGGER.debug("Inserting Facility -> {}", facilityId);
			facilityIdRepository.save(facilityId);
		}
		LOGGER.info(
				"FacilityIdServiceImpl::saveZipToDestFacility - Transactions are inserted into Facilty master table.");
	}

	/**
	 * Method will update the older zip code associations with transaction type
	 * 'D'.
	 * 
	 * @param facilityIds
	 *            - list of FacilityIds.
	 */
	@Override
	public void deleteZipToDestFacility(List<FacilityDelta> facilityIds, Long jobStartTime) {
		LOGGER.debug("FacilityIdServiceImpl::deleteZipToDestFacility - input FacilityId list with size {} ",
				facilityIds.size());
		for (FacilityDelta facility : facilityIds) {
			LOGGER.info("Updating facility transaction type to 'D' -> {}", facility);

			int updateCount = facilityIdRepository.updateFacilityTransTypeAndDateByPk(jobStartTime,
					ZipToDestBatchUtil.TRANSACTION_TYPE_DELETE, facility.getId());

			LOGGER.info("Updated {} facility transactions.", updateCount);
		}
		LOGGER.debug("FacilityIdServiceImpl::deleteZipToDestFacility - Facility transaction type update finished.");
	}

}
