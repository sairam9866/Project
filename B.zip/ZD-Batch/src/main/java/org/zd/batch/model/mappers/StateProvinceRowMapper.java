package org.zd.batch.model.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.zd.batch.model.StateProvince;

public class StateProvinceRowMapper implements RowMapper<StateProvince>{

	@Override
	public StateProvince mapRow(ResultSet rs, int rowNum) throws SQLException {
		StateProvince stateProvince = new StateProvince();
		stateProvince.setCntryc(StringUtils.trim(rs.getString("CNTRYC")));
		stateProvince.setSpName(StringUtils.trim(rs.getString("SPNAME")));
		stateProvince.setStaPro(StringUtils.trim(rs.getString("STAPRO")));
		return stateProvince;
	}

}
