package org.zd.batch.repository.redis;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.ZipToDestHasDelta;

@Repository("zipToDestHasDeltaRedisRepository")
public interface ZipToDestHasDeltaRedisRepository extends CrudRepository<ZipToDestHasDelta, String> {

}
