package org.zd.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.ZipToDestTransactionService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * The Tasklet implementation class for finding not processed transactions with
 * transaction type 'M' from the Transaction table. 
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestModifyReadTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestModifyReadTasklet.class);

	@Autowired
	private ZipToDestTransactionService zipToDestTransactionService;

	/**
	 * <p>The Tasklet::execute method implementation finds the not processed transactions which are
	 * modified up to current UTC time and keeps the transaction(s) inside
	 * <code>Job's</code> <code>ExecutionContext</code>.</p>
	 * 
	 * <p>The Not Processed transaction means -The Processed, Current and Cancelled
	 * flags must be 'N'.</p>
	 * 
	 * <p>
	 * Implementations return {@link RepeatStatus#FINISHED} if finished. If not
	 * they return {@link RepeatStatus#CONTINUABLE}. On failure throws an
	 * exception.
	 * </p>
	 * 
	 * @param contribution
	 *            mutable state to be passed back to update the current step
	 *            execution.
	 * @param chunkContext
	 *            attributes shared between invocations but not between
	 *            restarts.
	 * 
	 * @throws Exception
	 *             thrown if error occurs during execution.
	 * 
	 * @return an {@link RepeatStatus} indicating whether processing is
	 *         continuable. Returning {@code null} is interpreted as
	 *         {@link RepeatStatus#FINISHED}
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Starting ZipToDestModifyReadTasklet :- Step");

		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);

		List<ZipToDest> zipToDests = zipToDestTransactionService
				.findUnProcessedTransactionByType(ZipToDestBatchUtil.getCurrentUtcEpochTime(), ZipToDestBatchUtil.TRANSACTION_TYPE_MODIFY);

		LOGGER.info("Adding {} Not Processed Transaction with transaction type 'M' to the Job ExecutionContext.",
				zipToDests.size());
		context.put(ZipToDestBatchUtil.KEY_UNPROCESSED_MODIFIED, zipToDests);

		LOGGER.info("Finished ZipToDestModifyReadTasklet :- Step");
		return RepeatStatus.FINISHED;
	}

}
