package org.zd.batch.repository;

import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.ZipToDestination;
import org.zd.batch.repository.redis.ZipToDestinationRedisRepository;
import org.zd.batch.util.AppConstants;

/**
 * 
 * @author 3818669
 *
 */
@Repository("zipToDestinationRepository")
public class ZipToDestinationRepository implements ZipToDestinationRedisRepository {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestinationRepository.class);
	
	@Autowired
	ZipToDestinationRedisRepository zipToDestinationRedisRepository;
	
	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDestination> sortedzipToDestSetOperations;
	
	@Resource(name = "redisTemplate")
	private SetOperations<String, String> normalzipToDestSetOperations;
	
	@SuppressWarnings("unchecked")
	@Override
	public ZipToDestination save(ZipToDestination zipToDestination) {		
		normalzipToDestSetOperations.add(AppConstants.ZIP_TO_DEST_NETWORKS, zipToDestination.getNetwork());
		sortedzipToDestSetOperations.add(AppConstants.ZIP_TO_DEST, zipToDestination, zipToDestination.getLastUpdateTimestamp());		
		return zipToDestinationRedisRepository.save(zipToDestination);
	}
	
	@Override
	public long count() {		
		return zipToDestinationRedisRepository.count();
	}

	@Override
	public void delete(ZipToDestination zipToDestination) {	
		LOGGER.info("Deleting ZipToDestination From Hash - {}", zipToDestination);
		zipToDestinationRedisRepository.delete(zipToDestination);		
		
		LOGGER.info("Deleting ZipToDestination From ZSet Data Structure {}.", zipToDestination);
		long rmCount = sortedzipToDestSetOperations.remove(AppConstants.ZIP_TO_DEST, zipToDestination);
		LOGGER.info("Deleted {} ZipToDestination From ZSet Data Structure.", rmCount);
	}

	@Override
	public void deleteAll() {
		zipToDestinationRedisRepository.deleteAll();
	}

	@Override
	public void deleteAll(Iterable<? extends ZipToDestination> arg0) {
		zipToDestinationRedisRepository.deleteAll(arg0);		
	}

	@Override
	public void deleteById(String arg0) {
		zipToDestinationRedisRepository.deleteById(arg0);		
	}

	@Override
	public boolean existsById(String arg0) {
		return zipToDestinationRedisRepository.existsById(arg0);
	}

	@Override
	public Iterable<ZipToDestination> findAll() {
		return zipToDestinationRedisRepository.findAll();
	}

	@Override
	public Iterable<ZipToDestination> findAllById(Iterable<String> arg0) {
		return zipToDestinationRedisRepository.findAllById(arg0);
	}

	@Override
	public Optional<ZipToDestination> findById(String arg0) {
		return zipToDestinationRedisRepository.findById(arg0);
	}

	@Override
	public <S extends ZipToDestination> Iterable<S> saveAll(Iterable<S> arg0) {	
		return zipToDestinationRedisRepository.saveAll(arg0);
	}

}
