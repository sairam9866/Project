package org.zd.batch.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.model.ZipToDestination;
import org.zd.batch.repository.ZipToDestinationRepository;
import org.zd.batch.service.ZipToDestinationService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * The implementation class of ZipToDestinationService.
 * 
 * @author 3818669
 *
 */
@Service
public class ZipToDestinationServiceImpl implements ZipToDestinationService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestinationServiceImpl.class);

	@Autowired
	private ZipToDestinationRepository zipToDestinationRepository;

	/**
	 * The ZipToDestinationService::addZipToDestination implementation will
	 * process list of not processed transactions and insert it into
	 * ZipToDestionation master table.
	 * 
	 * @param zipToDests
	 *            - List of not processed ZiptoDest objects.
	 */
	@Override
	public void addZipToDestination(List<ZipToDest> zipToDests, Long jobDateTime) {
		ZipToDestination zipToDestination;
		LOGGER.info("Inserting not processed transaction into ziptodestination master table...");
		LOGGER.debug("ZipToDestinationServiceImpl::saveZipToDestinationService - input ZipToDest list with size {} ",
				zipToDests.size());

		for (ZipToDest zipToDest : zipToDests) {
			LOGGER.debug("Processing transaction -> {}", zipToDest);

			zipToDestination = ZipToDestBatchUtil.instanceOfZipToDestination(zipToDest);
			zipToDestination.setLastUpdateTimestamp(jobDateTime);
			LOGGER.debug("inserting ziptodestination -> {}", zipToDestination);
			zipToDestinationRepository.save(zipToDestination);
		}
		LOGGER.info("Not processed transaction are inserted into ziptodestination master table.");

	}

	/**
	 * The ZipToDestinationService::deleteZipToDestination implementation will
	 * physically deleting older zip code associations from the master table.
	 * 
	 * @param zipToDests
	 *            - list of transactions.
	 */
	@Override
	public void deleteZipToDestination(List<ZipToDest> zipToDests) {
		ZipToDestination zipToDestination;
		LOGGER.info("Physically deleting older transactions from ziptodestination master table...");
		LOGGER.info("ZipToDestinationServiceImpl::deleteZipToDestination - input ZipToDest list with size {} ",
				zipToDests.size());
		for (ZipToDest zipToDest : zipToDests) {
			zipToDestination = ZipToDestBatchUtil.instanceOfZipToDestination(zipToDest);
			LOGGER.info("Deleting ZipToDestination -> {}", zipToDestination);
			LOGGER.info("Deleting ZipToDestination ID -> {}", zipToDestination.getId());
			zipToDestinationRepository.delete(zipToDestination);
		}
		LOGGER.info("Physically deleted older transactions from ziptodestination master table.");
	}

}
