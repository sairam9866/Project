package org.zd.batch.repository;

import java.util.Optional;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.ZipToDestHasDelta;
import org.zd.batch.repository.redis.ZipToDestHasDeltaRedisRepository;
import org.zd.batch.util.AppConstants;

/**
 * 
 * @author 3818669
 *
 */
@Repository("zipToDestHasDeltaRepository")
public class ZipToDestHasDeltaRepository implements ZipToDestHasDeltaRedisRepository{

	@Autowired
	@Qualifier("zipToDestHasDeltaRedisRepository")
	ZipToDestHasDeltaRedisRepository zipToDestHasDeltaRedisRepository;
	
	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDestHasDelta> sortedzipToDestHasDeltaSetOperations;
	
	@SuppressWarnings("unchecked")
	@Override
	public ZipToDestHasDelta save(ZipToDestHasDelta zipToDestHasDelta) {
		sortedzipToDestHasDeltaSetOperations.add(AppConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY, zipToDestHasDelta,
				zipToDestHasDelta.getLastUpdateTimestamp());
		return zipToDestHasDeltaRedisRepository.save(zipToDestHasDelta);
	}

	@Override
	public long count() {
		return zipToDestHasDeltaRedisRepository.count();
	}

	@Override
	public void delete(ZipToDestHasDelta arg0) {
		zipToDestHasDeltaRedisRepository.delete(arg0);		
	}

	@Override
	public void deleteAll() {
		zipToDestHasDeltaRedisRepository.deleteAll();		
	}

	@Override
	public void deleteAll(Iterable<? extends ZipToDestHasDelta> arg0) {
		zipToDestHasDeltaRedisRepository.deleteAll(arg0);		
	}

	@Override
	public void deleteById(String arg0) {
		zipToDestHasDeltaRedisRepository.deleteById(arg0);		
	}

	@Override
	public boolean existsById(String arg0) {		
		return zipToDestHasDeltaRedisRepository.existsById(arg0);
	}

	@Override
	public Iterable<ZipToDestHasDelta> findAll() {
		return zipToDestHasDeltaRedisRepository.findAll();
	}

	@Override
	public Iterable<ZipToDestHasDelta> findAllById(Iterable<String> arg0) {
		return zipToDestHasDeltaRedisRepository.findAllById(arg0);
	}

	@Override
	public Optional<ZipToDestHasDelta> findById(String arg0) {		
		return zipToDestHasDeltaRedisRepository.findById(arg0);
	}	

	@Override
	public <S extends ZipToDestHasDelta> Iterable<S> saveAll(Iterable<S> arg0) {		
		return zipToDestHasDeltaRedisRepository.saveAll(arg0);
	}
}
