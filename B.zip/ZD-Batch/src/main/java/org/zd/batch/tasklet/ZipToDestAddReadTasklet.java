package org.zd.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.ZipToDestTransactionService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * The Tasklet implementation class for finding not processed transactions with
 * transaction type 'A' from the Transaction table.
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestAddReadTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestAddReadTasklet.class);

	@Autowired
	private ZipToDestTransactionService zipToDestTransactionService;

	/**
	 * The method implementation finds the not processed transactions which are
	 * added up to current UTC time and keeps the transaction(s) inside
	 * <code>Job's</code> <code>ExecutionContext</code>.
	 * 
	 * <p>The Not Processed transaction means -The Processed, Current and Cancelled
	 * flags must be 'N'.</p>
	 * 
	 * <p>
	 * The ExecutionContext is a set of key-value pairs containing information that
	 * is scoped to either StepExecution or JobExecution.
	 * </p>
	 * 
	 * <p>
	 * Implementations return {@link RepeatStatus#FINISHED} if finished. If not
	 * they return {@link RepeatStatus#CONTINUABLE}. On failure throws an
	 * exception.
	 * </p>
	 *
	 * 
	 * @param contribution
	 *            mutable state to be passed back to update the current step
	 *            execution.
	 * @param chunkContext
	 *            attributes shared between invocations but not between
	 *            restarts.
	 * 
	 * @throws Exception
	 *             thrown if error occurs during execution.
	 * 
	 * @return an {@link RepeatStatus} indicating whether processing is
	 *         continuable. Returning {@code null} is interpreted as
	 *         {@link RepeatStatus#FINISHED}
	 *         
	 * @see ExecutionContext    
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info("Starting ZipToDestAddReadTasklet - Step.");

		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);
		context.put(ZipToDestBatchUtil.KEY_JOB_START_TIME, ZipToDestBatchUtil.getCurrentUtcEpochTime());

		List<ZipToDest> zipToDests = zipToDestTransactionService.findUnProcessedTransactionByType(
				ZipToDestBatchUtil.getCurrentUtcEpochTime(), ZipToDestBatchUtil.TRANSACTION_TYPE_ADD);

		LOGGER.info("Adding {} Not Processed Transaction with transaction type 'A' to the Job ExecutionContext.",
				zipToDests.size());

		context.put(ZipToDestBatchUtil.KEY_UNPROCESSED_ADDED, zipToDests);
		
		LOGGER.info("Finished ZipToDestAddReadTasklet - Step.");
		return RepeatStatus.FINISHED;
	}

}
