package org.zd.batch.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

/**
 * @author 3818669
 *
 */

@RedisHash("ZipToDest")
public class ZipToDestination {

	@Id
	private String id;

	@Indexed
	private String network;

	@Indexed
	private Integer countryCode;

	@Indexed
	private String zipCode;

	private String state;

	@Indexed
	private String destination;

	private Long lastUpdateTimestamp;

	private String lastUpdateBy;

	public ZipToDestination() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Long getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Long lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public void buildKey() {
		setId(this.network + this.countryCode + this.zipCode);
	}

	@Override
	public String toString() {
		return "ZipToDestination [id=" + id + ", network=" + network + ", countryCode=" + countryCode + ", zipCode="
				+ zipCode + ", state=" + state + ", destination=" + destination + ", lastUpdateTimestamp="
				+ lastUpdateTimestamp + ", lastUpdateBy=" + lastUpdateBy + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass()) {
			return false;
		}
		ZipToDestination other = (ZipToDestination) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}

		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
