package org.zd.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.FacilityIdService;
import org.zd.batch.service.ZipToDestTransactionService;
import org.zd.batch.service.ZipToDestinationService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * The Tasklet implementation class for inserting not processed transactions
 * into Facility and ZipToDest master table.
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestAddWriteTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestAddWriteTasklet.class);

	@Autowired
	FacilityIdService facilityIdService;

	@Autowired
	ZipToDestinationService zipToDestinationService;

	@Autowired
	private ZipToDestTransactionService zipToDestTransactionService;

	/**
	 * The Tasklet::execute method implementation contains the business logic
	 * for inserting the not processed transactions into Facility and ZiptoDest
	 * master table.
	 * 
	 * <pre>
	 * Add Batch Process Flow:
	 * 1. Getting not processed transaction with transaction type as 'A' from ExecutionContext.
	 * 2. Adding the transactions into Facility master table.
	 * 3. Adding the transactions into Zip To Destination  master table.
	 * 4. Updating current transaction(s) Processed and Current flag as 'Y'
	 * </pre> 
	 * 
	 * <p>
	 * Implementations return {@link RepeatStatus#FINISHED} if finished. If not
	 * they return {@link RepeatStatus#CONTINUABLE}. On failure throws an
	 * exception.
	 * </p>
	 * 
	 * @param contribution
	 *            mutable state to be passed back to update the current step
	 *            execution
	 * @param chunkContext
	 *            attributes shared between invocations but not between restarts
	 * @return an {@link RepeatStatus} indicating whether processing is
	 *         continuable. Returning {@code null} is interpreted as
	 *         {@link RepeatStatus#FINISHED}
	 *
	 * @throws Exception
	 *             thrown if error occurs during execution.
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info("Starting Add Batch Process... ");
		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);
		
		@SuppressWarnings("unchecked")
		List<ZipToDest> zipToDestList = (List<ZipToDest>) context.get(ZipToDestBatchUtil.KEY_UNPROCESSED_ADDED);
		
		int executionCount = 0;
		if(!context.containsKey(ZipToDestBatchUtil.KEY_EXECUTION_COUNT)){
			context.putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, executionCount);
		}

		if (!zipToDestList.isEmpty()) {
			
			Long jobDateTime = (Long) context.get(ZipToDestBatchUtil.KEY_JOB_START_TIME);
			
			context.putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, zipToDestList.size() + context.getInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT));
			
			LOGGER.debug("{} Not processed transactions with type 'A'  found for batch processing.",
					zipToDestList.size());

			LOGGER.info("Starting add batch process in Facility table...");
			facilityIdService.addZipToDestFacility(zipToDestList, jobDateTime);
			LOGGER.info("Not processed transactions successfully inserted in Facilty.");

			LOGGER.info(
					"Starting add batch process in ZipToDestination table...");
			zipToDestinationService.addZipToDestination(zipToDestList, jobDateTime);
			LOGGER.info("Not processed transactions successfully inserted in ZipToDestination.");

			LOGGER.info("Starting updating Transaction's processed and current flag... ");
			zipToDestTransactionService.updateNotProcessedTransactions(zipToDestList, jobDateTime,
					ZipToDestBatchUtil.TRANSACTION_TYPE_ADD);
			LOGGER.info("Transaction's processed and current flag are updated successfully.");
		} else {			
			LOGGER.info("Skipping Add Batch Process. Transactions with transaction type 'A' are not available.");
		}

		LOGGER.info("Finishing Add Batch Process... ");
		return RepeatStatus.FINISHED;
	}

}
