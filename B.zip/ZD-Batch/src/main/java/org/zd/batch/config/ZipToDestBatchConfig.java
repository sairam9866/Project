package org.zd.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.zd.batch.tasklet.IseriesDataReaderTasklet;
import org.zd.batch.tasklet.IseriesDataWriterTasklet;
import org.zd.batch.tasklet.ZipToDestAddReadTasklet;
import org.zd.batch.tasklet.ZipToDestAddWriteTasklet;
import org.zd.batch.tasklet.ZipToDestCacheManagerTasklet;
import org.zd.batch.tasklet.ZipToDestDeleteReadTasklet;
import org.zd.batch.tasklet.ZipToDestDeleteWriteTasklet;
import org.zd.batch.tasklet.ZipToDestHasDeltaTasklet;
import org.zd.batch.tasklet.ZipToDestModifyReadTasklet;
import org.zd.batch.tasklet.ZipToDestModifyWriteTasklet;

/**
 * Spring configuration class, which uses <code>@EnableBatchProcessing</code> to enable batch processing features.
 * <p>This class contains bean configurations for <code>Step</code>, <code>Job</code> and <code>Tasklet</code>.</p>
 * <p>For creating <code>Step</code> instance it using <code>StepBuilderFactory</code>.</p>
 * <p>For creating <code>Job</code> instance it using <code>JobBuilderFactory</code>.</p>
 * 
 * @author 3818669
 *
 */
@Configuration
@EnableBatchProcessing
public class ZipToDestBatchConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	ZipToDestAddReadTasklet zipToDestAddReadTasklet;
	
	@Autowired
	ZipToDestAddWriteTasklet zipToDestAddWriteTasklet;
	
	@Autowired
	ZipToDestModifyReadTasklet zipToDestModifyReadTasklet;
	
	@Autowired
	ZipToDestModifyWriteTasklet zipToDestModifyWriteTasklet;
	
	@Autowired
	ZipToDestDeleteReadTasklet zipToDestDeleteReadTasklet;
	
	@Autowired
	ZipToDestDeleteWriteTasklet zipToDestDeleteWriteTasklet;
	
	@Autowired
	ZipToDestCacheManagerTasklet zipToDestCacheManagerTasklet;
	
	@Autowired
	ZipToDestHasDeltaTasklet zipToDestHasDeltaTasklet;
	
	@Autowired
	IseriesDataReaderTasklet iseriesDataReaderTasklet;
	
	@Autowired
	IseriesDataWriterTasklet iseriesDataWriterTasklet;
	
	/**
	 * 
	 * @return
	 */
	@Bean(name = "importTransactionToMaster")
	public Job importTransactionToMaster(){
		return (jobBuilderFactory.get("importTransactionToMaster")
				.incrementer(new RunIdIncrementer())
				.start(zipToDestAddReadStep())		
				.next(zipToDestAddWriteStep())		
				.next(zipToDestModifyReadStep())
				.next(zipToDestModifyWriteStep())
				.next(zipToDestDeleteReadStep())
				.next(zipToDestDeleteWriteStep())
				.next(zipToDestHasDeltaStep())
				.next(zipToDestCacheManagerStep())
				.build());
	}	
	
	@Bean(name = "iseriesDataMigrator")
	public Job iseriesDataMigrator(){
		return (jobBuilderFactory.get("iseriesDataMigrator")
				.incrementer(new RunIdIncrementer())
				.start(iseriesDataReaderStep())
				.next(iseriesDataWriterStep())
				.build());
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestAddReadStep(){
		return stepBuilderFactory.get("zipToDestAddReadStep")				
				.tasklet(zipToDestAddReadTasklet)
				.build();
	}	
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestAddWriteStep(){
		return stepBuilderFactory.get("zipToDestAddWriteStep")
				.tasklet(zipToDestAddWriteTasklet)
				.build();
	}	
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestModifyReadStep(){
		return stepBuilderFactory.get("zipToDestModifyReadStep")				
				.tasklet(zipToDestModifyReadTasklet)
				.build();
	}	
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestModifyWriteStep(){
		return stepBuilderFactory.get("zipToDestModifyWriteStep")
				.tasklet(zipToDestModifyWriteTasklet)
				.build();
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestDeleteReadStep(){
		return stepBuilderFactory.get("zipToDestDeleteReadStep")				
				.tasklet(zipToDestDeleteReadTasklet)
				.build();
	}	
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestDeleteWriteStep(){
		return stepBuilderFactory.get("zipToDestDeleteWriteStep")
				.tasklet(zipToDestDeleteWriteTasklet)
				.build();
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestCacheManagerStep(){
		return stepBuilderFactory.get("zipToDestCacheManagerStep")
				.tasklet(zipToDestCacheManagerTasklet)
				.build();
	}	
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestHasDeltaStep(){
		return stepBuilderFactory.get("zipToDestHasDeltaStep")
				.tasklet(zipToDestHasDeltaTasklet)
				.build();
	}
	
	public Step iseriesDataReaderStep(){
		return stepBuilderFactory.get("iseriesDataReaderStep")
				.tasklet(iseriesDataReaderTasklet).build();
	}
	
	public Step iseriesDataWriterStep(){
		return stepBuilderFactory.get("iseriesDataWriterStep")
				.tasklet(iseriesDataWriterTasklet).build();
	}
	
}

