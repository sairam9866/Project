package org.zd.batch.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.zd.batch.service.WriteProcess;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * The Tasklet implementation class for inserting not processed transactions
 * which are deleted into Facility and ZipToDest master table.
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestDeleteWriteTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestDeleteWriteTasklet.class);

	@Autowired
	WriteProcess writeProcess;

	/**
	 * The Tasklet::execute method implementation contains the business logic
	 * for inserting the not processed transactions which are deleted into
	 * Facility and ZiptoDest master table.
	 * 
	 * <pre>
	 * Modify Batch Process Flow:
	 * 1. Getting not processed transaction with transaction type as 'D' from ExecutionContext.
	 * 2. Getting Zip code range association from Facility table and need to update each facility's transaction type as 'D'(Deleted).
	 * 3. Adding the deleted transactions into Facility master table with transaction type as 'A' and updating its effective time stamp to current UTC time.
	 * 4. Physically deleting older zip code association from zip to destination master table.	 * 
	 * 5. Getting older transactions from transaction table and updating the current flag of each transaction to 'N'.
	 * 6. Updating the deleted transactions current flag to 'N'.
	 * </pre>
	 * 
	 * <p>
	 * Implementations return {@link RepeatStatus#FINISHED} if finished. If not
	 * they return {@link RepeatStatus#CONTINUABLE}. On failure throws an
	 * exception.
	 * </p>
	 * 
	 * @param contribution
	 *            mutable state to be passed back to update the current step
	 *            execution
	 * @param chunkContext
	 *            attributes shared between invocations but not between restarts
	 * @return an {@link RepeatStatus} indicating whether processing is
	 *         continuable. Returning {@code null} is interpreted as
	 *         {@link RepeatStatus#FINISHED}
	 *
	 * @throws Exception
	 *             thrown if error occurs during execution.
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Starting Delete Batch Process... ");
		writeProcess.executeWriteProcess(ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext),
				ZipToDestBatchUtil.TRANSACTION_TYPE_DELETE, ZipToDestBatchUtil.KEY_UNPROCESSED_DELETED);

		LOGGER.info("Finishing Delete Batch Process... ");
		return RepeatStatus.FINISHED;
	}

}
