package org.zd.batch.repository.redis;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.ZipToDest;

@Repository("zipToDestRedisRepository")
public interface ZipToDestRedisRepository extends CrudRepository<ZipToDest, String> {

	public List<ZipToDest> findByProcessedAndCurrentAndCancelledFlagAndTransactionType(String processed, String current, String cancelledFlag, String transctionType);
	
	public List<ZipToDest> findByNetworkAndZipCodeAndProcessed(String network, String zipCode, String processed);
}
