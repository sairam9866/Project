package org.zd.batch.repository.redis;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.StateProvince;

@Repository("stateProvinceRedisRepository")
public interface StateProvinceRedisRepository extends CrudRepository<StateProvince, Long> {
}
