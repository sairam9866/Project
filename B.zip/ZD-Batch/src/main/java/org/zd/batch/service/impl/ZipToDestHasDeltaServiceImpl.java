package org.zd.batch.service.impl;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.repository.ZipToDestHasDeltaRepository;
import org.zd.batch.service.ZipToDestHasDeltaService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * 
 * @author 3818669
 *
 */
@Service
public class ZipToDestHasDeltaServiceImpl implements ZipToDestHasDeltaService {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestHasDeltaServiceImpl.class);
	
	@Autowired
	private ZipToDestHasDeltaRepository zipToDestHasDeltaRepository;

	@Override
	public int insertOrUpdateZipToDestHasDelta(Set<String> networks, Long effectiveDate) {
		int insertCount = 0;
		LOGGER.info("Processed Time : {}",effectiveDate);
		for(String network : networks){
			LOGGER.info("Has Delta : {}",network);			
			zipToDestHasDeltaRepository.save(ZipToDestBatchUtil.instanceOfZipToDestHasDelta(network, effectiveDate));
			insertCount++;
		}		
		return insertCount;
	}

}
