package org.zd.batch.repository;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.repository.redis.FacilityIdRedisRepository;
import org.zd.batch.util.AppConstants;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * 
 * @author 3818669
 *
 */
@Repository("facilityIdRepository")
public class FacilityDeltaRepository implements FacilityIdRedisRepository{

	public static final Logger LOGGER = LoggerFactory.getLogger(FacilityDeltaRepository.class);
	
	@Autowired
	@Qualifier("facilityIdRedisRepository")
	FacilityIdRedisRepository facilityIdRedisRepository;
	
	@Resource(name = "redisTemplate")
	private ZSetOperations<String, FacilityDelta> sortedFacilitySetOperations;
	
	@SuppressWarnings("unchecked")
	@Override
	public FacilityDelta save(FacilityDelta facilityId) {
		sortedFacilitySetOperations.add(AppConstants.FACILITY_HASH_KEY, facilityId, facilityId.getEffectiveDateTime());
		return facilityIdRedisRepository.save(facilityId);
	}
	
	@Override
	public long count() {		
		return facilityIdRedisRepository.count();
	}

	@Override
	public void delete(FacilityDelta arg0) {
		facilityIdRedisRepository.delete(arg0);
	}

	@Override
	public void deleteAll() {
		facilityIdRedisRepository.deleteAll();
	}

	@Override
	public void deleteAll(Iterable<? extends FacilityDelta> arg0) {
		facilityIdRedisRepository.deleteAll(arg0);
	}

	@Override
	public void deleteById(String arg0) {
		facilityIdRedisRepository.deleteById(arg0);
	}

	@Override
	public boolean existsById(String arg0) {
		return facilityIdRedisRepository.existsById(arg0);
	}

	@Override
	public Iterable<FacilityDelta> findAll() {
		return facilityIdRedisRepository.findAll();
	}

	@Override
	public Iterable<FacilityDelta> findAllById(Iterable<String> arg0) {
		return facilityIdRedisRepository.findAllById(arg0);
	}

	@Override
	public Optional<FacilityDelta> findById(String facilityId) {
		return facilityIdRedisRepository.findById(facilityId);
	}	

	@Override
	public <S extends FacilityDelta> Iterable<S> saveAll(Iterable<S> arg0) {
		return facilityIdRedisRepository.saveAll(arg0);
	}

	@Override
	public List<FacilityDelta> findByNetworkAndZipCodeAndTransactionType(String network, String zipCode,
			String transactionType) {
		return facilityIdRedisRepository.findByNetworkAndZipCodeAndTransactionType(network, zipCode, transactionType);
	}
	
	//@Query("select f from FacilityId f where f.facilityIdPK.network = ?1 and f.facilityIdPK.zipCode = ?2 and f.transactionType = 'A'")
	public List<FacilityDelta> findZipcodeRangeByNetwork(String network, String zipCode){
		return findByNetworkAndZipCodeAndTransactionType(network,zipCode, ZipToDestBatchUtil.TRANSACTION_TYPE_ADD);
	}
	
	//@Modifying
	//@Query("update FacilityId f set f.facilityIdPK.effectiveDateTimestamp = ?1, f.transactionType = ?2 "
	//		+ "where f.facilityIdPK = ?3")
	public int updateFacilityTransTypeAndDateByPk(Long effectiveDateTime, String transactionType, String facilityId){
		FacilityDelta updatedFacility = null;
		String oldKey = "";
		Long oldTimestamp = null;
		
		Optional<FacilityDelta> facilityDelta = findById(facilityId);		
		if(facilityDelta.isPresent()){
			
			FacilityDelta facility = facilityDelta.get();
			oldKey = facility.getId();		
			oldTimestamp = facility.getEffectiveDateTime();
			
			deleteById(oldKey);
			FacilityDelta oldFacilityDelta = new FacilityDelta();			
			oldFacilityDelta.setFacilityId(facility.getFacilityId());
			oldFacilityDelta.setNetwork(facility.getNetwork());
			oldFacilityDelta.setState(facility.getState());
			oldFacilityDelta.setTransactionType(transactionType);
			oldFacilityDelta.setEffectiveDateTime(effectiveDateTime);
			oldFacilityDelta.setUuId(facility.getUuId());
			oldFacilityDelta.setZipCode(facility.getZipCode());
			oldFacilityDelta.buildKey();			
			
			LOGGER.info("Facility : {}",facility);
			LOGGER.info("Facility Old Key : {}",oldKey);
			LOGGER.info("Facility Old Effective Date : {}",oldTimestamp);
			
			LOGGER.info("Facility New Key : {}",oldFacilityDelta.getId());
			LOGGER.info("Facility New Effective Date : {}",oldFacilityDelta.getEffectiveDateTime());
			updatedFacility = save(oldFacilityDelta);
			long rmCount = sortedFacilitySetOperations.remove(AppConstants.FACILITY_HASH_KEY, facility);
			LOGGER.info("Removed {} Older Facility records from ZSet Facility data structure.",rmCount);			
			deleteById(oldKey);
			LOGGER.info("Older Facility  records {} removed from hash.",oldKey);

		}
		return (updatedFacility != null ? 1 : 0);
	}
}
