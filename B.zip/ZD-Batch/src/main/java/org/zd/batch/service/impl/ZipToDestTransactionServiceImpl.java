package org.zd.batch.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.repository.ZipToDestTransactionRepository;
import org.zd.batch.service.ZipToDestTransactionService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * The implementation class for ZipToDestTransactionService.
 * 
 * @author 3818669
 *
 */
@Service
public class ZipToDestTransactionServiceImpl implements ZipToDestTransactionService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestTransactionServiceImpl.class);

	@Autowired
	ZipToDestTransactionRepository zipToDestRepository;

	/**
	 * The ZipToDestTransactionService::findUnProcessedTransactionByType
	 * implementation will return a list of ZipToDest objects.
	 * 
	 * Which are not yet processed and cancelled with the transaction type
	 * 'A',M' or 'D' and effective date up to current UTC time.
	 * 
	 * @param utcTime
	 *            - current UTC Timestamp.
	 * @param type
	 *            - transaction type.
	 * 
	 * @return List of ZipToDest which are not yet processed.
	 */
	@Override
	public List<ZipToDest> findUnProcessedTransactionByType(Long utcTime, String type) {
		LOGGER.debug("ZipToDestTransactionServiceImpl::findUnProcessedTransactionByType -> Current UTC time : {}.",
				utcTime);
		LOGGER.debug("ZipToDestTransactionServiceImpl::findUnProcessedTransactionByType -> Transaction Type : {}.",
				type);
		return zipToDestRepository.findUnProcessedTransactionByType(utcTime, type);
	}

	/**
	 * The ZipToDestTransactionService::findOlderTransactions implementation
	 * will return a list of older transactions.
	 * 
	 * @param network
	 *            - network code of transaction.
	 * @param zipCode
	 *            - zipcode of transaction.
	 * 
	 * @return List of ZipToDest.
	 */
	@Override
	public List<ZipToDest> findOlderTransactions(String network, String zipCode) {
		return zipToDestRepository.findOlderTransactions(network, zipCode, ZipToDestBatchUtil.getCurrentUtcEpochTime());
	}

	/**
	 * The ZipToDestTransactionService::updateNotProcessedTransactions
	 * implementation updates the transactions processed and current flag based
	 * of the value of parameter step.
	 * 
	 * If the step execution is of ADD flow then the processed and current flag
	 * of transaction is updated with 'Y'. If the step execution is of MODIFY
	 * flow then the current flag of transaction is updated with 'Y'. If the
	 * step execution is of DELETE flow then the current flag of transaction is
	 * updated with 'N'.
	 * 
	 * @param zipToDests
	 *            - list of ZipToDest.
	 * @param step
	 *            - character value to identify the step execution.
	 */
	@Override
	public void updateNotProcessedTransactions(List<ZipToDest> zipToDests, Long processedAt, String step) {
		LOGGER.info("Updating transactions processed and current flag...");
		LOGGER.debug("Updating processed and current flag of {} transactions.", zipToDests.size());
		for (ZipToDest zipToDest : zipToDests) {
			LOGGER.debug("Updating transaction : {}", zipToDest);
			zipToDest.setProcessed(ZipToDestBatchUtil.FLAG_YES);
			zipToDest.setCurrent(ZipToDestBatchUtil.FLAG_YES);
			zipToDest.setProcessedDateTime(processedAt);
			if (ZipToDestBatchUtil.TRANSACTION_TYPE_DELETE.equals(step)) {				
				zipToDest.setCurrent(ZipToDestBatchUtil.FLAG_NO);
			}
			zipToDestRepository.save(zipToDest);
		}
		LOGGER.info("Transactions processed and current flag are updated.");
	}

	/**
	 * The ZipToDestTransactionService::updateOlderTransactions implementation
	 * updates the current flag of older transactions to 'N'.
	 * 
	 * @param zipToDests
	 *            list of transaction.
	 */
	@Override
	public void updateOlderTransactions(List<ZipToDest> zipToDests, Long processedAt) {
		LOGGER.info("Updating older transactions current flag...");
		LOGGER.debug("Updating processed and current flag of {} transactions.", zipToDests.size());
		for (ZipToDest oldZipToDest : zipToDests) {
			LOGGER.debug("Updating Older transaction -> {}", oldZipToDest);
			oldZipToDest.setCurrent(ZipToDestBatchUtil.FLAG_NO);
			oldZipToDest.setProcessedDateTime(processedAt);
			zipToDestRepository.save(oldZipToDest);
		}
		LOGGER.info("Older transactions current flag updated.");

	}
}
