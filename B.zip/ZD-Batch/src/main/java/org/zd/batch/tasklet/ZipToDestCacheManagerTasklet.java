package org.zd.batch.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestCacheManagerTasklet implements Tasklet {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestCacheManagerTasklet.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Environment environment;

	/**
	 * 
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Satrting Clear Cache step...");
		int instanceCount;
		String cacheEndPoint;		
		String instanceName;
		String instanceGuid;
		String apiKey;
		
		HttpHeaders header;
		HttpEntity<String> httpEntity;		
		
		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);

		int executionCount = context.getInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT);
		LOGGER.info("Satrting Clear Cache step...");
		LOGGER.debug("Execution Count : {}", executionCount);
		
		if (executionCount > 0) {
			
			cacheEndPoint = environment.getProperty(ZipToDestBatchUtil.ZD_DISTRIBUTION_CACHE_URL);
			
			instanceCount = Integer
					.parseInt(environment.getProperty(ZipToDestBatchUtil.ZD_DISTRIBUTION_INSTANCE_COUNT));
			
			instanceName = environment.getProperty(ZipToDestBatchUtil.ZD_DISTRIBUTION_APP_INSTANCE);
			
			instanceGuid = environment.getProperty(ZipToDestBatchUtil.ZD_DISTRIBUTION_GUID);
			
			apiKey = environment.getProperty(ZipToDestBatchUtil.ZD_DISTRIBUTION_CACHE_KEY);	
			
			LOGGER.debug("cacheEndPoint : {}", cacheEndPoint);
			LOGGER.debug("instanceCount : {}", instanceCount);
			LOGGER.debug("instanceName : {}", instanceName);
			LOGGER.debug("instanceGuid : {}", instanceGuid);
			LOGGER.debug("apiKey : {}", apiKey);

			for (int instanceIndex = 0; instanceIndex < instanceCount; instanceIndex++) {
				
				header = new HttpHeaders();
				header.set("apiKey", apiKey);
				header.set(instanceName, instanceGuid + ":" + instanceIndex);

				httpEntity = new HttpEntity<>(header);

				restTemplate.exchange(cacheEndPoint, HttpMethod.GET, httpEntity, Void.class);
			}
		}
		LOGGER.info("Clear Cache step finished...");
		return RepeatStatus.FINISHED;
	}

}
