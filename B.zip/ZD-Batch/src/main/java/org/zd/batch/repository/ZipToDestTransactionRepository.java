package org.zd.batch.repository;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.repository.redis.ZipToDestRedisRepository;
import org.zd.batch.util.AppConstants;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * 
 * @author 3818669
 *
 */
@Repository("zipToDestTransactionRepository")
public class ZipToDestTransactionRepository implements ZipToDestRedisRepository {

	@Autowired
	ZipToDestRedisRepository zipToDestRedisRepository;
	
	@Autowired
	private RedisTemplate<String, String> redisStringTemplate;

	@Autowired
	private RedisTemplate<String, Long> redisLongTemplate;	

	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDest> zSetOperations;
	
	@Resource(name = "redisTemplate")
	private ZSetOperations<String, ZipToDest> zSetProcessedOperations;

	private ZSetOperations<String, String> zipSetOperations;
	private ZSetOperations<String, Long> zipSetProcessedDateOperations;

	@PostConstruct
	public void init() {
		zipSetOperations = redisStringTemplate.opsForZSet();
		zipSetProcessedDateOperations = redisLongTemplate.opsForZSet();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ZipToDest save(ZipToDest zipToDest) {
		zSetOperations.add(AppConstants.APP_TRANSACTION_TMSTMP_KEY, zipToDest, zipToDest.getEffectiveDateAt());

		zipSetOperations.add(AppConstants.APP_TRANSACTION_ZIP_KEY, zipToDest.getZipCode(),
				AppConstants.ZIP_CODE_DEFAULT_SCORE);

		if (zipToDest.getProcessedDateTime() != null) {
			zipSetProcessedDateOperations.add(AppConstants.APP_TRANSACTION_PROCESS_TMSTAMP_KEY,
					zipToDest.getProcessedDateTime(), 2);
			zSetProcessedOperations.add(AppConstants.APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY, zipToDest,
					zipToDest.getProcessedDateTime());
		}
		
		return zipToDestRedisRepository.save(zipToDest);
	}

	@Override
	public long count() {
		return zipToDestRedisRepository.count();
	}

	@Override
	public void delete(ZipToDest arg0) {
		zipToDestRedisRepository.delete(arg0);
	}

	@Override
	public void deleteAll() {
		zipToDestRedisRepository.deleteAll();
	}

	@Override
	public void deleteAll(Iterable<? extends ZipToDest> arg0) {
		zipToDestRedisRepository.deleteAll(arg0);
	}

	@Override
	public void deleteById(String arg0) {
		zipToDestRedisRepository.deleteById(arg0);
	}

	@Override
	public boolean existsById(String arg0) {
		return zipToDestRedisRepository.existsById(arg0);
	}

	@Override
	public Iterable<ZipToDest> findAll() {
		return zipToDestRedisRepository.findAll();
	}

	@Override
	public Iterable<ZipToDest> findAllById(Iterable<String> arg0) {
		return zipToDestRedisRepository.findAllById(arg0);
	}

	@Override
	public Optional<ZipToDest> findById(String arg0) {
		return zipToDestRedisRepository.findById(arg0);
	}

	

	@Override
	public <S extends ZipToDest> Iterable<S> saveAll(Iterable<S> arg0) {
		return zipToDestRedisRepository.saveAll(arg0);
	}

	// @Query("select d from ZipToDest d where d.processed = 'N' and d.current =
	// 'N' and d.transactionType = ?2 and d.cancelledFlag = 'N' and
	// d.effectiveDate <= ?1 order by d.uuid,d.zipCode asc")
	public List<ZipToDest> findUnProcessedTransactionByType(Long currentTimestamp, String transactionType) {
		List<ZipToDest> output = Collections.emptyList();
		List<ZipToDest> unprocessedTransactions = findByProcessedAndCurrentAndCancelledFlagAndTransactionType(ZipToDestBatchUtil.FLAG_NO, ZipToDestBatchUtil.FLAG_NO,
				ZipToDestBatchUtil.FLAG_NO, transactionType);
		if (!unprocessedTransactions.isEmpty()) {
			output = unprocessedTransactions.stream().filter(trans -> trans.getEffectiveDateAt() <= currentTimestamp)
					.collect(Collectors.toList());
		}
		return output;
	}

	// @Query("select d from ZipToDest d where d.network = ?1 and d.zipCode = ?2
	// and d.current = 'Y' and d.effectiveDate <= ?3 order by d.uuid,d.zipCode
	// asc")
	public List<ZipToDest> findOlderTransactions(String network, String zipCode, Long currentUtcTime) {
		List<ZipToDest> output = Collections.emptyList();
		List<ZipToDest> olderTransactions = (List<ZipToDest>) findByNetworkAndZipCodeAndProcessed(network, zipCode, ZipToDestBatchUtil.FLAG_YES);
		if(!olderTransactions.isEmpty()){
			output = olderTransactions.stream().filter(trans -> trans.getEffectiveDateAt() <= currentUtcTime)
					.collect(Collectors.toList());
		}
		return output;
	}

	@Override
	public List<ZipToDest> findByProcessedAndCurrentAndCancelledFlagAndTransactionType(String processed, String current,
			String cancelledFlag, String transctionType) {
		return zipToDestRedisRepository.findByProcessedAndCurrentAndCancelledFlagAndTransactionType(processed, current,
				cancelledFlag, transctionType);
	}
	
	@Override
	public List<ZipToDest> findByNetworkAndZipCodeAndProcessed(String network, String zipCode, String processed){
		return zipToDestRedisRepository.findByNetworkAndZipCodeAndProcessed(network, zipCode, processed);
	}
}
