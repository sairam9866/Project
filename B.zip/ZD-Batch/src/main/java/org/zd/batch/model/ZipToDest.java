package org.zd.batch.model;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

@RedisHash("{ZdTransaction}")
public class ZipToDest {

	@Id
	private String id;

	@Indexed
	private String network;

	private int countryCode;

	@Indexed
	private String zipCode;

	private String state;

	private String destinationTerminal;

	private String creationUser;

	@JsonIgnore
	private Long createdDateAt;

	@Indexed
	@JsonIgnore
	private Long effectiveDateAt;

	@Indexed
	private String transactionType;

	@Indexed
	private String processed;

	@Indexed
	private String current;

	@Indexed
	private String uuid;

	@Indexed
	private String cancelledUser;

	@Indexed
	@JsonIgnore
	private Long cancelledTimestamp;

	@Indexed
	private String cancelledFlag;

	@Indexed
	@JsonIgnore
	private Long processedDateTime;

	@Transient
	@JsonInclude(Include.NON_DEFAULT)
	private String zipFrom;

	@Transient
	@JsonInclude(Include.NON_DEFAULT)
	private String zipTo;

	@Transient
	@JsonInclude(Include.NON_DEFAULT)
	private String timeZone;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private transient LocalDateTime effectiveDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private LocalDateTime creationDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private transient LocalDateTime processedAt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd.HH:mm:ss")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@Transient
	private transient LocalDateTime cancelledAt;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDestinationTerminal() {
		return destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	public String getCreationUser() {
		return creationUser;
	}

	public void setCreationUser(String creationUser) {
		this.creationUser = creationUser;
	}

	public Long getCreatedDateAt() {
		return createdDateAt;
	}

	public void setCreatedDateAt(Long createdDateAt) {
		this.createdDateAt = createdDateAt;
	}	

	public Long getCancelledTimestamp() {
		return cancelledTimestamp;
	}

	public Long getEffectiveDateAt() {
		return effectiveDateAt;
	}

	public void setEffectiveDateAt(Long effectiveDateAt) {
		this.effectiveDateAt = effectiveDateAt;
	}

	public void setCancelledTimestamp(Long cancelledTimestamp) {
		this.cancelledTimestamp = cancelledTimestamp;
	}

	public Long getProcessedDateTime() {
		return processedDateTime;
	}

	public void setProcessedDateTime(Long processedDateTime) {
		this.processedDateTime = processedDateTime;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getProcessed() {
		return processed;
	}

	public void setProcessed(String processed) {
		this.processed = processed;
	}

	public String getCurrent() {
		return current;
	}

	public void setCurrent(String current) {
		this.current = current;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCancelledUser() {
		return cancelledUser;
	}

	public void setCancelledUser(String cancelledUser) {
		this.cancelledUser = cancelledUser;
	}

	public String getCancelledFlag() {
		return cancelledFlag;
	}

	public void setCancelledFlag(String cancelledFlag) {
		this.cancelledFlag = cancelledFlag;
	}

	public String getZipFrom() {
		return zipFrom;
	}

	public void setZipFrom(String zipFrom) {
		this.zipFrom = zipFrom;
	}

	public String getZipTo() {
		return zipTo;
	}

	public void setZipTo(String zipTo) {
		this.zipTo = zipTo;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public LocalDateTime getCreationDate() {
		if (createdDateAt != null) {
			creationDate = LocalDateTime.ofEpochSecond(createdDateAt, 0, ZoneOffset.UTC);
		}
		return creationDate;
	}

	public LocalDateTime getEffectiveDate() {
		if (effectiveDateAt != null) {
			effectiveDate = LocalDateTime.ofEpochSecond(effectiveDateAt, 0, ZoneOffset.UTC);
		}
		return effectiveDate;
	}

	public LocalDateTime getProcessedAt() {
		if (processedDateTime != null) {
			processedAt = LocalDateTime.ofEpochSecond(processedDateTime, 0, ZoneOffset.UTC);
		}
		return processedAt;
	}

	public LocalDateTime getCancelledAt() {
		if (cancelledTimestamp != null) {
			cancelledAt = LocalDateTime.ofEpochSecond(cancelledTimestamp, 0, ZoneOffset.UTC);
		}
		return cancelledAt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass()) {
			return false;
		}
		ZipToDest other = (ZipToDest) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public void buildKey() {
		setId(this.network + this.zipCode + this.destinationTerminal + this.createdDateAt);
	}

	@Override
	public String toString() {
		return "ZipToDest [id=" + id + ", network=" + network + ", countryCode=" + countryCode + ", zipCode=" + zipCode
				+ ", state=" + state + ", destinationTerminal=" + destinationTerminal + ", creationUser=" + creationUser
				+ ", createdDateAt=" + createdDateAt + ", effectiveDateAt=" + effectiveDateAt + ", transactionType="
				+ transactionType + ", processed=" + processed + ", current=" + current + ", uuid=" + uuid
				+ ", cancelledUser=" + cancelledUser + ", cancelledTimestamp=" + cancelledTimestamp + ", cancelledFlag="
				+ cancelledFlag + ", processedDateTime=" + processedDateTime + ", zipFrom=" + zipFrom + ", zipTo="
				+ zipTo + ", timeZone=" + timeZone + ", creationDate=" + creationDate + "]";
	}

}
