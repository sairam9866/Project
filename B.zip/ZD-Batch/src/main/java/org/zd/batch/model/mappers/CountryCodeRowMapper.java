package org.zd.batch.model.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.zd.batch.model.CountryCode;

public class CountryCodeRowMapper implements RowMapper<CountryCode>{

	@Override
	public CountryCode mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		CountryCode countryCode = new CountryCode();
		countryCode.setCyclcu(resultSet.getInt("CYCLCU"));
		countryCode.setCycode(StringUtils.trim(resultSet.getString("CYCODE")));
		return countryCode;
	}

}
