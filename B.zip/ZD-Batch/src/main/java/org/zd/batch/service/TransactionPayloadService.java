package org.zd.batch.service;

public interface TransactionPayloadService {
	public void init();
}
