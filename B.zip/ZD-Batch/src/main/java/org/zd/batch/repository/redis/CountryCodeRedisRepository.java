package org.zd.batch.repository.redis;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.CountryCode;

@Repository("countryCodeRedisRepository")
public interface CountryCodeRedisRepository extends CrudRepository<CountryCode, Long> {

}
