package org.zd.batch.tasklet;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.ZipToDestHasDeltaService;
import org.zd.batch.util.ZipToDestBatchUtil;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestHasDeltaTasklet implements Tasklet {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestHasDeltaTasklet.class);

	@Autowired
	ZipToDestHasDeltaService zipToDestHasDeltaService;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		ExecutionContext context = ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext);

		@SuppressWarnings("unchecked")
		List<ZipToDest> zipToDestListAdded = (List<ZipToDest>) context.get(ZipToDestBatchUtil.KEY_UNPROCESSED_ADDED);

		@SuppressWarnings("unchecked")
		List<ZipToDest> zipToDestListModified = (List<ZipToDest>) context
				.get(ZipToDestBatchUtil.KEY_UNPROCESSED_MODIFIED);

		@SuppressWarnings("unchecked")
		List<ZipToDest> zipToDestListDeleted = (List<ZipToDest>) context
				.get(ZipToDestBatchUtil.KEY_UNPROCESSED_DELETED);

		Long jobDateTime = (Long) context.get(ZipToDestBatchUtil.KEY_JOB_START_TIME);

		Set<String> networks = new HashSet<>();
		
		LOGGER.info("JOB START TIME : {}", jobDateTime);
		LOGGER.info("Added Not Processed Count : {}",zipToDestListAdded.size());
		LOGGER.info("Modified Not Processed Count : {}",zipToDestListModified.size());
		LOGGER.info("Deleted Not Processed Count : {}",zipToDestListDeleted.size());
		if (!zipToDestListAdded.isEmpty()) {
			networks.addAll(zipToDestListAdded.stream().map(ZipToDest::getNetwork).collect(Collectors.toSet()));
		}

		if (!zipToDestListModified.isEmpty()) {
			networks.addAll(zipToDestListModified.stream().map(ZipToDest::getNetwork).collect(Collectors.toSet()));
		}

		if (!zipToDestListDeleted.isEmpty()) {
			networks.addAll(zipToDestListDeleted.stream().map(ZipToDest::getNetwork).collect(Collectors.toSet()));
		}		
		
		LOGGER.info("Number of Networks available for add or update in has delta table : {}", networks.size());
		if(!networks.isEmpty()){
			zipToDestHasDeltaService.insertOrUpdateZipToDestHasDelta(networks, jobDateTime);
		}
		LOGGER.info("Has Delta Table Updation finished.");
		return RepeatStatus.FINISHED;
	}

}
