package org.zd.batch.repository;

import java.util.Optional;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;
import org.zd.batch.model.Network;
import org.zd.batch.repository.redis.NetworkRedisRepository;
import org.zd.batch.util.AppConstants;

@Repository("networkRepository")
public class NetworkRepository implements NetworkRedisRepository {

	@Autowired
	@Qualifier("networkRedisRepository")
	NetworkRedisRepository networkRedisRepository;

	@Resource(name = "redisTemplate")
	private ZSetOperations<String, String> networkSetOperations;

	@SuppressWarnings("unchecked")
	@Override
	public Network save(Network network) {
		networkSetOperations.add(AppConstants.HASH_KEY_NETWORK, network.getNetworkId(), network.getTermNum());
		return networkRedisRepository.save(network);
	}	

	@Override
	public <S extends Network> Iterable<S> saveAll(Iterable<S> entities) {
		return networkRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<Network> findById(Long id) {
		return networkRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(Long id) {
		return networkRedisRepository.existsById(id);
	}

	@Override
	public Iterable<Network> findAll() {
		return networkRedisRepository.findAll();
	}

	@Override
	public Iterable<Network> findAllById(Iterable<Long> ids) {
		return networkRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return networkRedisRepository.count();
	}

	@Override
	public void deleteById(Long id) {
		networkRedisRepository.deleteById(id);
	}

	@Override
	public void delete(Network entity) {
		networkRedisRepository.delete(entity);
	}

	@Override
	public void deleteAll(Iterable<? extends Network> entities) {
		networkRedisRepository.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		networkRedisRepository.deleteAll();
	}

}
