package org.zd.batch.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.FacilityIdService;
import org.zd.batch.service.WriteProcess;
import org.zd.batch.service.ZipToDestTransactionService;
import org.zd.batch.service.ZipToDestinationService;
import org.zd.batch.util.ZipToDestBatchUtil;

@Service
public class WriteProcessImpl implements WriteProcess{
	
	public static final Logger LOGGER = LoggerFactory.getLogger(WriteProcessImpl.class);
	
	@Autowired
	FacilityIdService facilityIdService;

	@Autowired
	ZipToDestinationService zipToDestinationService;

	@Autowired
	private ZipToDestTransactionService zipToDestTransactionService;

	@Override
	public int executeWriteProcess(ExecutionContext context, String transactionType, String keyUnprocessedType) {
		List<FacilityDelta> oldFacilities = null;
		List<ZipToDest> olderTransactions;
		String zipCode;
		int commitCount = 0;

		@SuppressWarnings("unchecked")
		List<ZipToDest> zipToDestList = (List<ZipToDest>) context.get(keyUnprocessedType);
		
		int executionCount = 0;
		if (!context.containsKey(ZipToDestBatchUtil.KEY_EXECUTION_COUNT)) {
			context.putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, executionCount);
		}
		
		if (!zipToDestList.isEmpty()) {
			
			Long jobDateTime = (Long) context.get(ZipToDestBatchUtil.KEY_JOB_START_TIME);

			context.putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, zipToDestList.size() + context.getInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT));

			LOGGER.debug("{} Not processed transactions with type 'M' found for batch processing.",
					zipToDestList.size());

			LOGGER.info("Reading and updating transaction type of older Facilty zip code range associations.");
			for (ZipToDest zipToDest : zipToDestList) {
				
				zipCode = ZipToDestBatchUtil.getActualZipcode(zipToDest.getZipCode());				
			
				oldFacilities = facilityIdService.findZipcodeRangeByNetwork(zipToDest.getNetwork(), zipCode);

				LOGGER.info("{} Older Zip code association found for netweork - {} and Zipcode - {} in Facility.",
						oldFacilities.size(), zipToDest.getNetwork(), zipToDest.getZipCode());
				facilityIdService.deleteZipToDestFacility(oldFacilities, jobDateTime);
			}

			LOGGER.info("Inserting modified zip code associations into Facility...");
			
			facilityIdService.addZipToDestFacility(zipToDestList, jobDateTime);
			
			LOGGER.info("Finished insertion of modified zip code associations into Facility.");

			LOGGER.info("Physically deleting older zip code associations from Zip to destination master table...");
			
			zipToDestinationService.deleteZipToDestination(zipToDestList);

			LOGGER.info("Inserting modified transactions into Zip to destination master table");
			
			if(ZipToDestBatchUtil.TRANSACTION_TYPE_MODIFY == transactionType){
				zipToDestinationService.addZipToDestination(zipToDestList, jobDateTime);
			}
			
			
			LOGGER.info("Getting older transactions from Transaction table and updating its current flag to 'N'...");
			for (ZipToDest zipToDest : zipToDestList) {
				olderTransactions = zipToDestTransactionService.findOlderTransactions(zipToDest.getNetwork(),
						zipToDest.getZipCode());

				LOGGER.info(
						"{} Older Zip code association found for netweork - {} and Zipcode - {} in Transaction table.",
						olderTransactions.size(), zipToDest.getNetwork(), zipToDest.getZipCode());
				zipToDestTransactionService.updateOlderTransactions(olderTransactions, jobDateTime);
				commitCount++;
			}

			LOGGER.info("Updating modified transactions current flag to 'Y'...");
			zipToDestTransactionService.updateNotProcessedTransactions(zipToDestList, jobDateTime, transactionType);
			
		}else{
			LOGGER.info("Not Processed transactiona not availabel for processing.");
		}
		return commitCount;
	}

}
