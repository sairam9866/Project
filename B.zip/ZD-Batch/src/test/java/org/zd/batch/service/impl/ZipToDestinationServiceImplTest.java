package org.zd.batch.service.impl;

import static org.junit.Assert.assertNotNull;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.repository.ZipToDestinationRepository;

@RunWith(SpringRunner.class)
public class ZipToDestinationServiceImplTest {

	@InjectMocks
	private ZipToDestinationServiceImpl zipToDestinationService;

	@Mock
	ZipToDestinationRepository zipToDestinationRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testAddZipToDestination(){
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);
		
		zipToDestinationService.addZipToDestination(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		assertNotNull(zipToDest);
	}
	
	@Test
	public void testDeleteZipToDestination(){
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);
		
		zipToDestinationService.deleteZipToDestination(transactions);
		assertNotNull(zipToDest);
	}
}
