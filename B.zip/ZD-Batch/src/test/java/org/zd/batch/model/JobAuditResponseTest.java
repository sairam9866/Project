package org.zd.batch.model;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class JobAuditResponseTest {

	JobAuditResponse jobAuditResponse;
	
	@Before
	public void init(){
		Date date = new Date();
		jobAuditResponse = new JobAuditResponse();
		jobAuditResponse.setStartTime(date);
		jobAuditResponse.setCreateTime(date);
		jobAuditResponse.setEndTime(date);
		jobAuditResponse.setExitMessage("Completed");
		jobAuditResponse.setLastUpdated(date);
		jobAuditResponse.setStackTrace(null);
		jobAuditResponse.setStatus("Finished");
	}
	
	@Test
	public void testJobAuditResponse(){
		assertNotNull(jobAuditResponse.getCreateTime());
		assertNotNull(jobAuditResponse.getEndTime());
		assertNotNull(jobAuditResponse.getExitMessage());
		assertNotNull(jobAuditResponse.getLastUpdated());
		assertNotNull(jobAuditResponse.getStartTime());
		assertNotNull(jobAuditResponse.getStatus());
		assertNull(jobAuditResponse.getStackTrace());
		assertNotNull(jobAuditResponse.toString());
	}
}
