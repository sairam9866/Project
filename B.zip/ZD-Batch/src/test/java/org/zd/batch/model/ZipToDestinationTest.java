package org.zd.batch.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;

public class ZipToDestinationTest {
	ZipToDestination zipToDestination;	
	@Before
	public void init(){
		zipToDestination = new ZipToDestination();
		zipToDestination.setCountryCode(840);
		zipToDestination.setNetwork("FXGL");
		zipToDestination.setZipCode("A0A0A0");
		zipToDestination.setDestination("11");
		zipToDestination.setLastUpdateBy("USER1");
		zipToDestination.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestination.setState("WA");
		zipToDestination.buildKey();
	}
	
	@Test
	public void testZipToDestination(){
		assertNotNull(zipToDestination.getCountryCode());
		assertNotNull(zipToDestination.getNetwork());
		assertNotNull(zipToDestination.getZipCode());
		assertNotNull(zipToDestination.getDestination());
		assertNotNull(zipToDestination.getState());		
		assertNotNull(zipToDestination.getLastUpdateBy());		
		assertNotNull(zipToDestination.getLastUpdateTimestamp());
		assertNotNull(zipToDestination.toString());
	}
	
	@Test
	public void testHashCode(){
		assertThat(zipToDestination.hashCode() > 0);
		zipToDestination.setId(null);
		assertThat(zipToDestination.hashCode() > 0);
	}
	
	@Test
	public void testEquals(){
		ZipToDestination zipToDestination = new ZipToDestination();
		zipToDestination.setCountryCode(840);
		zipToDestination.setNetwork("FXGL");
		zipToDestination.setZipCode("A0A0A0");
		zipToDestination.setDestination("11");
		zipToDestination.setLastUpdateBy("USER1");
		zipToDestination.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestination.setState("WA");
		zipToDestination.buildKey();
		
		assertTrue(zipToDestination.equals(zipToDestination));
		ZipToDestination zipToDestination2 = null;
		assertFalse(zipToDestination.equals(zipToDestination2));
		assertFalse(zipToDestination.equals(new Object()));
		zipToDestination2 = new ZipToDestination();
		zipToDestination.setId(null);
		zipToDestination2.setId(null);
		assertTrue(zipToDestination.equals(zipToDestination2));
		zipToDestination2.setId("");
		assertFalse(zipToDestination.equals(zipToDestination2));
		zipToDestination.buildKey();
		assertFalse(zipToDestination.equals(zipToDestination2));
		zipToDestination2.setId(zipToDestination.getId());
		assertTrue(zipToDestination.equals(zipToDestination2));
		
	}
}
