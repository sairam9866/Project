package org.zd.batch.config;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class IseriesJdbcTemplateTest {

	@InjectMocks
	IseriesJdbcTemplate iseriesJdbcTemplate;

	@Mock
	Environment environment;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testJdbcTemplate() {		
		iseriesJdbcTemplate.getJdbcTemplate();
	}

	@Test
	public void testInit() {
		when(environment.getProperty("iseries.datasource.driver-class-name")).thenReturn("com.ibm.as400.access.AS400JDBCDriver");
		when(environment.getProperty("iseries.datasource.password")).thenReturn("g76En4vLH7cr4PfpEUTW4VGpe");
		when(environment.getProperty("iseries.datasource.username")).thenReturn("LPI_APP");
		when(environment.getProperty("iseries.datasource.jdbc-url")).thenReturn("jdbc:as400://TST1.ground.fedex.com;naming=system;libraries=MSTDTALIB,PT1DTALIB,TBTDTALIB");
		iseriesJdbcTemplate.init();
	}
}
