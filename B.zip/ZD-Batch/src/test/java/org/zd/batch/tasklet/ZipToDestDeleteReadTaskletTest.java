package org.zd.batch.tasklet;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.ZipToDestTransactionService;
import org.zd.batch.util.ZipToDestBatchUtil;

@RunWith(SpringRunner.class)
public class ZipToDestDeleteReadTaskletTest {
	
	@InjectMocks
	private ZipToDestDeleteReadTasklet zipToDestDeleteReadTasklet;
	
	@Mock
	private ZipToDestTransactionService zipToDestTransactionService;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testZipToDestDeleteReadTasklet() throws Exception{
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);

		StepExecution execution = new StepExecution("zipToDestDeleteReadTasklet", jobExecution);
		StepContribution contribution = new StepContribution(execution);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);		
		
		List<ZipToDest> zipToDests = new ArrayList<>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setNetwork("FHDL");
		zipToDests.add(zipToDest);
		
		Mockito.doReturn(zipToDests)
		.when(zipToDestTransactionService)
		.findUnProcessedTransactionByType(ZipToDestBatchUtil.getCurrentUtcEpochTime(),
				ZipToDestBatchUtil.TRANSACTION_TYPE_DELETE);
		
		RepeatStatus status = zipToDestDeleteReadTasklet.execute(contribution, chunkContext);	
		
		assertEquals(RepeatStatus.FINISHED, status);
	}
}
