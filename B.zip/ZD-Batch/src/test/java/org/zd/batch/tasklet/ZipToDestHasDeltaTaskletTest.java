package org.zd.batch.tasklet;

import static org.junit.Assert.assertEquals;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.service.ZipToDestHasDeltaService;
import org.zd.batch.util.ZipToDestBatchUtil;

public class ZipToDestHasDeltaTaskletTest {

	@InjectMocks
	ZipToDestHasDeltaTasklet zipToDestHasDeltaTasklet;
	
	@Mock
	ZipToDestHasDeltaService zipToDestHasDeltaService;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testZipToDestHistoryTasklet() throws Exception{
		
		List<ZipToDest> unprocessedAdd = new ArrayList<>();
		List<ZipToDest> unprocessedModify = new ArrayList<>();
		List<ZipToDest> unprocessedDelete = new ArrayList<>();
		
		ZipToDest zipToDestAdded = new ZipToDest();
		zipToDestAdded.setCountryCode(840);
		zipToDestAdded.setCancelledFlag("N");
		zipToDestAdded.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestAdded.setCreationUser("Test");
		zipToDestAdded.setCurrent("N");
		zipToDestAdded.setDestinationTerminal("11");
		zipToDestAdded.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestAdded.setProcessed("N");
		zipToDestAdded.setNetwork("FHDL");
		zipToDestAdded.setState("WA");
		zipToDestAdded.setTransactionType("A");
		zipToDestAdded.setUuid("asdsadsd-asdsad--adsa");
		zipToDestAdded.setZipCode("50450000000");
		
		ZipToDest zipToDestModified = new ZipToDest();
		zipToDestModified.setCountryCode(840);
		zipToDestModified.setCancelledFlag("N");
		zipToDestModified.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestModified.setCreationUser("Test");
		zipToDestModified.setCurrent("N");
		zipToDestModified.setDestinationTerminal("11");
		zipToDestModified.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestModified.setProcessed("N");
		zipToDestModified.setNetwork("FHDL");
		zipToDestModified.setState("WA");
		zipToDestModified.setTransactionType("M");
		zipToDestModified.setUuid("asdsadsd-asdsad--adsa");
		zipToDestModified.setZipCode("A0A0A0");
		
		ZipToDest zipToDestDelete = new ZipToDest();
		zipToDestDelete.setCountryCode(840);
		zipToDestDelete.setCancelledFlag("N");
		zipToDestDelete.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestDelete.setCreationUser("Test");
		zipToDestDelete.setCurrent("N");
		zipToDestDelete.setDestinationTerminal("11");
		zipToDestDelete.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestDelete.setProcessed("N");
		zipToDestDelete.setNetwork("FHDL");
		zipToDestDelete.setState("WA");
		zipToDestDelete.setTransactionType("D");
		zipToDestDelete.setUuid("asdsadsd-asdsad--adsa");
		zipToDestDelete.setZipCode("A0A0A1");
	
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		jobExecution.getExecutionContext().put(ZipToDestBatchUtil.KEY_UNPROCESSED_ADDED, unprocessedAdd);
		jobExecution.getExecutionContext().put(ZipToDestBatchUtil.KEY_UNPROCESSED_MODIFIED, unprocessedModify);
		jobExecution.getExecutionContext().put(ZipToDestBatchUtil.KEY_UNPROCESSED_DELETED, unprocessedDelete);
		

		StepExecution execution = new StepExecution("zipToDestModifyReadTasklet", jobExecution);
		StepContribution contribution = new StepContribution(execution);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);
		
		RepeatStatus status  = zipToDestHasDeltaTasklet.execute(contribution, chunkContext);
		assertEquals(RepeatStatus.FINISHED, status);
		
		unprocessedAdd.add(zipToDestAdded);
		unprocessedModify.add(zipToDestModified);
		unprocessedDelete.add(zipToDestDelete);
		status = zipToDestHasDeltaTasklet.execute(contribution, chunkContext);
		assertEquals(RepeatStatus.FINISHED, status);
	}
}
