package org.zd.batch.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;
import org.zd.batch.model.Network;
import org.zd.batch.repository.redis.NetworkRedisRepository;

@RunWith(SpringRunner.class)
public class NetworkRepositoryTest {

	@InjectMocks
	NetworkRepository networkRepository;

	@Mock
	NetworkRedisRepository networkRedisRepository;

	@Mock
	ZSetOperations<String, String> networkSetOperations;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSave() {
		Network network = new Network();
		network.setNetworkId("FXG");
		network.setTermNum(1234L);

		when(networkRedisRepository.save(network)).thenReturn(network);

		Network output = networkRepository.save(network);
		assertEquals(network.getNetworkId(), output.getNetworkId());
	}

	@Test
	public void testSaveAll() {
		List<Network> networks = new ArrayList<>();
		when(networkRedisRepository.saveAll(networks)).thenReturn(networks);
		networkRepository.saveAll(networks);
	}

	@Test
	public void testFindById() {
		Optional<Network> network = Optional.empty();
		when(networkRedisRepository.findById(123L)).thenReturn(network);
		networkRepository.findById(123L);
	}

	@Test
	public void testExistsById() {
		when(networkRedisRepository.existsById(123L)).thenReturn(false);
		networkRepository.existsById(123L);
	}

	@Test
	public void testFindAll() {
		List<Network> networks = new ArrayList<>();
		when(networkRedisRepository.findAll()).thenReturn(networks);
		networkRepository.findAll();
	}
	
	@Test
	public void testFindAllById() {
		List<Long> ids = new ArrayList<>();
		ids.add(1234L);
		List<Network> networks = new ArrayList<>();
		when(networkRedisRepository.findAllById(ids)).thenReturn(networks);
		networkRepository.findAllById(ids);
	}

	@Test
	public void testCount() {
		when(networkRedisRepository.count()).thenReturn(0L);
		networkRepository.count();
	}
	
	@Test
	public void testDeleteById() {		
		networkRepository.deleteById(123L);
	}

	@Test
	public void testDelete() {
		Network entity = new Network();
		entity.setTermNum(12L);
		networkRepository.delete(entity);
	}

	@Test
	public void testListDeleteAll() {
		List<Network> entities = new ArrayList<>();
		networkRepository.deleteAll(entities);
	}

	@Test
	public void testDeleteAll() {
		networkRepository.deleteAll();
	}
	
}
