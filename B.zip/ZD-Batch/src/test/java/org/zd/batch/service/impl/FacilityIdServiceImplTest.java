package org.zd.batch.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.zd.batch.model.FacilityDelta;
import org.zd.batch.model.ZipToDest;
import org.zd.batch.repository.FacilityDeltaRepository;
import org.zd.batch.util.ZipToDestBatchUtil;

@RunWith(SpringRunner.class)
public class FacilityIdServiceImplTest {

	@InjectMocks
	private FacilityIdServiceImpl facilityIdService;	

	@Mock
	FacilityDeltaRepository facilityIdRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testFindZipcodeRangeByNetwork(){
		List<FacilityDelta> facilities = new ArrayList<>();
		String network = "FXGL";
		String zipCode = "85851";
		
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345000000");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);
		
		FacilityDelta facility = ZipToDestBatchUtil.instanceOfFacilityId(zipToDest);
		facilities.add(facility);
		
		when(facilityIdRepository.findZipcodeRangeByNetwork(network, zipCode)).thenReturn(facilities);
		
		
		List<FacilityDelta> rvalue = facilityIdService.findZipcodeRangeByNetwork(network, zipCode);
		
		assertNotNull(rvalue);
	}
	
	@Test
	public void addZipToDestFacility(){
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345000000");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);	
		
		facilityIdService.addZipToDestFacility(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("A0A0A0");
		facilityIdService.addZipToDestFacility(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		assertNotNull(zipToDest);
	}
	
	@Test
	public void testDeleteZipToDestFacility(){
		List<FacilityDelta> facilities = new ArrayList<>();	
		
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345000000");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);
		
		FacilityDelta facility = ZipToDestBatchUtil.instanceOfFacilityId(zipToDest);
		facilities.add(facility);
		
		facilityIdService.deleteZipToDestFacility(facilities, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		assertNotNull(zipToDest);
	}
}
