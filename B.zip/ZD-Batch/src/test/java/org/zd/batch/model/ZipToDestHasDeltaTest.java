package org.zd.batch.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;

public class ZipToDestHasDeltaTest {

	ZipToDestHasDelta zipToDestHasDelta;
	
	@Before
	public void init(){	
		zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork("FHDL");
		zipToDestHasDelta.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
	}
	
	@Test
	public void testZipToDestHasDelta(){
		assertNotNull(zipToDestHasDelta.getNetwork());
		assertNotNull(zipToDestHasDelta.getLastUpdateTimestamp());	
		assertNotNull(zipToDestHasDelta.toString());
	}
	
	@Test
	public void testHashCode(){
		assertThat(zipToDestHasDelta.hashCode() > 0);
		zipToDestHasDelta.setNetwork(null);
		assertThat(zipToDestHasDelta.hashCode() > 0);
	}
	
	@Test
	public void testEquals(){
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork("FHDL");
		zipToDestHasDelta.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());	
		
		assertTrue(zipToDestHasDelta.equals(zipToDestHasDelta));
		ZipToDestHasDelta zipToDestHasDelta2 = null;
		assertFalse(zipToDestHasDelta.equals(zipToDestHasDelta2));
		assertFalse(zipToDestHasDelta.equals(new Object()));
		zipToDestHasDelta2 = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork(null);
		zipToDestHasDelta2.setNetwork(null);
		assertTrue(zipToDestHasDelta.equals(zipToDestHasDelta2));
		zipToDestHasDelta2.setNetwork("");
		assertFalse(zipToDestHasDelta.equals(zipToDestHasDelta2));
		zipToDestHasDelta.setNetwork("FXG");
		assertFalse(zipToDestHasDelta.equals(zipToDestHasDelta2));
		zipToDestHasDelta2.setNetwork(zipToDestHasDelta.getNetwork());
		assertTrue(zipToDestHasDelta.equals(zipToDestHasDelta2));
		
	}
}
