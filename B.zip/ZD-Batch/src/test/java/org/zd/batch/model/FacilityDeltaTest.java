package org.zd.batch.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;

public class FacilityDeltaTest {
	FacilityDelta facilityId;	
	
	@Before
	public void init(){		
		facilityId = new FacilityDelta();		
		facilityId.setState("WA");
		facilityId.setTransactionType("A");
		facilityId.setUuId("AZX-SXDE4R-CDDD");
		facilityId.setFacilityId(11);
		facilityId.setNetwork("FXGL");
		facilityId.setZipCode("A0A0A0");
		facilityId.setEffectiveDateTime(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		facilityId.buildKey();
	}	

	@Test
	public void testFacilityId() {		
		assertNotNull(facilityId.getState());
		assertNotNull(facilityId.getTransactionType());
		assertNotNull(facilityId.getUuId());
		assertNotNull(facilityId.getNetwork());
		assertNotNull(facilityId.getFacilityId());
		assertNotNull(facilityId.getZipCode());
		assertNotNull(facilityId.getEffectiveDateTime());
		assertNotNull(facilityId.toString());
				
	}	
	
	@Test
	public void testHashCode(){
		assertThat(facilityId.hashCode() > 0);
		facilityId.setId(null);
		assertThat(facilityId.hashCode() > 0);
	}
	
	@Test
	public void testEquals(){
		FacilityDelta facilityId = new FacilityDelta();		
		facilityId.setState("WA");
		facilityId.setTransactionType("A");
		facilityId.setUuId("AZX-SXDE4R-CDDD");
		facilityId.setFacilityId(11);
		facilityId.setNetwork("FXGL");
		facilityId.setZipCode("A0A0A0");
		facilityId.setEffectiveDateTime(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		facilityId.buildKey();
		
		assertTrue(facilityId.equals(facilityId));
		FacilityDelta facilityId2 = null;
		assertFalse(facilityId.equals(facilityId2));
		assertFalse(facilityId.equals(new Object()));
		facilityId2 = new FacilityDelta();
		facilityId.setId(null);
		facilityId2.setId(null);
		assertTrue(facilityId.equals(facilityId2));
		facilityId2.setId("");
		assertFalse(facilityId.equals(facilityId2));
		facilityId.buildKey();
		assertFalse(facilityId.equals(facilityId2));
		facilityId2.setId(facilityId.getId());
		assertTrue(facilityId.equals(facilityId2));
		
	}
}
