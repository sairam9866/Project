package org.zd.batch.model.mappers;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.zd.batch.model.StateProvince;

@RunWith(SpringRunner.class)
public class StateProvinceRowMapperTest {

	StateProvinceRowMapper stateProvinceRowMapper;
	
	@Mock
	ResultSet resultSet;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testStateProvinceRowMapper() throws SQLException{
		stateProvinceRowMapper = new StateProvinceRowMapper();
		
		when(resultSet.getString("CNTRYC")).thenReturn("CA");
		when(resultSet.getString("SPNAME")).thenReturn("ONTARIO");
		when(resultSet.getString("STAPRO")).thenReturn("ON");
		
		StateProvince stateProvince = stateProvinceRowMapper.mapRow(resultSet, 1);
		
		assertEquals("CA", stateProvince.getCntryc());
		assertEquals("ONTARIO", stateProvince.getSpName());
		assertEquals("ON", stateProvince.getStaPro());
	}
}
